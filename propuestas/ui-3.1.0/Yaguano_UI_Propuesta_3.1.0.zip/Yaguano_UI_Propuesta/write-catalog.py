from pathlib import Path
import json,re,hashlib
p=Path(__file__).resolve().parent
inventory='''| Pantalla / estado | Se conserva | Organización propuesta / motivo | Acción principal |
|---|---|---|---|
| Texto · Presets | 32 presets, IN/OUT, unidades, preview simulada/real, parámetros, restaurar | Preview + controles habituales; catálogo compacto con búsqueda/favoritos/recientes y 4 familias; sin miniaturas decorativas | Aplicar preset |
| Texto · Zoom y barridos | Zoom independiente, 5 estilos, colores, Blur, secuencia, follow, quitar y preview AE | Barridos desplegados; un grupo por intención; no se llevan a Lab | Aplicar acción seleccionada |
| Texto · Motion Lab v0.9 | 33 presets/4 packs, texto propio/original, dos líneas, Fill1–5, base/Echo/Ghost/glow, curva/anclaje, IN/OUT, secuencia/hold, transporte ±1f/scrub/loop, export config/60fps, crear/insertar/original/fuente | Texto primero; preview y controles principales; avanzados replegados por Movimiento/Aspecto/Tiempo; export y crear-insertar como elección accesible | Crear (con modo Crear/Insertar/Original) |
| Texto · Complex text animation | AEP original, render PNG de AE, pausa/scrub, dos textos opcionales, copia/insertar/abrir original | Acceso anidado dentro de Texto y ruta antigua compatible; frame correcto, caption fuera del clip, secundarios visibles | Insertar / Crear copia según modo |
| Biblioteca | Colecciones AEP, búsqueda, filtros, preview original, inserción/copia e importación | Lista y ficha de preview iguales a Texto; dependencias en Avanzado | Insertar |
| Carrousel | Línea editorial / Órbita suave, tres pins drag/teclado/X-Y, pausa/reset, imágenes/comp, count/gap/tamaños/anchura/softness/speed/radios/esquinas/duración/reverse/orient | Sigue debajo de Biblioteca; preview con pins que no se vuelven diminutos al reducir; fuentes antes de ajustes | Crear carrousel |
| Movimiento | 6 expresiones, preview, parámetros, código personalizado, CTA Ping, Lo-Fi Steps y aplicar | Nombres compactos, un inspector; avanzados sin perder parámetros | Aplicar expresión |
| Fondos | Estilos, paletas, intensidad/velocidad, controles nativos y actualización | Preview + Aspecto/Tiempo; conservar colores artísticos de los estilos | Crear / actualizar fondo |
| Curvas | Value/Speed, handles, coordenadas/leer/aplicar/guardar, 22 presets y personalizados, Curva Rebote llegada/salida/intensidad | Gráfico con hit targets, biblioteca y modo Rebote; no convertir rebote a una Bézier ficticia | Aplicar curva |
| Tools · Keys y curvas | 14 presets propios, gráfico valor/velocidad, números, guardar/leer/aplicar, IN/OUT, clipboard, pegar, shift/scale con colisiones | Un mismo control de valores; clipboard es acción directa secundaria | Aplicar curva o timing activo |
| Tools · Shapes y comps | Distribución H/V, duplicación superficial/profunda, recortar, extraer/fusionar formas, nulos de path, loop/Elastic | Grupos por tarea; límites operativos visibles donde se necesitan | Aplicar herramienta elegida |
| Tools · Scripts y expresiones | Código, selector de tipo, guardar/eliminar/cargar, drop sin ejecutar, reemplazo, Ctrl/Cmd+Enter | Editor wrap fluido y biblioteca lateral/anidada según ancho; ejecutar explícito | Ejecutar / aplicar |
| Tools · utilidades previas | Anclas 3×3, alineación, capas y todas las utilidades antiguas | Mismos componentes; agrupación, no eliminación | Acción contextual |
| Guardado | Paletas, referencias, fuentes, presets/FFX y recursos que ya estén disponibles; importar/exportar | Tabs por tipo, búsqueda/empty states, mismos datos persistidos | Añadir / guardar |
| Retícula | 10 formatos RRSS, FPS/duración, overlays TikTok/IG/Shorts mostrar/quitar/opacidad | Selector de formato fluido y acciones; overlays en grupo propio | Crear composición |
| Grid Pro | Distribución, estilo, geometría, guías/marcadores, animación, fuentes, attach/follow/pin/cover, máscaras, reparar/diagnosticar/desvincular | Preview + Distribución/Aspecto/Vínculos; color fields con espacio reservado | Crear / actualizar grid |
| Ajustes | Temas, acento/ayudas/movimiento, contexto, diagnóstico/reconectar, backups y reset | Conservar Claro y Midnight además del oscuro principal; acento fijo de propuesta o preferencias existentes sin sobrescribirlas | Guardar ajustes |
| Estados / diálogos | Demo, vacío, cargando, error, cancelación, fuente/permisos y confirmación destructiva | Estado local/aria-live; error de host persistente; reconexión manual; foco modal y Escape | Reintentar / continuar |
'''
(p/'MAPA_E_INVENTARIO.md').write_text('''# Inventario completo y mapa de información

Base: 3.1.0 publicada. No se considera que las capturas del prototipo sean una implementación de estas funciones: el inventario es el compromiso de conservación para la fase aprobada.

'''+inventory+'''
## Qué permanece visible y qué se pliega

- Siempre: título corto, preview cuando existe, texto editable de Lab, preset actual, controles frecuentes, acción contextual persistente y estado.
- Por intención: Movimiento, Aspecto, Tiempo, Fuentes o Vínculos según corresponda; el mismo nombre no significa forzar controles que no existen en ese efecto.
- Avanzado: opciones raras, exportaciones técnicas, diagnóstico y dependencias. Son accesibles por teclado y no cambian valores al plegar.
- Barridos se mantienen desplegados por requisito previo. El tamaño de cada bloque se reduce por diseño de filas, no ocultando los barridos.
- Nombres originales de presets/secciones/controles de UI se mantienen. Solo se traducirá copy auxiliar nueva; una traducción que cambie un nombre existente no se hará sin acordarla.

## Flujo de dos clics

Clic 1 en familia/pack, clic 2 en preset para cargarlo; buscar encuentra en todas las familias sin necesidad de abrirlas. Favoritos/recientes son metadatos UI por ID, no mutaciones de presets. Acciones Aplicar/Crear continúan explícitas y no se disparan al navegar.

## Notas de comportamiento a aprobar

Seleccionar un formato RRSS en un catálogo y crear desde la barra contextual es una reorganización de la acción actual; si se quiere mantener el botón de creación directa por formato, se conservará como secundaria sin duplicar lógica. Las utilidades de un clic de Tools conservarán ejecución directa secundaria. El prototipo no ha eliminado funciones que no muestra en detalle; su conservación está en esta matriz y deberá comprobarse en código al implementar.
''')
(p/'COMPONENTES_Y_TOKENS.md').write_text('''# Catálogo y sistema de diseño propuestos

Todos los componentes serán propios (HTML/CSS/JS), con los mismos IDs/valores/handlers del producto. La implementación integrará un sistema coherente y retirará reglas antiguas conflictivas; no se limitará a acumular otro fichero de parches.

| Componente | Anatomía / tamaño | Responsive | Halo / teclado |
|---|---|---|---|
| Botón primario | Uno por pantalla, azul #66C2FF, texto casi negro, alto ≥32px, radio 8px | Ancho flexible; verbo corto en estrecho y aria-label completa | Ambiental 9s; foco 2px; pressed .97 |
| Botón secundario / icono | Superficie elevada, etiqueta o icono uniforme 16/20px, hit area 32px | Texto envuelve o ellipsis con título; icon-only conserva nombre accesible | Hover 7s solo en el más cercano; Enter/Space |
| Fila de ajuste | Label, slider fino, valor tabular, unidad | ≥480 una fila cuando cabe; estrecho label arriba y rango/valor debajo | Rango nativo y valor con arrastre; teclado/foco; doble clic/Enter para escribir |
| Campo / pop-up | Input/select dentro de wrapper borde/halo; mínimo 32px | width/max-width:100%, min-width:0 | Sin pseudo en input reemplazado; select nativo, opciones por teclado |
| Segmented / tabs | 2–4 opciones cortas, estado activo azul claro | Envuelve en dos filas o cambia a pop-up cuando las etiquetas no caben | APG tabs manual, flechas/Home/End, Enter/Space |
| Interruptor | Pastilla azul (no verde), thumb contrastado, área ≥28–32px | No se encoge; label puede envolver | role=switch, aria-checked, Space; foco visible |
| Grupo plegable | Summary con nombre/contador, cuerpo asociado | Ancho fluido, títulos envolventes | Teclado nativo/APG; familia conserva animación, body ≤4px |
| Tarjeta / fila de preset | Nombre compacto, selección y favorito accesible | Grid auto-fit con mínimos limitados por 100%; una columna a 220px | aria-pressed; no depender de hover; conservar scroll |
| Preview / medio | Frame halo exterior, clip hijo de ratio, transporte fuera | Sin min-height que transfiera ancho; contain, viewBox o backing-store independiente | Ampliar preview accesible; caption siempre legible |
| Gráfico / pins | Trazo y handle visual discreto, target ≥28px | Hit area en CSS px, no escalada por viewBox; números X/Y alternativos | Teclado, reset, nombre/valor; contraste 3:1 |
| Lista / biblioteca | Search + filtros + filas, selección y ficha | Un panel o dos columnas según ancho | Acciones visibles al foco/táctil, títulos para truncado |
| Barra de acción | Fuera del scroll principal; estado + acción principal | Compacta en ≤340; presente a 360px de altura | Orden de foco estable; no clonar callbacks |
| Tooltip | Singleton medido respecto al viewport, retardo 400ms | Clamp lateral/vertical; nunca obliga a scroll horizontal | aria-describedby, foco y hover, no información exclusiva |
| Vacío / carga / error | Mensaje corto, contexto y acción útil | Texto envuelve; no ilustraciones grandes | aria-live; errores de host persistentes y reintento |
| Diálogo | Título, contenido, acciones; foco contenido | max-width:calc(100% - gutters), alto máximo con scroll interior | Escape, restaurar foco, no cambiar confirmaciones existentes |

## Tokens

| Grupo | Propuesta |
|---|---|
| Superficies | --base:#101216; --surface:#191C22; --raised:#22262E; --interactive:#292F39 |
| Texto | --text:#F1F4F8; --secondary:#B0B8C5; --tertiary:#8994A5; disabled opacidad .25 (exento de contraste de contenido activo) |
| Acento | --accent:#66C2FF; --accent-ink:#0D0E11; --focus:#91D3FF; hover #8BD1FF |
| Selección | --selected:rgba(102,194,255,.12); --selected-border:rgba(102,194,255,.55) |
| Halo | --halo-color:190,230,255; --halo-opacity:.06 reposo, .48 hover/foco, .7 pulsado; principal .23 blanco |
| Bordes / track | --border:rgba(255,255,255,.08) decorativo; track interactivo #66758B (no se confía en el borde 8% para información esencial) |
| Semánticos propuestos | Error #D6A2A2; aviso #CAB995; éxito #9EBCAC; uso local, no sustituyen el acento |
| Tipo | -apple-system,"SF Pro Text",Inter,"Segoe UI",sans-serif; Inter empaquetada OFL; 13/11–12/15–17px; 400/500/600; tabular-nums |
| Código / valores | Consolas,"Liberation Mono",monospace para código; valores Inter con tabular-nums; no keyword ui-monospace por Chrome99 |
| Espaciado | 4,8,12,16,24px expresados en rem; gutters clamp(8px,2.2vw,24px) |
| Radios | Control 8px; tarjeta 14px; panel 18px; hijos con radio = radio padre menos borde/padding |
| Sombra | 0 .6rem 1.5rem rgba(0,0,0,.16); sin glow persistente en todas las tarjetas |
| Curvas | --ease-out:cubic-bezier(.32,.72,0,1); --ease-standard:cubic-bezier(.4,0,.2,1) |
| Tiempos | --dur-fast:120ms; --dur-base:240ms; --dur-slow:320ms; --dur-exit:400ms; tooltip:150ms + retardo400ms; popover200ms |
| Breakpoints | ≤260,≤340,≤480,≤720,>720; altura≤480; mínimo220×360 CSS px |

Los tokens del prototipo están en mock/design.css como muestra revisable. Los tokens de duración complementarios se completarán en la integración; ninguna duración arbitraria quedará repartida por componentes. Los ~40% de texto terciario del brief se traducen a un color medido, no a opacidad literal que haga fallar AA en texto pequeño.

## Halo: técnica y rendimiento

`.halo` usa pseudo de anillo con inset:-1px y padding de 1px; conic-gradient y -webkit-mask / -webkit-mask-composite:xor. El frame no recorta: el hijo de medios sí. Los wrappers de campos reciben foco de sus inputs. Solo el elemento más cercano recibe el estado hover/foco para evitar halos de todos sus ancestors. En reposo no hay loops salvo el primario. Sin box-shadow/filter animado en bucle, sin backdrop-filter masivo. Reduced motion deja estados/foco sin rotación ni scale.

## Compatibilidad

Chrome99 soporta custom properties, flex/grid, minmax/min/clamp, gap de flex, aspect-ratio, object-fit, conic-gradient, @property, :focus-visible, ResizeObserver y prefers-reduced-motion utilizados. No se usarán :has, @container, color-mix, oklch/lab, dvh/svh ni scrollbar-width. El CSS actual contiene color-mix y scrollbar-width heredados: se retirarán al consolidar.

Doiuse señala CSS Masks como soporte parcial: el halo usa explícitamente la ruta prefijada de WebKit compatible, y tendrá fallback de borde/foco estático si no se soporta. No se declara compatibilidad basándose en silencios del linter: se probará esa ruta en CEF/AE. El entorno automatizado utiliza Chromium actual, no un binario de Chromium99; el contraste y la geometría se prueban aparte.
''')
(p/'NAMING.md').write_text('''# Naming Yaguano — propuesta de migración compatible

**No hay renombrado aplicado todavía.** Cambiar solo la palabra visible en capas no basta: hay expresiones y búsquedas por nombre. AUDITORIA_NAMING.json recoge 195 puntos de creación, nombres o lookup en las fuentes JSX (se excluye el bundle generado para no duplicarlos).

## Fuente única

`shared/product-config.js` será ES3 sin referencias a window, con BRAND="Yaguano", BRAND_MOTION="Yaguano Motion" y VERSION="3.1.0". Un único naming(kind,effect,index) y uniqueName(container,...) construirán nombres; el manifest, header, pie, diagnóstico y distribución derivarán de esa misma fuente. El XML se genera durante empaquetado de desarrollo: el usuario instala archivos planos, sin compilar. La revisión de UI/hash de bundle es un identificador interno, no una segunda versión mostrada.

Separador: U+00B7 (` · `) en UTF-8 y literales escapados con JSON.stringify al crear expresiones. No usar el texto localizado de nombres de efectos de Adobe: conservar matchName.

| Elemento generado | Patrón | Ejemplo |
|---|---|---|
| Capa de texto nueva | Yaguano · <Efecto> | Yaguano · Smart Reveal |
| Forma | Yaguano Shape · <Efecto> | Yaguano Shape · Grid Pro |
| Nulo/control | Yaguano Ctrl · <Efecto> | Yaguano Ctrl · Slide |
| Ajuste | Yaguano Adj · <Efecto> | Yaguano Adj · Lo-Fi Steps |
| Sólido/fondo | Yaguano BG | Yaguano BG |
| Composición | Yaguano Motion · <Efecto> | Yaguano Motion · Órbita suave |
| Precomposición | Yaguano Pre · <Efecto> | Yaguano Pre · Slide |
| Raíz / carpetas | Yaguano Motion / Yaguano Text, Yaguano Carousel, Yaguano Fluid | Yaguano Motion / Yaguano Text |
| Animator/control de expresión nuevo | Yaguano · <Parámetro> | Yaguano · Distancia |
| Duplicado | <nombre base> 02, 03… | Yaguano · Smart Reveal 02 |
| Texto de ejemplo general | BRAND_MOTION | Yaguano Motion |
| Ejemplo corto | BRAND | Yaguano |
| Menú / extensión | BRAND / BRAND_MOTION | Yaguano / Yaguano Motion |
| Pie | BRAND_MOTION · vVERSION | Yaguano Motion · v3.1.0 |

No se prefija cada etiqueta visible de UI; Smart Reveal, Órbita suave, Línea editorial, los controles y secciones conservan sus nombres. El branding de elementos generados en AE es distinto del naming de UI.

## Auditoría por módulo y compatibilidad

| Fuente | Dependencias actuales por nombre / metadata | Acción segura propuesta |
|---|---|---|
| jsx/host.jsx · Texto | Animix <kind> In/Out, MaskMotion/Mask Reveal, WO, Highlight, Spring Selector; Yaguano Spring/TW/Sweep/FX/Zoom; removers y expresiones | Nombre nuevo centralizado al crear; alias heredados al detectar/quitar/actualizar; jamás cambiar un TextDocument seleccionado por branding |
| jsx/host.jsx · fondos | YBG_PREFIX, YBG_CTRL, YBG_COLORS, SPEED/POWER; expresión bgExprProperty | Tabla de alias por parámetro; expresiones nuevas construidas con el nombre real encontrado |
| jsx/host.jsx · biblioteca | YL_ORIGINAL / YL_INSTANCE y nombres originales AEP | Conservar tags/IDs y originales; renombrar solo copias independientes, con memo del grafo y referencias correctas |
| jsx/host.jsx · Grid Pro | DG_NAME, DG_BG, DG_MASK, DG_META, DG_EXPR / DG_SCALE_EXPR; dgLayer/dgBgLayer/dgBoundsJS | Metadata primero, alias antiguo/nuevo después; migración de nombre solo explícita y con expresiones actualizadas |
| jsx/lab-native.jsx | Carpetas, glifos, scale/position nodes, IDs de muestreo | IDs internos y geometría no cambian; nombre visible por helper, descriptor interno separado |
| jsx/lab-editable.jsx | driverName/cacheName, fields[].name, nombre de comp/layer en expresiones, IDs externos | Rigs antiguos leen su metadata con nombres antiguos; nuevos guardan nombres nuevos; globals usan referencias resueltas, no literales repetidos |
| jsx/carrousel.jsx | YaguaTool Carrousel Control y etiquetas de sliders/pins en expresiones | Crear un mapa de nombres por instancia y usarlo en todas las expresiones/máscaras; rigs previos intactos |
| jsx/complex-text.jsx | Vapor Text, Text 01/02 y marker de master | Master importado intacto; copias con nombres nuevos; localizar por IDs/metadata antes de renombrar, no perder el mapa de textos |
| jsx/tools-pro.jsx | Expresiones/loops, formas y comps duplicadas | Nombrar únicamente lo que se crea; no renombrar fuentes, capas seleccionadas ni código del usuario |
| jsx/workflow.jsx | Comp RRSS generada | nombre común, valores de formatos/FPS/duración sin cambios |
| js previews / Lab / librerías | Defaults dispersos, referencia original y estado persistido | Default de marca solo cuando no hay texto de usuario; thumbnails/previews usan helper sin reescribir catálogos |
| Instaladores / manifest / bridge | com.animix.panel, root, versiones, backup folders | IDs CEP y API Animix.call quedan; ruta nueva o actual resuelta por bridge; backup fuera de CEP y no coexistencia del mismo ID |

No se editarán AEP, fuentes ni ZIP publicados, JSON de presets o presets guardados. No se hará find/replace global de Animix/YaguaTool. No se renombrarán automáticamente elementos de proyectos existentes. Alias no significa borrar cualquier capa de usuario que coincida: se exigen metadata/controles propios. La limpieza continúa limitada a IDs propios y sin usos externos.

## Texto del usuario y excepciones funcionales

Capa de texto ya seleccionada: contenido intacto. Estado persistido: no se interpreta «Tu texto» o «Meet Qwix» como permiso para sustituirlo; se respeta cualquier valor guardado y se aplica marca solo a nuevos defaults. Los generadores numéricos/Timer mantienen su salida y valores para no cambiar la función; marca en nombre y caption. La acción de referencia original conserva los textos del recurso al invocarse explícitamente. Estas dos excepciones forman parte de la propuesta de aprobación.

Fluido mantiene AEP master intacto. Una copia independiente puede usar defaults Yaguano / Motion si el usuario elige texto personalizado; el original y su preview real siguen siendo originales.

## Pruebas a añadir al implementar

1. Patrones por tipo y duplicados 02/03 con nombres que contienen espacios, acentos, comillas y barras.
2. Misma versión en manifest, web, host y distribución, proveniente del config único; recarga de host antiguo con misma versión pública y revisión interna distinta.
3. No sobrescribir contenido/nombre de una capa seleccionada o texto/preset guardado por branding.
4. Crear/quitar/actualizar sobre proyectos nuevos y sobre rigs legacy; resolver nombres antiguos y nuevos sin tocar terceros.
5. Expresiones y metadatos usan el nombre real generado/encontrado, incluyendo cambios de comps/instancias y duplicados.
6. Grid/fondos/Carrousel/Lab conservan enlaces, máscaras, secuencia, curvas y parámetros; limpieza solo de propios.
7. SHA256 de AEP, JSON de presets, fuentes originales y ZIP publicados idénticos; Inter con OFL.
8. Declaración de branding central: no se permiten literales sueltos para nuevos nombres generados fuera del módulo/aliases.
''')
raw=json.loads((p/'PRESETS_INVENTARIO.json').read_text());lab=json.loads(Path('/workspace/work/v310/YaguaTool/motion-lab/catalog.json').read_text())
lines=['# Defaults propuestos por efecto\n','No se modifica el catálogo. Estos valores pertenecen a la capa de presentación y a nuevas creaciones, nunca al contenido seleccionado o guardado.\n','| Ámbito | ID / efecto | Default | Criterio |','|---|---|---|---|']
for v in raw['text']:
 k=v['id'];name=v['name'];text='Yaguano';why='Texto breve para animación por letra, máscara, tracking o gran escala.'
 if k in ['N','TM']:text='Salida numérica/temporal original';why='Excepción funcional propuesta: marca en nombre/caption, sin cambiar formato/valores.'
 elif k in ['TW','WR','WB','HWR','EDITORIAL','GLIDE','AFL']:text='Yaguano Motion';why='Lectura por palabras/líneas o escritura; ejemplo general de dos palabras.'
 lines.append(f"| Texto | `{k}` · {name} | {text} | {why} |")
for v in lab:
 text='Yaguano Motion' if v['params'].get('split') in ['words','lines'] else 'Yaguano';why='Unidad '+str(v['params'].get('split','chars'))+'; no cambia parámetros ni valores del preset.'
 lines.append(f"| Motion Lab | `{v['id']}` · {v['name']} | {text} | {why} |")
for v in raw['motion']:lines.append(f"| Movimiento | `{v['id']}` · {v['name']} | Yaguano Motion (preview) | No cambia el contenido de capas seleccionadas. |")
lines+=['| Fluido | Copia personalizada / master | Yaguano + Motion / original intacto | Texto personalizado optativo; original explícito conserva recurso. |','| Carrousel | Línea editorial / Órbita suave | Imágenes del usuario; caption Yaguano | No incrustar texto en imágenes ni reemplazar fuentes. |','| Fondos / Retícula / Grid Pro | Todos | Sin texto añadido por fuerza; nombres Yaguano | Marca en elementos generados y chrome, sin alterar composición visual. |']
(p/'DEFAULTS_POR_EFECTO.md').write_text('\n'.join(lines)+'\n')
