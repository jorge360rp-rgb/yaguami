import urllib.request,concurrent.futures,json,re,pathlib
refs=[('Apple HIG Layout','https://developer.apple.com/design/human-interface-guidelines/layout'),('Apple HIG Sidebars','https://developer.apple.com/design/human-interface-guidelines/sidebars'),('Spectrum Slider','https://spectrum.adobe.com/page/slider/'),('Spectrum Side navigation','https://spectrum.adobe.com/page/side-navigation/'),('WAI APG Accordion','https://www.w3.org/WAI/ARIA/apg/patterns/accordion/'),('WAI APG Tabs','https://www.w3.org/WAI/ARIA/apg/patterns/tabs/'),('MDN aspect-ratio','https://developer.mozilla.org/en-US/docs/Web/CSS/aspect-ratio'),('MDN min-width','https://developer.mozilla.org/en-US/docs/Web/CSS/min-width'),('MDN @property','https://developer.mozilla.org/en-US/docs/Web/CSS/@property'),('DTCG','https://www.designtokens.org/'),('Magic UI Border Beam','https://magicui.design/docs/components/border-beam'),('Inter licence','https://raw.githubusercontent.com/rsms/inter/master/LICENSE.txt'),('CEP Resources','https://github.com/Adobe-CEP/CEP-Resources'),('Every Layout','https://every-layout.dev/'),('WCAG 2.2','https://www.w3.org/WAI/WCAG22/quickref/')]
def fetch(pair):
 name,url=pair
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=25) as r:s=r.read(2000000).decode('utf-8','replace');status=r.status
  title=re.search(r'<title[^>]*>(.*?)</title>',s,re.S|re.I)
  return dict(name=name,url=url,status=status,title=re.sub('<[^>]+>','',title.group(1)).strip() if title else name,bytes=len(s))
 except Exception as e:return dict(name=name,url=url,error=str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:data=list(pool.map(fetch,refs))
pathlib.Path('/workspace/work/ui-proposal-310/REFERENCIAS_VERIFICADAS.json').write_text(json.dumps(data,ensure_ascii=False,indent=2));print(json.dumps(data,ensure_ascii=False))
