from pathlib import Path
import zipfile,json,hashlib
p=Path(__file__).resolve().parent
# Integrity is a hard gate: the proposal must not write product files.
r=Path('/workspace/work/v310/YaguaTool');before=json.loads((p/'BASE_PROTEGIDA.json').read_text());now={str(f.relative_to(r)):hashlib.sha256(f.read_bytes()).hexdigest() for f in r.rglob('*') if f.is_file()};assert before==now
proto=json.loads((p/'PROTOTIPO_RESPONSIVE.json').read_text());assert proto['cases']==450 and not any(x['issues'] for x in proto['report'])
assert json.loads((p/'REGRESION_MEDIA.json').read_text())['checks']==60
assert not any(x['violations'] for x in json.loads((p/'ACCESIBILIDAD_PROTOTIPO.json').read_text()))
# No existing release archive is opened for writing.
z=p/'Yaguano_UI_Propuesta_3.1.0.zip'
exclude={'repo','devtools','video','node_modules','__pycache__'}
files=[]
for f in p.rglob('*'):
 if not f.is_file() or any(x in exclude for x in f.relative_to(p).parts):continue
 if f.suffix in ['.zip','.log'] or f.name in ['repo-main.js','package-meta.json']:continue
 files.append(f)
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for f in sorted(files):archive.write(f,'Yaguano_UI_Propuesta/'+str(f.relative_to(p)))
with zipfile.ZipFile(z) as archive:assert archive.testzip() is None
b=z.read_bytes();meta={'size':len(b),'sha256':hashlib.sha256(b).hexdigest(),'gitBlob':hashlib.sha1(('blob '+str(len(b))+'\0').encode()+b).hexdigest(),'files':len(files)}
(p/'package-meta.json').write_text(json.dumps(meta,indent=2));print(json.dumps(meta))
