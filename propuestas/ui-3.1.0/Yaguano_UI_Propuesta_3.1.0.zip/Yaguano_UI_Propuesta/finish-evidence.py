from pathlib import Path
import json,subprocess,hashlib,html
p=Path(__file__).resolve().parent;r=Path('/workspace/work/v310/YaguaTool')
log=subprocess.run(['git','-C',str(p/'repo'),'log','--oneline','-14'],capture_output=True,text=True,check=True).stdout
ancestor=subprocess.run(['git','-C',str(p/'repo'),'merge-base','--is-ancestor','48632ec16bf256cebe6726235e2a4e39d9bfeba7','e2bc26138adc0c7fa04e2a82447c6b819cd44488']).returncode
assert ancestor==0
(p/'HISTORIAL_BASE.txt').write_text('Base: codex/yaguatool-3.1.0-editable-motion-lab\nHead: e2bc26138adc0c7fa04e2a82447c6b819cd44488\nPR #4 head 48632ec... es ancestro (merge-base exit 0).\nmain sigue en 6a68c8a... y no se usa como base.\n\n'+log)
protected=json.loads((p/'BASE_PROTEGIDA.json').read_text());now={str(f.relative_to(r)):hashlib.sha256(f.read_bytes()).hexdigest() for f in r.rglob('*') if f.is_file()};assert protected==now,'Production files modified'
(p/'INTEGRIDAD_PRODUCTO.json').write_text(json.dumps({'files':len(protected),'unchanged':True,'aepSha256':now['library/Fluido_Original_AE2024.aep'],'note':'No source/manifest/native code, preset data, image, AEP or existing release ZIP has been changed by this proposal.'},indent=2))
base=json.loads((p/'BASELINE_RESPONSIVE.json').read_text());proto=json.loads((p/'PROTOTIPO_RESPONSIVE.json').read_text());media=json.loads((p/'REGRESION_MEDIA.json').read_text());axe=json.loads((p/'ACCESIBILIDAD_PROTOTIPO.json').read_text());compat=json.loads((p/'CHROME99.json').read_text());contrast=json.loads((p/'CONTRASTE.json').read_text())
assert proto['cases']==450 and not any(x['issues'] for x in proto['report']);assert media['checks']==60
bad=sum(bool(x['pageOverflow'] or x['documentOverflow'] or x['bounds'] or x['clipped'] or x['overlap']) for x in base['results'])
(p/'INFORME_RESPONSIVE.md').write_text(f'''# Informe de diagnóstico y propuesta responsive

**No es la validación de un rediseño ya instalado.** El producto 3.1.0 permanece intacto; se comparan base, prueba de solución en DOM y prototipo independiente.

| Prueba | Resultado | Límite |
|---|---|---|
| Base 3.1.0 | {base['cases']} casos, {bad} con incidencias detectadas | 15 estados: 12 secciones + Lab y dos tabs Tools |
| Matriz | anchuras 220/240/280/320/360/420/520/720/1000/1400 × alturas 360/560/800 | CSS px, tema oscuro y movimiento reducido para geometría |
| Prototipo | {proto['cases']} casos, cero desbordamientos/solapamientos/recortes sin ellipsis detectados | Maqueta visual; no ejecuta la extensión |
| Regresión de medios | {media['baselineFailures']} fallos originales; {media['checks']} checks de solución pasan | Referencia + PNG simulado de AE; corrección inyectada solo en DOM de prueba |
| Axe | {sum(len(x['violations']) for x in axe)} infracciones automáticas en {len(axe)} secciones | No certifica AA por sí sola; revisar incomplete y teclado manual |
| Contraste | {len(contrast['checks'])} combinaciones pasan | Texto ≥4.5:1; track ≥3:1; principal 9.86:1 |
| Chrome99 / doiuse | {len(compat['warnings'])} avisos de CSS Masks parcial | Implementación prefijada WebKit con fallback de borde/foco; confirmar en CEF de AE |
| Integridad | {len(protected)} archivos de extensión sin cambios | Native bridge, presets, fuentes y AEP no modificados |

El informe visual está en [informe.html](informe.html). Se guardaron capturas de cada estado × ancho × altura, antes y propuesta. Las mediciones no se limitan al scroll del documento: también comparan frames/medios, ancestros, controles y clipping. Se excluye el desbordamiento artístico intencional dentro de previews recortadas.

## Problemas encontrados → solución propuesta

| Hallazgo | Evidencia / solución | Estado |
|---|---|---|
| Fluido fuerza ~451/676px por min-height + ratio | ancho explícito, min-height:0, clip hijo y media contain | Demostrado en 60 checks; pendiente producto |
| Inspector Lab demasiado estrecho | una columna; avanzados por intención; numeric controls accesibles | Maqueta responde; integración pendiente |
| SVG Tools mayor que botón | SVG fluido y targets estables; mínimos limitados por 100% | Maqueta responde; integración pendiente |
| Formatos RRSS min 160px | catálogo fluido/pop-up y barra contextual | Maqueta responde; integración pendiente |
| Color fields Grid Pro | filas apilables y min-width:0 | Maqueta responde; integración pendiente |
| Botones cortados Texto/Guardado/Tools | wrapping/ellipsis con títulos, secundarios compactos | Maqueta responde; integración pendiente |
| Versión/fuentes CSS incompatibles | tokens; Consolas/fallback mono en lugar de ui-monospace; retirar color-mix/scrollbar-width actuales | Propuesta y compat check; pendiente consolidar producto |

## Qué prueban y qué no prueban las herramientas

- Scripts y JSON están incluidos para reproducir las mediciones. El navegador automatizado es Chromium actual; doiuse comprueba el objetivo Chrome99. No se ha ejecutado Chromium99 real ni After Effects.
- La búsqueda global de muestra carga un preset en dos clics, no lo aplica; Escape restaura el foco. Teclado: acordeón/Enter, tabs/flechas, switch/Space y ausencia de loops/transform bajo reduced motion tras estabilizar el estado.
- DPR automatizado 1/1.25/1.5/2 en 240×560 comprueba rasterización y ausencia de scroll. **No equivale a escalado real de SO/CEF ni a panel acoplado/flotante.**
- Las capturas de defecto/corrección y el halo son evidencia visual, no renders de After Effects. Los pins de Carrousel y las curvas del prototipo son representaciones; su interacción de producto se conserva y verificará al implementar.

## Verificación manual en AE pendiente tras aprobar e implementar

Panel acoplado/flotante; resize continuo; escalado SO 100/125/150/200%; temas oscuro/claro/Midnight; teclado y foco en menús/diálogos; texto largo/localizado; carga/error/empty/retry; preview real PNG; native create/insert/original Lab a60fps; Fill/Echo/Ghost/secuencia; scroll estable; imágenes/comps y pins; Tools/scripts/drop sin ejecución; alias de nombres legacy; contenido/presets guardados intactos. No avanzar de fase con desbordamientos.

## Reproducir

Servir la extensión intacta en :8770 y esta propuesta en :8771. node audit-baseline.js produce el baseline. node regression-media.js --proof reproduce el bug y prueba la estructura solo en DOM. node test-mock.js cubre la maqueta. Las dependencias Playwright, axe-core, postcss y doiuse son de desarrollo y no se incorporarán a la extensión.
''')
# offline HTML evidence index
pro={}
for x in proto['report']:pro[(x['state'],x['width'],x['height'])]=x
stateMap={'Texto':'text','motion-lab':'motion-lab','Complex-text-animation':'complex','Biblioteca':'library','Carrousel':'carrousel','Movimiento':'motion','Fondos':'backgrounds','Curvas':'graph','Herramientas':'tools','Guardado':'saved','Ret-cula':'grid','Grid-Pro':'dynamicgrid','Ajustes':'settings','tools-shapes':'tools-shapes','tools-code':'tools-code'}
rows=[]
for x in base['results']:
 y=pro.get((stateMap[x['state']],x['width'],x['height']));n=int(x['pageOverflow'])+len(x['bounds'])+len(x['clipped'])+len(x['overlap']);rows.append(f'<tr data-section="{html.escape(x["label"])}"><td>{html.escape(x["label"])}<small>{html.escape(x["state"])}</small></td><td>{x["width"]}×{x["height"]}</td><td>{n}</td><td><a href="{html.escape(x["screenshot"])}">Base</a></td><td><a href="{html.escape(y["screenshot"])}">Propuesta</a></td></tr>')
(p/'informe.html').write_text('''<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Yaguano · Informe UI</title><style>body{background:#101216;color:#f1f4f8;font:14px system-ui;line-height:1.55;margin:0;padding:20px}main{max-width:1100px;margin:auto}a{color:#66c2ff}img{max-width:100%;height:auto;border-radius:12px}header{display:grid;gap:8px}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,300px),1fr));gap:16px}.box{background:#191c22;border:1px solid #ffffff14;border-radius:14px;padding:16px}small{display:block;color:#b0b8c5}table{width:100%;border-collapse:collapse}td,th{text-align:left;border-bottom:1px solid #ffffff14;padding:8px}input,select{font:inherit;background:#22262e;color:inherit;padding:10px;border:1px solid #ffffff30;border-radius:8px;max-width:100%}.table-wrap{overflow-x:auto}video{max-width:100%}h1{font-size:24px}h2{font-size:18px}</style><main><header><h1>Yaguano · Propuesta de interfaz</h1><p>Revisión visual de 3.1.0 pendiente de aprobación. La extensión no está modificada.</p><p>Base:450 casos / 63 con incidencias. Maqueta:450 sin incidencias geométricas detectadas. Prueba de medios:60 checks. No es una validación en AE.</p><nav><a href="mock/index.html">Abrir prototipo</a> · <a href="DECISIONES_UI.md">Decisiones</a> · <a href="NAMING.md">Naming</a> · <a href="INFORME_RESPONSIVE.md">Informe</a></nav></header><section class="cards"><figure class="box"><img src="Propuesta_MotionLab.png" alt="Propuesta Motion Lab"><figcaption>Texto primero, superficies homogéneas y acción persistente.</figcaption></figure><figure class="box"><img src="Propuesta_240.png" alt="Propuesta a240px"><figcaption>Panel compacto de240px.</figcaption></figure></section><h2>Halo</h2><video controls src="Halo_Estados.webm"></video><div class="cards">'''+''.join(f'<figure class="box"><img src="halo-{s}.png" alt="Halo {s}"><figcaption>{s}</figcaption></figure>' for s in ['rest','hover','focus','pressed','primary'])+'''</div><h2>Bug y prueba de solución</h2><div class="cards"><figure class="box"><img src="bug-240.png" alt="Bug en base"><figcaption>Base: frame mayor que tarjeta.</figcaption></figure><figure class="box"><img src="proof-reference-240.png" alt="Solución inyectada en prueba"><figcaption>Prueba DOM: clip hijo y ancho100%, sin cambiar producto.</figcaption></figure></div><h2>Capturas por sección y tamaño</h2><label>Filtrar sección <input id="filter" type="search" placeholder="Texto, Tools, Retícula…"></label><div class="table-wrap"><table><thead><tr><th>Estado</th><th>CSS px</th><th>Incidencias base</th><th>Antes</th><th>Maqueta</th></tr></thead><tbody>'''+''.join(rows)+'''</tbody></table></div><p>Las comprobaciones de código, AE, escalado del SO y panel acoplado/flotante siguen pendientes de la fase de implementación.</p></main><script>document.getElementById('filter').oninput=function(){var q=this.value.toLowerCase();document.querySelectorAll('tbody tr').forEach(function(r){r.hidden=!r.textContent.toLowerCase().includes(q)})}</script></html>''')
(p/'README.md').write_text('''# Yaguano · Propuesta UI 3.1.0 — pendiente de aprobación

Esta entrega prepara las decisiones solicitadas antes de implementar. **No es una extensión instalable y no modifica la versión 3.1.0 ni sus AEP/ZIP.**

1. Abre **informe.html** para ver comparación, capturas de los 450 casos base y450 de maqueta, regresión de medios y halo.
2. Abre **mock/index.html** para navegar el prototipo sin conexión a AE. Búsqueda global, sliders, controles, tabs y switches son muestras de interacción; previews/pins son representativos y ningún botón ejecuta scripts. La muestra de búsqueda indexa78 presets; el producto deberá indexar también los recursos/bibliotecas del usuario.
3. Revisa **DECISIONES_UI.md** (causa del bug y decisiones), **MAPA_E_INVENTARIO.md**, **COMPONENTES_Y_TOKENS.md** y **REFERENCIAS.md**.
4. Revisa **NAMING.md** y **DEFAULTS_POR_EFECTO.md**: nombres centralizados, compatibilidad con proyectos antiguos y excepciones funcionales de números/Timer/originales.

Base correcta: release e2bc261… de3.1.0, con PR#4 como ancestro. main no contiene esa entrega. Fuente y producto protegidos por hash:153 archivos sin cambios.

Decisiones clave a aprobar: diseño oscuro con azul #66C2FF; mínimo220×360; preview/controles/acciones coherentes; Complex dentro de Texto con alias; naming Yaguano para nuevas creaciones; valores numéricos y modo original conservan contenido funcional. La versión pública seguirá siendo3.1.0 por el brief; se diferenciará la revisión interna para evitar un host antiguo en memoria.

La aprobación autoriza implementación por fases. El documento original pide: «Espera mi aprobación de todo esto antes de implementar» (BRIEF_ORIGINAL.txt). No se ha hecho todavía el rediseño del producto.
''')
print('Reports and decisions ready; product unchanged')
