# Yaguanimix 2.7 — Nuevo apartado Grid Pro

Se instala exactamente igual que la versión 2.6: cerrar AE, extraer todos los archivos y ejecutar el instalador del sistema. No altera las composiciones `.aep` incluidas. Se conserva la barra lateral con iconos y todos los apartados previos.

**Inicio rápido:** `Grid Pro → Grid → Classic 5×5 → Crear / reconstruir grid`. Para modificar un layout, arrastra sus divisores desde la vista previa y vuelve a reconstruir el grid. Para animar, elige `Animate` y un movimiento; los layouts personalizados se guardan con `+ Guardar layout` y se aplican con `Animar keyframes`. El botón `Extender al cabezal` añade el nuevo movimiento sin borrar los keyframes anteriores.

**Attach:** selecciona en AE las capas que quieras fijar, escoge uno o varios destinos en la miniatura y pulsa `Anclar capas seleccionadas`. `One area` coloca todas las capas seleccionadas en el área que abarcan las celdas. `One each` requiere igual número de capas y destinos. Se utilizan expresiones de Posición; un anclaje no sustituye expresiones anteriores, y separaciones de dimensiones existentes deben desactivarse. La máscara se ofrece solo para capas 2D y destinos de celdas. La ubicación se calcula con respecto al punto de anclaje de cada capa. Para modificar dimensiones del grid con capas ancladas, desvincúlalas primero.

**Backdrop:** los fondos se crean como una capa separada en la parte inferior; se pueden eliminar sin borrar el grid. `Archivo` abre un selector de metraje dentro de After Effects. Para el gradiente se usa el efecto nativo `Gradient Ramp`.

**Limitación:** probada fuera de After Effects con navegador y mocks ExtendScript. La ejecución real de expresiones 3D/parentadas, clipping de vídeo, importación y render deben comprobarse en AE 2024/2025. Ejecuta `qa/diagnostico_dynamic_grid_2_7.jsx` en un proyecto de prueba.

---

# Yaguanimix 2.6 — Instalación y uso

Compatible a nivel de manifiesto con After Effects 2024 (24.x) y 2025 (25.x). Es un panel **CEP** para **Ventana > Extensiones** (o Extensiones heredadas).

## Antes de instalar

1. Cierra completamente After Effects (no basta con cerrar el panel).
2. **Descomprime el ZIP entero**, conservando carpetas (`CSXS`, `css`, `js`, `jsx`, `library`, `assets`).
3. No ejecutes el instalador desde dentro del ZIP.

### Windows 10 / 11

1. Abre la carpeta descomprimida `Yaguanimix`.
2. Haz doble clic en **install_windows.bat**.
3. Confirma el mensaje **INSTALACIÓN COMPLETA**.
4. Abre After Effects. Busca `Yaguanimix` en **Ventana > Extensiones**.

Ruta de instalación por usuario: `%APPDATA%\Adobe\CEP\extensions\Yaguanimix`

Si Windows avisa de que no reconoce el script, examina su contenido antes de ejecutarlo. No solicita administración.

### macOS Intel / Apple Silicon

1. Abre Terminal.
2. Escribe `bash ` (con un espacio final), arrastra el archivo `install_mac.command` y pulsa Intro.
3. Comprueba el mensaje **INSTALACION COMPLETADA**.
4. Abre After Effects y busca **Ventana > Extensiones (heredadas) > Yaguanimix** (puede variar según el idioma).

Ruta: `~/Library/Application Support/Adobe/CEP/extensions/Yaguanimix`

### Actualización desde 2.3

No es necesario desinstalar la versión anterior. El instalador copia primero a una carpeta temporal, conserva un respaldo mientras termina y después sustituye la extensión. Tus composiciones `.aep` no se modifican al actualizar.

Los ajustes de la interfaz guardados en `localStorage` normalmente persisten, pero es recomendable hacer una copia de tus proyectos AE antes de probar nuevos efectos.

## Cómo animar ENTRADA + SALIDA distintas

1. En la composición, selecciona una o varias capas **de texto**.
2. En **Text**, selecciona el preset **Smart Reveal** y la fase **IN · Entrada**. Ajusta la duración y pulsa **Aplicar IN**. Por defecto comienza en el inicio de la capa (el ajuste de inicio de Ajustes se conserva).
3. Mueve el **cabezal del timeline** exactamente al fotograma donde quieras comenzar a despedir el texto.
4. Cambia a **OUT · Salida**, elige **Smart Bounce** (o un preset diferente), ajusta su duración y pulsa **Aplicar OUT en cabezal**.
5. Pulsa espacio para comprobar el montaje. Cambia de OUT y reaplica para sustituir solo el cierre.
6. **Quitar IN** y **Quitar OUT** no eliminan la fase contraria.

Cada aplicación es una operación Undo agrupada (Ctrl+Z / Cmd+Z). La nueva fase OUT se inicia en el tiempo actual de la composición. Si la capa acaba antes de completar la salida, su punto de salida se prolonga hasta terminarla, siempre que exista espacio en la composición. La aplicación se rechaza si la salida excede la duración total o comienza antes de la capa.

### Máscaras y presets especiales

- Los seis revelados con máscaras usan recortes reales. Se conservan máscaras IN al crear OUT. Para garantizar que el OUT sea consistente con varios renglones, la máscara OUT se aplica al **bloque de texto entero** (sin desfase por línea).
- Se rechaza aplicar máscaras a capas con máscaras manuales para evitar sobrescribirlas.
- **Whole Rise / Whole Bounce** ahora trabajan con animadores de texto y no sobre los keyframes de Transform (en aplicaciones nuevas).
- **Elastic Letters / Smart Bounce** exponen controles de rebote independientes para IN y OUT en Efectos.
- Los presets **Números** y **Temporizador** son generadores de contenido y no se pueden seleccionar como OUT. **Typewriter** tiene controles separados de escritura y borrado.
- Los presets existentes de la versión anterior no se convierten automáticamente; al reaplicarlos con el nuevo sistema, sus fases pasan a estar separadas.

## Interfaz y biblioteca

Se mantiene la interfaz que proporcionaste: paleta violeta/azul, controles y tarjetas redondeadas, temas y **Manrope como tipografía preferida**. Manrope se carga mediante Google Fonts si el sistema CEP tiene acceso a Internet; también se puede instalar Manrope en el sistema operativo. No se distribuyen archivos de fuentes con la extensión.

Las nueve pestañas mantienen el estilo 2.3. En un panel estrecho, la navegación inferior se puede desplazar horizontalmente para mostrar las secciones que no caben.

En **Library** ahora verás **Text Animation Pack 1**, **Text Animation Pack 2** y **Dynamic Text Animation**, sin alterar los archivos `.aep` originales ni los nombres internos de composición.

## Diagnóstico

Abre After Effects y ejecuta **Archivo > Scripts > Ejecutar archivo de script**, elige `qa/diagnostico_in_out_2_4.jsx`. El diagnóstico crea una composición de prueba (sin modificar la tuya) y escribe un informe en el Escritorio.

Si la interfaz sale vacía, comprueba primero que existen `js/main.js` y `css/style.css` dentro de la carpeta instalada. Verifica que se ve la versión 2.6 en la cabecera.

## Seguridad, permisos y desinstalación

La extensión CEP no está firmada. Los instaladores habilitan el ajuste de desarrollo `PlayerDebugMode` en CSXS 11, 12 y 13, solo para el usuario actual. Si no deseas mantenerlo, restaura el valor previo de `PlayerDebugMode` de esas versiones en el Registro (Windows: `HKCU\Software\Adobe\CSXS.x`) o las preferencias `com.adobe.CSXS.x` (macOS). No alteres otras extensiones antes de comprobar si utilizan ese ajuste.

Para desinstalar, cierra After Effects y elimina la carpeta `Yaguanimix` de la ruta de CEP correspondiente. No elimines tus archivos `.aep` de proyectos ni la carpeta de plantillas que hayas guardado fuera de la extensión.

**Importante:** aunque el código ha superado pruebas automatizadas, las animaciones deben renderizarse y comprobarse en AE 2024/2025 reales para afirmar compatibilidad visual completa.


## Novedades 2.6: Sweep Studio, Zoom y Tools

La versión 2.6 añade las funciones sin borrar el sistema IN/OUT ni la biblioteca de 51 composiciones. Encuentra Sweep Studio debajo de Color Sweep en **Text**; cada estilo incluye colores y controles propios. Si ya tienes aplicado Color Sweep original, puedes quitarlo antes de probar Studio para que los colores de ambos no se mezclen. **Preview real** crea una composición de prueba independiente (no aplica nada al proyecto activo).

El nuevo **Zoom tipográfico** está en Text. Actívalo, ajusta entrada/salida, intensidad y duración, mueve el cabezal al instante deseado y pulsa Aplicar zoom. Se puede eliminar la fase IN o OUT sin borrar la fase opuesta. Es un zoom por carácter, no una cámara o escala global de toda la capa. Para cambiar su timing, expande los keyframes del control `Yaguano Zoom IN/OUT Progress` en Efectos.

En **Tools**, Timeline añade **Escalonar capas** (fotogramas en positivo o negativo, en orden de pila), **Alinear inicios**, **Recortar IN/OUT**, **Marcador IN/OUT**, **Easy Ease** y **Renombrar capas**. Todas las operaciones permiten Deshacer en un paso. Para Easy Ease, selecciona antes los fotogramas clave, no solo las capas.

### Diagnóstico de 2.6

Ejecuta **Archivo → Scripts → Ejecutar archivo de script** y selecciona `qa/diagnostico_2_6.jsx`. Crea una composición de prueba con texto y ejecuta los nuevos barridos y el zoom. Si no permite escribir el informe en el Escritorio, muestra el resultado en un cuadro de diálogo. No uses composiciones importantes para hacer pruebas.

**Nota de compatibilidad:** el motor de ExtendScript usa ES3 y efectos nativos, pero algunas operaciones requieren validación en AE 2024/2025 reales. La simulación no reproduce los píxeles del render. **Manrope** se utiliza si la fuente está instalada o disponible por Google Fonts; no se distribuyen archivos de tipografías.


## Cambios de interfaz 2.6

La barra inferior se sustituye por una barra lateral con iconos que permanece visible. Pulsa el icono de menú arriba de la barra para expandir o contraer; al tocar otra sección también se abre. Pulsa Escape o haz clic fuera para cerrar. En Text, las familias de presets se despliegan pulsando sus títulos; los cinco barridos aparecen en un selector único y el deslizador Blur en píxeles afecta al barrido seleccionado.

Los ajustes se guardan en el panel. Después de aplicar un barrido, su Blur permanece editable en Efectos como `Yaguano Sweep Blur` o `Yaguano FX Blur`. Para retirar el barrido, selecciona la capa y pulsa **Quitar barrido**.
