// Yaguanimix 2.0 simulated AE engine: masks + ink sweep + full-frame gradient backgrounds.
// This is NOT a substitute for rendering in After Effects.
const vm=require('vm'),fs=require('fs'),assert=require('assert'),path=require('path');
let nextId=1, sceneComps=[];
class Shape{constructor(){this.vertices=[];this.inTangents=[];this.outTangents=[];this.closed=false}}
class Prop{
  constructor(name){this.name=name;this.children=[];this.value=0;this.keys=[];this.expression='';this.expressionEnabled=false;this.parentProperty=null;this.isSpatial=false;this.propertyValueType=0;this.maskMode=0}
  get numProperties(){return this.children.length}get numKeys(){return this.keys.length}
  property(n){return typeof n==='number'?this.children[n-1]||null:this.children.find(x=>x.name===n)||null}
  addProperty(name){let x=new Prop(name);x.parentProperty=this;
    if(name==='ADBE Text Animator'){x.addProperty('ADBE Text Animator Properties');let s=x.addProperty('ADBE Text Selectors');let r=s.addProperty('ADBE Text Selector');r.addProperty('ADBE Text Range Advanced');r.addProperty('ADBE Text Percent Start');r.addProperty('ADBE Text Percent End');r.addProperty('ADBE Text Percent Offset')}
    else if(name==='ADBE Text Expressible Selector'){x.addProperty('ADBE Text Expressible Amount');x.addProperty('ADBE Text Range Type2');}
    else if(name==='ADBE Slider Control'||name==='ADBE Color Control')x.addProperty('value');
    else if(name==='ADBE 4ColorGradient')for(let i=1;i<=8;i++)x.addProperty('effect-'+i);
    else if(name==='ADBE Ramp')for(let i=1;i<=7;i++)x.addProperty('ramp-'+i);
    else if(name==='ADBE Vector Group')x.addProperty('ADBE Vectors Group');
    else if(name==='ADBE Vector Shape - Ellipse')x.addProperty('ADBE Vector Ellipse Size');
    else if(name==='ADBE Vector Shape - Rect')x.addProperty('ADBE Vector Rect Size');
    else if(name==='ADBE Vector Graphic - Fill')x.addProperty('ADBE Vector Fill Color');
    else if(name==='ADBE Gaussian Blur 2'){x.addProperty('amount');x.addProperty('unused');x.addProperty('repeat edge pixels')}
    else if(name==='ADBE Fill')x.addProperty('ADBE Fill-0002');
    else if(name==='ADBE Glo2')for(let i=1;i<=5;i++)x.addProperty('ADBE Glo2-'+String(i).padStart(4,'0'));
    else if(name==='ADBE Mask Atom'){x.addProperty('ADBE Mask Shape');x.addProperty('ADBE Mask Feather')}
    this.children.push(x);return x;
  }
  setValue(v){this.value=v} setValueAtTime(t,v){this.keys.push([t,v]);this.value=v}
  valueAtTime(){return this.value}keyTime(i){return this.keys[i-1][0]} keyValue(i){return this.keys[i-1][1]} removeKey(i){this.keys.splice(i-1,1)} keyInInterpolationType(){return 1} keyOutInterpolationType(){return 1} keyInTemporalEase(){return [{}]} keyOutTemporalEase(){return [{}]}
  moveTo(index){if(!this.parentProperty)return;const ar=this.parentProperty.children;const old=ar.indexOf(this);if(old<0)return;ar.splice(old,1);ar.splice(Math.max(0,Math.min(ar.length,index-1)),0,this)}
  remove(){if(this.parentProperty)this.parentProperty.children=this.parentProperty.children.filter(x=>x!==this)}
  setInterpolationTypeAtKey(){}setTemporalEaseAtKey(){}
}
class Layer{
  constructor(name,comp){this.id=nextId++;this.name=name;this.comp=comp;this.inPoint=0;this.outPoint=comp.duration;this.label=1;this.selected=false;this.audioEnabled=false;this.properties={};this.source=null;this.transform={};
    for(const name of ['position','scale','rotation','opacity','anchorPoint'])this.transform[name]=new Prop(name);
    this.transform.opacity.value=100;this.transform.position.value=[200,200];this.transform.scale.value=[100,100];
    this.properties['ADBE Effect Parade']=new Prop('ADBE Effect Parade');
    this.properties['ADBE Root Vectors Group']=new Prop('ADBE Root Vectors Group');
    this.properties['ADBE Mask Parade']=new Prop('ADBE Mask Parade');
    let tp=this.properties['ADBE Text Properties']=new Prop('ADBE Text Properties');tp.addProperty('ADBE Text Animators');let td=tp.addProperty('ADBE Text Document');td.value={text:'Creative\rMotion',fontSize:82};
  }
  property(n){return this.properties[n]||null}
  duplicate(){let d=new this.constructor('Duplicated',this.comp);d.inPoint=this.inPoint;d.outPoint=this.outPoint;
    d.transform.opacity.value=this.transform.opacity.value;d.transform.opacity.expression=this.transform.opacity.expression;
    d.property('ADBE Text Properties').property('ADBE Text Document').value={...this.property('ADBE Text Properties').property('ADBE Text Document').value};
    d.property('ADBE Text Properties').property('ADBE Text Document').expression=this.property('ADBE Text Properties').property('ADBE Text Document').expression;
    this.comp.arr.unshift(d);return d}
  sourceRectAtTime(){return {left:-150,top:-90,width:360,height:160}}
  moveBefore(other){this.comp.arr=this.comp.arr.filter(x=>x!==this);this.comp.arr.splice(this.comp.arr.indexOf(other),0,this)}
  moveToEnd(){this.comp.arr=this.comp.arr.filter(x=>x!==this);this.comp.arr.push(this)}
  remove(){this.comp.arr=this.comp.arr.filter(x=>x!==this)}
}
class TextLayer extends Layer{}
class ShapeLayer extends Layer{}
class CompItem{
  constructor(w=1080,h=1920,d=10,fps=30){this.width=w;this.height=h;this.duration=d;this.frameRate=fps;this.frameDuration=1/fps;this.pixelAspect=1;this.time=0;this.arr=[];this.usedIn=[];
    this.layers={
      addNull:()=>{let l=new Layer('Null',this);this.arr.unshift(l);return l},
      addShape:()=>{let l=new ShapeLayer('Shape',this);this.arr.unshift(l);return l},
      addSolid:(c,nm)=>{let l=new ShapeLayer(nm,this);this.arr.unshift(l);return l},
      add:(source)=>{let l=new Layer(source.name,this);l.source=source;this.arr.unshift(l);return l},
      addText:(txt)=>{let l=new TextLayer('Text',this);l.property('ADBE Text Properties').property('ADBE Text Document').value.text=txt;this.arr.unshift(l);return l}
    }
  }
  get numLayers(){return this.arr.length}layer(i){return this.arr[i-1]}
  get selectedLayers(){return this.arr.filter(x=>x.selected)}
  openInViewer(){current=this}
  remove(){sceneComps=sceneComps.filter(x=>x!==this)}
}
let current=new CompItem();let orig=new TextLayer('Original',current);orig.selected=true;current.arr.push(orig);
orig.property('ADBE Text Properties').property('ADBE Text Document').expression='"keep expression"';
orig.transform.opacity.expression='value*0.5';orig.transform.opacity.expressionEnabled=true;
const sandbox={app:{project:{get activeItem(){return current},items:{addComp:(nm,w,h,pa,d,fps)=>{let c=new CompItem(w,h,d,fps);c.name=nm;sceneComps.push(c);return c}}},beginUndoGroup(){},endUndoGroup(){}},
 CompItem,TextLayer,ShapeLayer,Shape,MaskMode:{ADD:1,INTERSECT:2},BlendingMode:{NORMAL:1,SCREEN:2,MULTIPLY:3},KeyframeEase:class{},KeyframeInterpolationType:{BEZIER:1},PropertyValueType:{TwoD:2,ThreeD:3},ParagraphJustification:{CENTER_JUSTIFY:1},JSON,Math};
vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../jsx/host.jsx'),'utf8'),sandbox);
const call=(name,o)=>JSON.parse(sandbox.Animix.call(name,JSON.stringify(o)));

const base={mode:'in',dur:.8,delay:0,startAt:'layer',basedOn:'chars',dir:'up',dist:32,blur:5,scale:92,rot:0,bounce:23,bounces:2,overlap:70,fade:true};
function reset(){current=new CompItem();orig=new TextLayer('Original',current);orig.selected=true;current.arr.push(orig);orig.property('ADBE Text Properties').property('ADBE Text Document').value.text='Hello\rWorld';}
function animatorNames(){return orig.property('ADBE Text Properties').property('ADBE Text Animators').children.map(x=>x.name);}
function maskNames(){return orig.property('ADBE Mask Parade').children.map(x=>x.name);}


// Regression matrix: every TEXT preset, both phases, shared native preview dispatch.
let definitions={};vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../js/data.js'),'utf8'),definitions);
function snapshot(layer){
 function prop(p){return {name:p.name,value:p.value,expression:p.expression,keys:p.keys,children:p.children.map(prop)}}
 return layer.property('ADBE Text Properties').property('ADBE Text Document').expression+JSON.stringify(['ADBE Text Animators','ADBE Effect Parade','ADBE Mask Parade'].map(name=>prop(name==='ADBE Text Animators'?layer.property('ADBE Text Properties').property(name):layer.property(name))));
}
let passed=0;
for(const preset of definitions.TEXT_PRESETS){
 for(const mode of ['in','out']){
  reset();current.time=mode==='out'?.6:0;orig.property('ADBE Text Properties').property('ADBE Text Document').value.text='CREATIVE MOTION\rDESIGN WITH TYPE';let config={mode,startAt:'cti'};for(const p of preset.params)if(p.k!=='mode')config[p.k]=p.def;
  if(preset.id==='TW')config.twMode=mode==='out'?'delete':'type';
  if(preset.id==='YHERO')config.highlight=true;
  if(/^AF[WLC]$/.test(preset.id))config.lightAccent=true;
  const invalid=mode==='out'&&/^(N|TM)$/.test(preset.id);
  const applied=call('text',{...config,kind:preset.id});
  assert.equal(applied.ok,!invalid,preset.id+' apply '+mode+': '+applied.msg);
  let expected=snapshot(orig);
  reset();const preview=call('previewText',{kind:preset.id,params:config});
  assert.equal(preview.ok,!invalid,preset.id+' preview '+mode+': '+preview.msg);
  if(invalid)continue;
  assert.equal(snapshot(current.arr.find(l=>l.name==='Preview - '+preset.id)),expected,preset.id+' differs from apply '+mode);
  passed++;
 }
}
// Direction vectors, literal zero values and grouping must reach the AE properties.
for(const [dir,vector] of [['left',[32,0,0]],['right',[-32,0,0]],['up',[0,32,0]],['down',[0,-32,0]]]){
 reset();assert(call('text',{...base,kind:'SR',dir}).ok);
 const animator=orig.property('ADBE Text Properties').property('ADBE Text Animators').property(1);
 assert.deepEqual(animator.property('ADBE Text Animator Properties').property('ADBE Text Position 3D').value,vector);
}
for(const basedOn of ['chars','nospace','words','lines']){
 reset();assert(call('text',{...base,kind:'SB',basedOn,dist:0}).ok);
 const a=orig.property('ADBE Text Properties').property('ADBE Text Animators').property(1);
 assert(!a.property('ADBE Text Animator Properties').property('ADBE Text Position 3D'));
 assert.equal(a.property('ADBE Text Selectors').property(1).property('ADBE Text Range Type2').value,{chars:1,nospace:2,words:3,lines:4}[basedOn]);
}
reset();assert(call('text',{...base,kind:'MRU',stagger:0}).ok);
assert.deepEqual(orig.property('ADBE Mask Parade').children.map(m=>m.property(1).keys[0][0]),[0,0]);
// PNG path: mock filesystem/render API only. No pixels are claimed as AE validation.
const cache=new Map();
class MockFile {constructor(name){this.fsName=name;this.absoluteURI='file://'+name;this.exists=cache.has(name)} remove(){cache.delete(this.fsName)}}
class MockFolder {constructor(name){this.fsName=name;this.exists=true} create(){return true} getFiles(){return [...cache.keys()].map(x=>new MockFile(x))}}
MockFolder.temp={fsName:'/tmp'};sandbox.File=MockFile;sandbox.Folder=MockFolder;
let captured=[];CompItem.prototype.saveFrameToPng=function(time,file){assert(time>=0&&time<this.duration);cache.set(file.fsName,true);file.exists=true;captured.push(time)};
reset();const original=current;const sceneCount=sceneComps.length;const result=call('previewText',{kind:'SR',params:{...base,delay:10,dur:10},renderFrames:true});
assert(result.ok,result.msg);assert.equal(result.data.frames.length,180);assert.equal(current,original);assert(captured[captured.length-1]>20);assert.equal(sceneComps.length,sceneCount);
CompItem.prototype.saveFrameToPng=function(){throw Error('disk failure')};
assert(!call('previewText',{kind:'SR',params:base,renderFrames:true}).ok);assert.equal(current,original);
console.log(passed+' apply/preview combinations match; directions, zero values, grouping, rendered frames and failure cleanup PASS');

reset();current.time=9;
assert(!call('text',{...base,kind:'SR',mode:'out',dur:.8,delay:1}).ok,'delayed OUT must fit in the composition');
reset();assert(call('text',{...base,kind:'N',prefix:'C:\\tmp\n"',suffix:"'\\"}).ok);
new Function(orig.property('ADBE Text Properties').property('ADBE Text Document').expression);
reset();assert(call('text',{...base,kind:'MRL'}).ok);
const initial=orig.property('ADBE Mask Parade').property(1).property(1).keys[0][1].vertices;
assert(initial[1][0]-initial[0][0]<.1,'closed mask must not leave a visible strip');
console.log('Delayed OUT bounds, escaped number strings and fully hidden masks PASS');
