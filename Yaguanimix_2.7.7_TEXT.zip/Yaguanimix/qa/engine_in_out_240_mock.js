// Yaguanimix 2.0 simulated AE engine: masks + ink sweep + full-frame gradient backgrounds.
// This is NOT a substitute for rendering in After Effects.
const vm=require('vm'),fs=require('fs'),assert=require('assert'),path=require('path');
let nextId=1, sceneComps=[];
class Shape{constructor(){this.vertices=[];this.inTangents=[];this.outTangents=[];this.closed=false}}
class Prop{
  constructor(name){this.name=name;this.children=[];this.value=0;this.keys=[];this.expression='';this.expressionEnabled=false;this.parentProperty=null;this.isSpatial=false;this.propertyValueType=0;this.maskMode=0}
  get numProperties(){return this.children.length}get numKeys(){return this.keys.length}
  property(n){return typeof n==='number'?this.children[n-1]||null:this.children.find(x=>x.name===n)||null}
  addProperty(name){let x=new Prop(name);x.parentProperty=this;
    if(name==='ADBE Text Animator'){x.addProperty('ADBE Text Animator Properties');let s=x.addProperty('ADBE Text Selectors');let r=s.addProperty('ADBE Text Selector');r.addProperty('ADBE Text Range Advanced');r.addProperty('ADBE Text Percent Start');r.addProperty('ADBE Text Percent End');r.addProperty('ADBE Text Percent Offset')}
    else if(name==='ADBE Text Expressible Selector'){x.addProperty('ADBE Text Expressible Amount');x.addProperty('ADBE Text Range Type2');}
    else if(name==='ADBE Slider Control'||name==='ADBE Color Control')x.addProperty('value');
    else if(name==='ADBE 4ColorGradient')for(let i=1;i<=8;i++)x.addProperty('effect-'+i);
    else if(name==='ADBE Ramp')for(let i=1;i<=7;i++)x.addProperty('ramp-'+i);
    else if(name==='ADBE Vector Group')x.addProperty('ADBE Vectors Group');
    else if(name==='ADBE Vector Shape - Ellipse')x.addProperty('ADBE Vector Ellipse Size');
    else if(name==='ADBE Vector Shape - Rect')x.addProperty('ADBE Vector Rect Size');
    else if(name==='ADBE Vector Graphic - Fill')x.addProperty('ADBE Vector Fill Color');
    else if(name==='ADBE Gaussian Blur 2'){x.addProperty('amount');x.addProperty('unused');x.addProperty('repeat edge pixels')}
    else if(name==='ADBE Fill')x.addProperty('ADBE Fill-0002');
    else if(name==='ADBE Glo2')for(let i=1;i<=5;i++)x.addProperty('ADBE Glo2-'+String(i).padStart(4,'0'));
    else if(name==='ADBE Mask Atom'){x.addProperty('ADBE Mask Shape');x.addProperty('ADBE Mask Feather')}
    this.children.push(x);return x;
  }
  setValue(v){this.value=v} setValueAtTime(t,v){this.keys.push([t,v]);this.value=v}
  valueAtTime(){return this.value}keyTime(i){return this.keys[i-1][0]} keyValue(i){return this.keys[i-1][1]} removeKey(i){this.keys.splice(i-1,1)} keyInInterpolationType(){return 1} keyOutInterpolationType(){return 1} keyInTemporalEase(){return [{}]} keyOutTemporalEase(){return [{}]}
  moveTo(index){if(!this.parentProperty)return;const ar=this.parentProperty.children;const old=ar.indexOf(this);if(old<0)return;ar.splice(old,1);ar.splice(Math.max(0,Math.min(ar.length,index-1)),0,this)}
  remove(){if(this.parentProperty)this.parentProperty.children=this.parentProperty.children.filter(x=>x!==this)}
  setInterpolationTypeAtKey(){}setTemporalEaseAtKey(){}
}
class Layer{
  constructor(name,comp){this.id=nextId++;this.name=name;this.comp=comp;this.inPoint=0;this.outPoint=comp.duration;this.label=1;this.selected=false;this.audioEnabled=false;this.properties={};this.source=null;this.transform={};
    for(const name of ['position','scale','rotation','opacity','anchorPoint'])this.transform[name]=new Prop(name);
    this.transform.opacity.value=100;this.transform.position.value=[200,200];this.transform.scale.value=[100,100];
    this.properties['ADBE Effect Parade']=new Prop('ADBE Effect Parade');
    this.properties['ADBE Root Vectors Group']=new Prop('ADBE Root Vectors Group');
    this.properties['ADBE Mask Parade']=new Prop('ADBE Mask Parade');
    let tp=this.properties['ADBE Text Properties']=new Prop('ADBE Text Properties');tp.addProperty('ADBE Text Animators');let td=tp.addProperty('ADBE Text Document');td.value={text:'Creative\rMotion',fontSize:82};
  }
  property(n){return this.properties[n]||null}
  duplicate(){let d=new this.constructor('Duplicated',this.comp);d.inPoint=this.inPoint;d.outPoint=this.outPoint;
    d.transform.opacity.value=this.transform.opacity.value;d.transform.opacity.expression=this.transform.opacity.expression;
    d.property('ADBE Text Properties').property('ADBE Text Document').value={...this.property('ADBE Text Properties').property('ADBE Text Document').value};
    d.property('ADBE Text Properties').property('ADBE Text Document').expression=this.property('ADBE Text Properties').property('ADBE Text Document').expression;
    this.comp.arr.unshift(d);return d}
  sourceRectAtTime(){return {left:-150,top:-90,width:360,height:160}}
  moveBefore(other){this.comp.arr=this.comp.arr.filter(x=>x!==this);this.comp.arr.splice(this.comp.arr.indexOf(other),0,this)}
  moveToEnd(){this.comp.arr=this.comp.arr.filter(x=>x!==this);this.comp.arr.push(this)}
  remove(){this.comp.arr=this.comp.arr.filter(x=>x!==this)}
}
class TextLayer extends Layer{}
class ShapeLayer extends Layer{}
class CompItem{
  constructor(w=1080,h=1920,d=10,fps=30){this.width=w;this.height=h;this.duration=d;this.frameRate=fps;this.frameDuration=1/fps;this.pixelAspect=1;this.time=0;this.arr=[];this.usedIn=[];
    this.layers={
      addNull:()=>{let l=new Layer('Null',this);this.arr.unshift(l);return l},
      addShape:()=>{let l=new ShapeLayer('Shape',this);this.arr.unshift(l);return l},
      addSolid:(c,nm)=>{let l=new ShapeLayer(nm,this);this.arr.unshift(l);return l},
      add:(source)=>{let l=new Layer(source.name,this);l.source=source;this.arr.unshift(l);return l},
      addText:(txt)=>{let l=new TextLayer('Text',this);l.property('ADBE Text Properties').property('ADBE Text Document').value.text=txt;this.arr.unshift(l);return l}
    }
  }
  get numLayers(){return this.arr.length}layer(i){return this.arr[i-1]}
  get selectedLayers(){return this.arr.filter(x=>x.selected)}
  openInViewer(){current=this}
  remove(){sceneComps=sceneComps.filter(x=>x!==this)}
}
let current=new CompItem();let orig=new TextLayer('Original',current);orig.selected=true;current.arr.push(orig);
orig.property('ADBE Text Properties').property('ADBE Text Document').expression='"keep expression"';
orig.transform.opacity.expression='value*0.5';orig.transform.opacity.expressionEnabled=true;
const sandbox={app:{project:{get activeItem(){return current},items:{addComp:(nm,w,h,pa,d,fps)=>{let c=new CompItem(w,h,d,fps);c.name=nm;sceneComps.push(c);return c}}},beginUndoGroup(){},endUndoGroup(){}},
 CompItem,TextLayer,ShapeLayer,Shape,MaskMode:{ADD:1,INTERSECT:2},BlendingMode:{NORMAL:1,SCREEN:2,MULTIPLY:3},KeyframeEase:class{},KeyframeInterpolationType:{BEZIER:1},PropertyValueType:{TwoD:2,ThreeD:3},ParagraphJustification:{CENTER_JUSTIFY:1},JSON,Math};
vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../jsx/host.jsx'),'utf8'),sandbox);
const call=(name,o)=>JSON.parse(sandbox.Animix.call(name,JSON.stringify(o)));

const base={mode:'in',dur:.8,delay:0,startAt:'layer',basedOn:'chars',dir:'up',dist:32,blur:5,scale:92,rot:0,bounce:23,bounces:2,overlap:70,fade:true};
function reset(){current=new CompItem();orig=new TextLayer('Original',current);orig.selected=true;current.arr.push(orig);orig.property('ADBE Text Properties').property('ADBE Text Document').value.text='Hello\rWorld';}
function animatorNames(){return orig.property('ADBE Text Properties').property('ADBE Text Animators').children.map(x=>x.name);}
function maskNames(){return orig.property('ADBE Mask Parade').children.map(x=>x.name);}
const all=['YDRIFT','YSLOW','YHERO','HWR','CT','SBL','EL','AFW','AFL','AFC','KPU','LIFT','STAG','SNAP','EDITORIAL','DEPTH','GLIDE','SR','SB','O','WO','WR','WB','N','TM','TW','MRU','MRD','MRL','MRR','MSC','MDI'];
for(const kind of all){
 reset();let result=call('text',{...base,kind}); assert(result.ok,kind+':'+result.msg);
 assert(call('removeText',{}).ok,'remove '+kind);
}
console.log('32 text presets apply/remove PASS');
reset();
let r=call('text',{...base,kind:'SR'});assert(r.ok,r.msg);assert(animatorNames().includes('Animix SR In'));
current.time=4;
r=call('text',{...base,kind:'SB',mode:'out',startAt:'cti'});assert(r.ok,r.msg);
assert(animatorNames().includes('Animix SR In')&&animatorNames().includes('Animix SB Out'),'mix IN/OUT');
let spring=orig.property('ADBE Text Properties').property('ADBE Text Animators').children.find(x=>x.name==='Animix SB Out').property('ADBE Text Selectors').property(1).property('ADBE Text Expressible Amount').expression;
new Function('time','textIndex','textTotal','effect',spring);
assert(spring.includes('Yaguano Spring Bounce OUT'));
assert(orig.property('ADBE Effect Parade').property('Yaguano Spring Bounce OUT'));
assert(orig.transform.position.numKeys===0,'text should not touch transform');
assert(call('text',{...base,kind:'EL',mode:'out',startAt:'cti'}).ok);
assert(animatorNames().includes('Animix SR In')&&animatorNames().includes('Animix EL Out'));
assert(!animatorNames().includes('Animix SB Out'),'replace OUT');
assert(call('removeTextPhase',{phase:'out'}).ok);
assert.deepEqual(animatorNames(),['Animix SR In'],'remove phase OUT only');
console.log('SR IN + SB OUT + swap EL OUT + remove OUT PASS');
reset();orig.transform.opacity.setValueAtTime(1,80);orig.transform.position.setValueAtTime(2,[100,100]);
assert(call('text',{...base,kind:'WR'}).ok);
current.time=3;
assert(call('text',{...base,kind:'WB',mode:'out',startAt:'cti'}).ok);
assert.deepEqual(animatorNames(),['Animix WR In','Animix WB Out']);
assert.equal(orig.transform.opacity.numKeys,1,'opacity preserved');
assert.equal(orig.transform.position.numKeys,1,'position preserved');
console.log('WR/WB non-destructive native animators PASS');
reset();r=call('text',{...base,kind:'MRL'});assert(r.ok,r.msg);
current.time=3;
r=call('text',{...base,kind:'MRU',mode:'out',startAt:'cti'});assert(r.ok,r.msg);
assert(maskNames().filter(x=>x.includes(' IN ')).length===2);
assert(maskNames().filter(x=>x.includes(' OUT ')).length===1);
assert.equal(orig.property('ADBE Mask Parade').children.slice(-1)[0].maskMode,2,'OUT intersection');
assert(call('removeTextPhase',{phase:'out'}).ok);
assert(maskNames().length===2,'IN masks remain');
console.log('mask IN (2 lines) + mask OUT intersect + remove OUT PASS');
reset();current.time=2;assert(call('text',{...base,kind:'MRD',mode:'out',startAt:'cti'}).ok);assert(call('text',{...base,kind:'MDR',mode:'in'}).ok===false,'invalid preset should fail');
assert(call('text',{...base,kind:'MRL',mode:'in'}).ok);
assert(maskNames().some(x=>x.includes(' OUT ')) && maskNames().filter(x=>x.includes(' IN ')).length===2);
assert(maskNames()[maskNames().length-1].includes(' OUT '),'OUT mask must be last');
console.log('OUT mask first then IN added PASS (intersection dependent on moveTo in real AE)');
reset();orig.outPoint=2;current.time=3;
assert(call('text',{...base,kind:'SR',mode:'out',startAt:'cti'}).ok);
assert(orig.outPoint>=3.8,'layer outPoint extended');
reset();current.time=9.8;
r=call('text',{...base,kind:'SB',mode:'out',startAt:'cti'});assert(!r.ok && r.msg.includes('fuera'),'guard overflow');
console.log('outPoint extension and comp duration guard PASS');
reset();assert(call('text',{...base,kind:'TW',mode:'in'}).ok);current.time=3;
assert(call('text',{...base,kind:'TW',mode:'out',startAt:'cti'}).ok);
let ex=orig.property('ADBE Text Properties').property('ADBE Text Document').expression;
assert(ex.includes('YAGUANIMIX_TW_240'));new Function('time','effect','value',ex);
let effects=orig.property('ADBE Effect Parade');
assert(effects.property('Yaguano TW IN').property(1).numKeys===2);
assert(effects.property('Yaguano TW OUT').property(1).numKeys===2);
assert(call('removeTextPhase',{phase:'out'}).ok);
assert(effects.property('Yaguano TW IN').property(1).numKeys===2);
console.log('Typewriter independent IN/OUT PASS');
console.log('2.4 AE MOCK PASS. These are logic simulations, not renders in After Effects.');
