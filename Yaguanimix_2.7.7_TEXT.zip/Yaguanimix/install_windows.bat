@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
title Instalacion Yaguanimix 2.7.7 - After Effects 2024/2025
set "SOURCE=%~dp0"
set "EXTDIR=%APPDATA%\Adobe\CEP\extensions"
set "DEST=%EXTDIR%\Yaguanimix"
set "STAGE=%EXTDIR%\Yaguanimix.__instalando__"
set "BACKUP=%EXTDIR%\Yaguanimix.__respaldo__"
set "LOG=%TEMP%\Yaguanimix_2_7_7_instalacion.log"

echo ============================================
echo   YAGUANIMIX 2.7.7 - Windows
 echo  After Effects 2024 / 2025 - CEP
 echo ============================================
echo.
echo Cierra After Effects antes de continuar.
echo Instalacion por usuario: no necesita administrador.
echo.
if not exist "%SOURCE%CSXS\manifest.xml" (
  echo ERROR: faltan archivos. Descomprime todo el ZIP y ejecuta desde la carpeta Yaguanimix.
  goto failure
)
if not exist "%EXTDIR%" mkdir "%EXTDIR%"
if errorlevel 1 goto failure
if exist "%STAGE%" rmdir /S /Q "%STAGE%"
if exist "%STAGE%" goto failure

rem Primero copiamos todo al directorio temporal; no tocamos la version actual.
robocopy "%SOURCE%" "%STAGE%" /E /R:2 /W:1 /NP /NFL /NDL >"%LOG%" 2>&1
set "RC=%ERRORLEVEL%"
if %RC% GEQ 8 (
  echo ERROR: fallo la copia de archivos. Consulta: "%LOG%"
  goto failure
)
if not exist "%STAGE%\CSXS\manifest.xml" goto failure
if not exist "%STAGE%\js\main.js" goto failure
if not exist "%STAGE%\css\style.css" goto failure

rem Guardar temporalmente la version anterior para permitir rollback.
if exist "%BACKUP%" rmdir /S /Q "%BACKUP%"
if exist "%BACKUP%" goto failure
if exist "%DEST%" (
  move "%DEST%" "%BACKUP%" >nul
  if errorlevel 1 goto failure
)
move "%STAGE%" "%DEST%" >nul
if errorlevel 1 goto restore

rem Esta extension CEP no esta firmada: se habilita el modo de desarrollo para CSXS.
for %%V in (11 12 13) do (
  reg add "HKCU\Software\Adobe\CSXS.%%V" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
  if errorlevel 1 echo AVISO: no se pudo configurar CSXS.%%V. Consulta GUIA_INSTALACION.md.
)
if exist "%BACKUP%" rmdir /S /Q "%BACKUP%"
echo.
echo INSTALACION COMPLETA: "%DEST%"
echo Reinicia After Effects y abre Ventana ^> Extensiones ^> Yaguanimix.
echo Si el panel no aparece, consulta GUIA_INSTALACION.md.
echo.
pause
exit /b 0

:restore
 echo ERROR al activar la nueva version. Recuperando la instalacion anterior...
 if exist "%DEST%" rmdir /S /Q "%DEST%"
 if exist "%BACKUP%" move "%BACKUP%" "%DEST%" >nul
:failure
 echo.
 echo No se pudo completar la instalacion. Comprueba el ZIP y los permisos.
 echo Registro de copia: "%LOG%"
 if exist "%STAGE%" rmdir /S /Q "%STAGE%"
 pause
 exit /b 1
