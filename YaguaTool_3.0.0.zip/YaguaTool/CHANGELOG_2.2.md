# Yaguanimix 2.2 — Fondos dinámicos corregidos + Biblioteca AEP

## Corrección de fondos v2.2
- **Pearl Bloom** ya no es una capa blanca plana: incorpora tres luces radiales suaves.
- **Principal, secundario y acento** tienen un degradado radial individual en *todos* los estilos: Pearl Bloom, Cobalt Horizon, Aurora Silk y Nocturne Flux.
- Desde **BG**, crea o reemplaza el fondo. Después los cambios de color/velocidad/intensidad del panel actualizan la composición automáticamente; también hay botón **Actualizar colores en AE**.
- En After Effects, busca la capa **Animix BG - CONTROLES 2.2** y abre **Efectos**: cinco controles nativos (3 colores, velocidad, intensidad) permiten editar sin reconstruir el fondo.
- Cada luz es un sólido del tamaño completo con **Gradient Ramp radial** (ADBE Ramp), sin formas ni máscaras recortadas. Pearl usa Multiply; los estilos oscuros usan Screen.
- Al actualizar un fondo de una versión anterior, se migra al nuevo sistema; al crear uno nuevo, el fondo viejo se borra **solo cuando** el nuevo se ha construido correctamente.
- Las capas se sitúan debajo del contenido de la composición activa. No se alteran las capas de texto.

**Prueba recomendada en AE 2024/2025:** ejecutar `qa/diagnostico_fondos_2_2.jsx` desde Archivo > Scripts > Ejecutar archivo de script. Genera una composición de prueba y `Yaguanimix_Diagnostico_Fondos_2_2.txt` en el Escritorio. Las simulaciones automatizadas no garantizan el render real.

## Contenido
- Biblioteca **51 animaciones originales** de tus tres archivos de After Effects (.aep), seleccionables desde la pestaña **Library**.
- `Text Animation 24.x.aep`: 21 presets de revelado, deriva, transiciones y escritura.
- `Text Animation.aep`: 10 títulos de diseño editorial.
- `Dynamic Text Animation.aep`: 20 títulos con controladores de color, glow y fondo.
- Tres nuevas recreaciones nativas inspiradas en esas técnicas: **Drift In · Fast**, **Drift Out · Cinematic** y **Highlight Lift** en **Texto**.

## Instalación
1. Cerrar After Effects.
2. Descomprimir todo el ZIP (NO mover los `.aep` fuera de `Yaguanimix/library`).
3. Ejecutar `install_windows.bat` o `install_mac.command`.
4. Reiniciar After Effects 2024/2025.
5. Ventana > Extensiones > Yaguanimix > **Library**.

## Aplicar una animación original
1. Abrir la composición de destino en After Effects.
2. Elegir un pack y una animación en **Library**.
3. Opcional: **Encajar tamaño en la comp** para adaptar su encuadre sin modificar el original. **▶ Ver original en AE** para examinar la fuente. **+ Aplicar en composición** para insertar una nueva instancia editable.
4. Editar las capas de texto y controladores de la composición que se crea; las copias se guardan en `Yaguano · Instancias AEP` del panel Proyecto.
5. Cada pack se importa **una vez por proyecto**, no una vez por clic. Las instancias duplican la composición y sus dependencias de precomp. Los sólidos/medios externos compartidos NO se duplican.

**Importante:** al pulsar "Ver original", AE activa la composición de la plantilla. Vuelve a abrir tu composición de destino antes de pulsar «Aplicar».

## Límites / compatibilidad
- Las composiciones se importan como proyectos `.aep`, no se convierten a `.ffx`. Es el método más fiel sin abrir y renderizar los proyectos previamente.
- La importación de un proyecto `.aep` en ExtendScript introduce el proyecto completo, no únicamente una composición. Después se reutiliza sin volver a importar.
- Las expresiones que apuntan a nombres de composición con `comp("Nombre")` se intentan redirigir a copias de la misma instancia. Referencias ambiguas con nombres duplicados entre proyectos, plugins externos, fuentes faltantes y medios sin vincular requieren comprobación en After Effects.
- Los `.aep` fueron inspeccionados como estructuras RIFX y catalogados por sus nombres internos. No hay garantía de render ni se han convertido/guardado en otra versión de After Effects.
- Al importar por primera vez, puede tardar si el proyecto contiene múltiples comp/efectos. Si faltan recursos, After Effects mostrará el aviso correspondiente.
- Los presets nativos son recreaciones **inspiradas** en los proyectos, no clones frame a frame; usan animadores de texto nativos.

## Verificación
Ejecutar `qa/diagnostico_ae2024.jsx` desde Archivo > Scripts > Ejecutar archivo de script para probar los animadores nativos. Para los `.aep`, prueba abrir el original, agregar a una composición y editar una copia de prueba; compara el render visual en tu instalación.
