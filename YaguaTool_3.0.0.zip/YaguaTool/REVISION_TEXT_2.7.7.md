# Yaguanimix 2.7.7 · Revisión de TEXT

## Uso

1. Cierra el panel y sustituye la carpeta Yaguanimix por la de este ZIP. También puedes utilizar los instaladores incluidos como en la versión anterior.
2. Reinicia After Effects y abre Yaguanimix. El encabezado debe indicar 2.7.7.
3. En TEXT, selecciona un preset, la fase IN/OUT y sus parámetros.
4. La simulación rápida se reproduce automáticamente. «Renderizar preview real en el panel» solicita a After Effects fotogramas PNG y los reproduce dentro del panel. El primer render puede tardar y AE estará ocupado mientras genera los fotogramas.
5. «Abrir preview real en AE» crea una composición editable con el mismo preset y todos sus componentes. Pulsa espacio en AE para reproducirla con la frecuencia de la composición.

Para guardar los PNG, AE debe tener activada la opción de permitir que los scripts escriban archivos, en Preferencias > Scripts y expresiones. Si falla el render, el panel muestra el error; puedes abrir la composición de preview en AE sin generar PNG.

## Qué representa cada vista

La simulación rápida utiliza texto de muestra y responde a unidad, dirección, distancia, escala, rotación, opacidad, duración, retraso, tracking y controles de rebote según el preset. Los números, temporizadores y typewriter se actualizan durante la reproducción. Sigue siendo una aproximación: las curvas, suavidad de los selectores, feather, distribución tipográfica, parpadeo aleatorio y acentos de luz requieren el motor de AE para compararlos con fidelidad.

La preview renderizada contiene imágenes calculadas por AE mediante el mismo código que aplica el preset, incluidos Highlight Lift y los acentos opcionales Apple Fluid. Utiliza texto de muestra, fuente y composición de prueba; no representa literalmente el diseño de una capa seleccionada. Los PNG se calculan a media resolución y se muestrean a unos 12 fps, con un máximo de 180 fotogramas. En secuencias largas disminuye la frecuencia de muestreo manteniendo la duración. Para juzgar suavidad a 30 fps, utiliza la composición nativa.

Cambiar parámetros descarta la preview renderizada y vuelve a la simulación. Se requiere un nuevo render para ver esos ajustes en AE. Los PNG se guardan en una carpeta temporal propia y se reemplazan en el siguiente render. La composición temporal se elimina al terminar el render del panel y se vuelve a abrir la composición anterior. La opción de abrir preview en AE conserva su composición de prueba.

## Correcciones del motor

- Dirección horizontal: izquierda/derecha ahora coincide con el sentido indicado por las flechas tanto en IN como en OUT. Esto afecta a las animaciones nuevas; los animadores ya aplicados se conservan hasta volver a aplicar el preset.
- Smart Bounce y Elastic Letters: el selector recibe la unidad elegida (letras, letras sin espacios, palabras o líneas).
- Se respeta distancia cero en el motor elástico y cadencia cero en los revelados por máscara.
- Las máscaras cerradas usan un rectángulo prácticamente nulo, evitando la franja del 3 % anterior.
- La validación de OUT tiene en cuenta el retraso y amplía el punto de salida hasta el final efectivo, cuando cabe en la composición.
- Number escapa correctamente prefijos y sufijos con barras, comillas y saltos de línea.
- Aplicar y previsualizar comparten un único distribuidor de presets. La preview incluye el highlight de YHERO y los acentos opcionales de AFW/AFL/AFC.
- Typewriter utiliza la fase IN/OUT como control de escribir/borrar. Se retira del panel el segundo selector contradictorio.
- Se corrigen descripciones: WR/WB usan animadores de texto y conservan Transform; KPU/SNAP no prometen un overshoot inexistente en su motor.

## Cobertura: los 32 presets

| Familia | Presets revisados |
| --- | --- |
| Inspirados en biblioteca | YDRIFT, YSLOW, YHERO |
| Máscaras | MRU, MRD, MRL, MRR, MSC, MDI |
| Editorial y fluido | HWR, CT, SBL, AFW, AFL, AFC, LIFT, STAG, EDITORIAL, GLIDE |
| Escala y profundidad | KPU, SNAP, DEPTH |
| Revelado y rebote | SR, SB, EL, WR, WB |
| Opacidad | O, WO |
| Contenido | N, TM, TW |

Number y Timer son generadores IN. OUT se rechaza con un mensaje explicativo; para animar su salida se aplica un preset visual. Typewriter admite entrada y salida independientes.

## Validación realizada

- 62 combinaciones válidas de aplicación/preview en un motor AE simulado; comparación de animadores, propiedades, expresiones, máscaras, controles y tiempos, incluida la expresión Source Text. Las dos combinaciones OUT de Number/Timer se rechazan como corresponde.
- Pruebas específicas de direcciones, unidades del selector elástico, valores cero, máscaras cerradas, retraso OUT, cadenas Number y limpieza/restauración de composición ante éxito/error del render.
- Chromium real a 420 px: navegación por los 32 presets en IN y OUT, cambio de unidades, contador animado, modo sin AE y ausencia de errores JavaScript.
- Transporte CEP simulado en Chromium: carga y reproducción de fotogramas y descarte al cambiar parámetros.
- Regresiones existentes: engine_in_out_240_mock.js, engine_260_mock.js, engine_attach_276_mock.js y engine_grid_regressions_275_mock.js pasan.

Ejecutar la matriz principal: `node qa/engine_text_277_mock.js`.

La prueba de navegador está en `qa/text_preview_277_browser.js`; requiere Node, Playwright y Chromium. Servir la carpeta de la extensión en `http://127.0.0.1:8765` (por ejemplo, `python -m http.server 8765`) y ejecutar la prueba desde la raíz de la extensión. Es posible indicar otra URL con YAGUANIMIX_TEST_URL y otro ejecutable con CHROMIUM_PATH.

Dos pruebas antiguas, engine_250_mock.js y panel_smoke_test.js, fallan también en el ZIP original 2.7.6: la primera espera tres animadores de Style Sweep donde el código actual genera cuatro; la segunda no modela nav-shade ni la navegación actual. No se presentan como comprobaciones superadas.

## Pendiente de validar en After Effects

Este entorno no dispone de After Effects. Los mocks comprueban la estructura y lógica, pero no certifican la interpretación de propiedades, expresiones ni píxeles por AE. La nueva ruta saveFrameToPng y el acceso a los PNG desde CEP se han comprobado con simulación, no en una instalación real de AE.

Antes de utilizar esta revisión en producción, comprobar en AE 2024/2025:

- Render del panel y apertura de preview nativa con permisos de escritura activados/desactivados.
- Las 32 previews con sus valores recomendados, y OUT para los 30 presets compatibles.
- SB/EL por palabras y líneas; direcciones izquierda/derecha; distancia y cadencia cero.
- YHERO con/sin highlight y AFW/AFL/AFC con/sin acento.
- Entrada/salida en capas con keyframes, texto de varias líneas y otras expresiones/animadores, y conservación de la fase contraria.

La versión se entrega como revisión pendiente de esta validación visual nativa; el ZIP original no se ha modificado.
