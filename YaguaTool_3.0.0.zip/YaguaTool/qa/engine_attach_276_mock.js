// Test de regresión 2.7.6: geometría de máscaras y posición desde los
// mismos sliders, un vínculo móvil sin saltos y centrado con ancla/escala.
// Harness JS; no sustituye la validación de AE real.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
class Prop {
 constructor(name,parent){this.name=name;this.parentProperty=parent||null;this.children=[];this._value=0;this.keys=[];this.expression='';this.dimensionsSeparated=false;this.expressionError='';}
 get numProperties(){return this.children.length;} get numKeys(){return this.keys.length;} get value(){return this._value;} get matchName(){return this.name;}
 property(k){return typeof k==='number'?this.children[k-1]||null:this.children.find(x=>x.name===k||x.matchName===k)||null;}
 addProperty(k){let v=new Prop(k,this);
  if(k==='ADBE Vector Group')v.children.push(new Prop('ADBE Vectors Group',v));
  if(k==='ADBE Vector Shape - Rect') ['ADBE Vector Rect Position','ADBE Vector Rect Size','ADBE Vector Rect Roundness'].forEach(x=>v.children.push(new Prop(x,v)));
  if(k==='ADBE Vector Shape - Ellipse') ['ADBE Vector Ellipse Position','ADBE Vector Ellipse Size'].forEach(x=>v.children.push(new Prop(x,v)));
  if(k==='ADBE Vector Graphic - Fill') ['ADBE Vector Fill Color','ADBE Vector Fill Opacity'].forEach(x=>v.children.push(new Prop(x,v)));
  if(k==='ADBE Vector Graphic - Stroke') ['ADBE Vector Stroke Color','ADBE Vector Stroke Width'].forEach(x=>v.children.push(new Prop(x,v)));
  if(k==='ADBE Mask Atom')v.children.push(new Prop('ADBE Mask Shape',v));
  if(k==='ADBE Slider Control')v.children.push(new Prop('ADBE Slider Control-0001',v));
  this.children.push(v);return v;
 }
 remove(){if(this.parentProperty)this.parentProperty.children=this.parentProperty.children.filter(x=>x!==this);}
 setValue(v){this._value=v;}
 setValueAtTime(t,v){let k=this.keys.find(k=>Math.abs(k.t-t)<1e-6);if(k)k.v=v;else this.keys.push({t,v});this.keys.sort((a,b)=>a.t-b.t);this._value=v;}
 setValueAtKey(k,v){this.keys[k-1].v=v;} keyTime(k){return this.keys[k-1].t;} keyValue(k){return this.keys[k-1].v;} removeKey(k){this.keys.splice(k-1,1);} setInterpolationTypeAtKey(){}
 valueAtTime(t){if(!this.keys.length)return this._value;if(t<=this.keys[0].t)return this.keys[0].v;if(t>=this.keys[this.keys.length-1].t)return this.keys[this.keys.length-1].v;
  for(let i=1;i<this.keys.length;i++)if(t<=this.keys[i].t){const a=this.keys[i-1],b=this.keys[i],u=(t-a.t)/(b.t-a.t);return Array.isArray(a.v)?a.v.map((v,j)=>v+(b.v[j]-v)*u):a.v+(b.v-a.v)*u;}return this._value;}
}
class Layer {
 constructor(c,type){this.c=c;this.type=type;this.name='Layer';this.comment='';this.threeDLayer=false;this.parent=null;this.selected=false;
  this.root=new Prop('ADBE Root Vectors Group');this.effects=new Prop('ADBE Effect Parade');this.masks=new Prop('ADBE Mask Parade');
  this.position=new Prop('ADBE Position');this.opacity=new Prop('ADBE Opacity');this.scale=new Prop('ADBE Scale');this.scale.setValue([100,100]);this.anchor=new Prop('ADBE Anchor Point');this.anchor.setValue([500,300]);
  this.transform={position:this.position,opacity:this.opacity,scale:this.scale,anchorPoint:this.anchor};this.width=1000;this.height=600;
 }
 property(k){if(k==='ADBE Root Vectors Group')return this.root;if(k==='ADBE Effect Parade')return this.effects;
  if(k==='ADBE Mask Parade')return this.masks;if(k==='ADBE Transform Group')return {property:(p)=>p==='ADBE Position'?this.position:p==='ADBE Scale'?this.scale:null};return null;}
 remove(){this.c._layers=this.c._layers.filter(x=>x!==this);} moveToBeginning(){this.remove();this.c._layers.unshift(this);} moveToEnd(){this.remove();this.c._layers.push(this);}
 duplicate(){let l=new Layer(this.c,this.type);l.name=this.name;this.c._layers.unshift(l);return l;}
}
class CompItem {
 constructor(){this.width=1920;this.height=1080;this.duration=30;this.time=0;this.frameDuration=1/30;this.pixelAspect=1;this._layers=[];}
 get numLayers(){return this._layers.length;} get selectedLayers(){return this._layers.filter(x=>x.selected);}
 layer(k){return typeof k==='number'?this._layers[k-1]||null:this._layers.find(x=>x.name===k)||null;}
 get layers(){const c=this;return {addShape(){let l=new Layer(c,'shape');c._layers.unshift(l);return l;},addSolid(){let l=new Layer(c,'solid');c._layers.unshift(l);return l;},add(){let l=new Layer(c,'footage');c._layers.unshift(l);return l;}};}
}
const comp=new CompItem(),ctx={JSON,Math,Error,Array,CompItem,app:{project:{activeItem:comp},beginUndoGroup(){},endUndoGroup(){}},File:{openDialog:()=>null},ImportOptions:function(){},ImportAsType:{FOOTAGE:'FOOTAGE'},KeyframeInterpolationType:{LINEAR:'LINEAR'},isFinite};
vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../jsx/host.jsx'),'utf8'),ctx,{filename:'host.jsx'});
function run(name,args){let res=JSON.parse(ctx.Animix.call(name,JSON.stringify(args||{})));if(!res.ok)throw Error(name+': '+res.msg);return res;}
const a={x:[0,.2,.55,1],y:[0,.25,.55,1]},b={x:[0,.29,.72,1],y:[0,.25,.48,1]},cfg={cols:3,rows:3,layout:a,draw:'both',markers:true,gap:8,radius:0,lineWidth:2,cellOpacity:0,rim:0,cellColor:'#8975ee',lineColor:'#ffffff',markerColor:'#ffffff'};
run('dgCreate',cfg);
const grid=comp.layer('Yaguanimix Dynamic Grid');assert(grid);
run('dgAnimate',{custom:true,frames:[{layout:a,move:1,hold:0},{layout:b,move:1,hold:0}],move:1,hold:0,stagger:0,easing:'Linear',order:'row'});
function gvalue(name,t){const eff=grid.effects.property(name);assert(eff,'Missing DG control: '+name);return eff.property(1).valueAtTime(t);}
function bounds(t){const x0=gvalue('DG X 1',t)*comp.width,x1=gvalue('DG X 2',t)*comp.width,y0=gvalue('DG Y 1',t)*comp.height,y1=gvalue('DG Y 2',t)*comp.height,g=gvalue('DG Gap',t);const w=Math.max(.5,x1-x0-g),h=Math.max(.5,y1-y0-g);return {x:(x0+x1)/2,y:(y0+y1)/2,L:(x0+x1-w)/2,R:(x0+x1+w)/2,T:(y0+y1-h)/2,B:(y0+y1+h)/2};}
function evalProp(prop,t,layer,extra={}){const mockgrid={effect(name){return n=>{assert.strictEqual(n,1);return gvalue(name,t);}}};
 const local={Math,time:t,value:prop.value,thisComp:{width:comp.width,height:comp.height,layer:(name)=>{assert(name==='Yaguanimix Dynamic Grid',name);return mockgrid;}},thisLayer:{hasParent:!!layer.parent,anchorPoint:layer.anchor.value,scale:layer.scale.value,rotation:layer.rotation||0,sourceRectAtTime:()=>layer.sourceRect||{left:0,top:0,width:layer.width,height:layer.height},fromComp:p=>p},createPath:(pts,inn,out,closed)=>({points:pts,closed}),...extra};
 // AE throws on `.parent` access for a layer with no parent; mocks must also throw.
 Object.defineProperty(local.thisLayer,'parent',{get(){if(!layer.parent)throw Error('La capa no tiene primario: no se puede utilizar .parent');return layer.parent;}});
 return vm.runInNewContext(prop.expression,local);
}
function near(actual,want,label,eps=.0001){assert(Math.abs(actual-want)<eps,label+': expected '+want+', got '+actual);}
const img=comp.layers.add();img.name='Imagen';img.selected=true;img.position.setValue([730,445]);img.scale.setValue([120,120]);
// 1. Reveal (fixed)
run('dgAttach',{targets:['c:1:1'],mode:'area',reveal:true,clip:true});assert.strictEqual(img.position.expression,'');
// 2. Follow: same baseline at t0; baseline+center delta at t1
run('dgAttach',{targets:['c:1:1'],mode:'area',follow:true});
assert(img.position.expression.includes('FOLLOW_CELL_275'));assert(!img.position.expression.includes('DG Rect'),'must follow slider rig directly');
let initial=evalProp(img.position,0,img),later=evalProp(img.position,1,img);
near(initial[0],730,'follow x0');near(initial[1],445,'follow y0');
near(later[0],730+bounds(1).x-bounds(0).x,'follow x1');near(later[1],445+bounds(1).y-bounds(0).y,'follow y1');
let mask=img.masks.property(1).property('ADBE Mask Shape'),at1=evalProp(mask,1,img);near(at1.points[0][0],bounds(1).L,'mask L');near(at1.points[0][1],bounds(1).T,'mask T');
// 3. Reapply follow at frame 1 without sudden jump. Simulate freeze evaluated expression.
comp.time=1;img.position.valueAtTime=function(t){return evalProp(this,t,img)};
run('dgAttach',{targets:['c:1:1'],mode:'area',follow:true});
let again=evalProp(img.position,1,img);near(again[0],later[0],'reattach x');near(again[1],later[1],'reattach y');
// 4. Pin, normal centered footage. No scale distortion and actual center of source aligns.
run('dgDetach');img.position.valueAtTime=Prop.prototype.valueAtTime;img.position.setValue([730,445]);comp.time=0;
img.sourceRect={left:0,top:0,width:1000,height:600};img.anchor.setValue([0,0]);img.scale.setValue([110,80]);img.rotation=30;
run('dgAttach',{targets:['c:1:1'],mode:'area',align:'center',fit:'none',clip:true});
assert(img.position.expression.includes('PIN_CELL_275'));
let pin=evalProp(img.position,0,img),r=img.sourceRect,origin=[r.width/2*1.1,r.height/2*.8],angle=Math.PI/6,ox=origin[0]*Math.cos(angle)-origin[1]*Math.sin(angle),oy=origin[0]*Math.sin(angle)+origin[1]*Math.cos(angle);
near(pin[0]+ox,bounds(0).x,'pin centered x');near(pin[1]+oy,bounds(0).y,'pin centered y');
let pin2=evalProp(img.position,1,img);near(pin2[0]-pin[0],bounds(1).x-bounds(0).x,'pin tracks x');near(pin2[1]-pin[1],bounds(1).y-bounds(0).y,'pin tracks y');
// 5. Parent space: target is transformed into parent before adjusting local offset.
const parent={fromComp:pt=>[(pt[0]-300)/2,(pt[1]-100)/2]};img.parent=parent;
let parentPin=evalProp(img.position,1,img);near(parentPin[0]+ox,(bounds(1).x-300)/2,'parent pin x');near(parentPin[1]+oy,(bounds(1).y-100)/2,'parent pin y');
run('dgDetach');img.position.setValue([70,50]);img.parent=parent;
run('dgAttach',{targets:['c:1:1'],mode:'area',follow:true});let parent0=evalProp(img.position,0,img),parent1=evalProp(img.position,1,img);
near(parent0[0],70,'parent follow base x');near(parent0[1],50,'parent follow base y');
near(parent1[0]-parent0[0],(bounds(1).x-bounds(0).x)/2,'parent follow dx');near(parent1[1]-parent0[1],(bounds(1).y-bounds(0).y)/2,'parent follow dy');
// 6. Center + cover scales uniformly, never stretches the image dimensions.
run('dgDetach');img.parent=null;img.anchor.setValue([0,0]);img.scale.setValue([100,100]);img.rotation=0;
run('dgAttach',{targets:['c:1:1'],mode:'area',align:'center',fit:'cover',clip:true});
const scExpr=img.scale.expression;assert(scExpr.includes('DG X 1')&&scExpr.includes('DG Y 1'));
const scaleAt0=evalProp(img.scale,0,img),desired=Math.max((bounds(0).R-bounds(0).L)/1000,(bounds(0).B-bounds(0).T)/600)*100;
near(scaleAt0[0],desired,'uniform cover x');near(scaleAt0[1],desired,'uniform cover y');
img.scale.setValue(Array.from(scaleAt0));
const cp=evalProp(img.position,0,img);
near(cp[0]+500*desired/100,bounds(0).x,'cover pin x');near(cp[1]+300*desired/100,bounds(0).y,'cover pin y');
// 7. Diagnosis: reports attach status.
const report=run('dgDiagnoseAttach');assert(report.data.report.includes('centrar 2.7.5'));
// 8. Regression: old broken expression cannot evaluate on an unparented layer,
// but Attach's one-click repair fixes it without resetting the mask or scale.
let brokenPin=img.position.expression.replace('var dest=thisLayer.hasParent?thisLayer.parent.fromComp([x,y]):[x,y];','var parentLayer=thisLayer.parent;var dest=(parentLayer!=null)?parentLayer.fromComp([x,y]):[x,y];');
assert.notStrictEqual(brokenPin,img.position.expression);
img.position.expression=brokenPin;
assert.throws(()=>evalProp(img.position,0,img),/no se puede utilizar .parent/);
const originalMask=img.masks.property('YAG Dynamic Grid Clip');
run('dgRepairAttach');
assert.strictEqual(img.masks.property('YAG Dynamic Grid Clip'),originalMask,'repair preserves mask');
const fixedPin=evalProp(img.position,0,img);
near(fixedPin[0]+500*desired/100,bounds(0).x,'repair pin x');
let brokenScale=img.scale.expression.replace('var parentScale=thisLayer.hasParent?thisLayer.parent.transform.scale[0]/100:1;','var parentScale=(thisLayer.parent!=null)?thisLayer.parent.transform.scale[0]/100:1;');
assert.notStrictEqual(brokenScale,img.scale.expression);
img.scale.expression=brokenScale;
assert.throws(()=>evalProp(img.scale,0,img),/no se puede utilizar .parent/);
run('dgRepairAttach');
near(evalProp(img.scale,0,img)[0],desired,'repair cover scale');
// Follow expression created by 2.7.5 also used an unguarded .parent.
run('dgDetach');img.position.setValue([475,310]);
run('dgAttach',{targets:['c:1:1'],mode:'area',follow:true});
let intactMask=img.masks.property('YAG Dynamic Grid Clip');
let brokenFollow=img.position.expression.replace('var parentLayer=thisLayer.hasParent?thisLayer.parent:null;', 'var parentLayer=thisLayer.parent;');
assert.notStrictEqual(brokenFollow,img.position.expression);
img.position.expression=brokenFollow;
assert.throws(()=>evalProp(img.position,0,img),/no se puede utilizar .parent/);
run('dgRepairAttach');
assert.strictEqual(img.masks.property('YAG Dynamic Grid Clip'),intactMask,'follow repair preserves mask');
near(evalProp(img.position,0,img)[0],475,'repaired follow base x');
near(evalProp(img.position,1,img)[0],475+bounds(1).x-bounds(0).x,'repaired follow movement');
console.log('PASS 2.7.6: rig sliders; fixed reveal; follow delta; animated mask; reattach; pin centering; uniform cover; parent coords; diagnostics');
