# Yaguanimix 2.7.4 — comprobaciones de Attach

## Problema corregido

La expresión «Anclar capa a celdas» dividía un vector de Escala entre 100, provocando resultados inválidos en JavaScript y dejando la posición sin actualizar. Se cambió a una división componente por componente.

## Nueva función

**Revelar y seguir celda (sin reescalar)** mantiene posición y escala al aplicar la máscara en el cabezal. Cuando se mueve el centro de la celda, suma su desplazamiento a la Posición de la capa. La máscara sigue siempre la geometría. Se admiten capas 2D parentadas, y se puede convertir un Backdrop seleccionándolo.

## Tests de motor simulados

- `node qa/engine_dynamic_grid_273_mock.js`
- `node qa/engine_grid_follow_274_mock.js`
- `node qa/panel_grid_274_mock.js`

Estas pruebas **no** prueban el render real de After Effects. Para verificar en AE: crea un grid 3×3 en composición nueva, anima sus divisores, elige imagen y celda con «Revelar y seguir celda». En el cabezal de aplicación la imagen no debe saltar. Al moverte por el tiempo, máscara e imagen deben desplazarse juntas y la imagen debe mantener su escala. Si la capa de Posición muestra un icono de error de expresión, envía el mensaje del error.
