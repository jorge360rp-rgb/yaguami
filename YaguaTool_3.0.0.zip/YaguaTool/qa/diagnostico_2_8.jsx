// Native visual review: creates six new test comps. Does not save the project.
(function(){
    var root=File($.fileName).parent.parent;
    $.evalFile(new File(root.fsName+"/jsx/host.jsx"));
    if(!app.project)app.newProject();
    var kinds=["MRU","MRD","MRL","MRR","MSC","MDI"],created=[],errors=[],i,c,l,doc,p,r;
    app.beginUndoGroup("Yaguanimix 2.8 visual review");
    try{
        for(i=0;i<kinds.length;i++){
            c=app.project.items.addComp("Yaguanimix 2.8 · "+kinds[i],1200,700,1,6,30);c.bgColor=[.05,.055,.065];c.openInViewer();
            l=c.layers.addText("CREATE\rWITH PURPOSE");doc=l.property("ADBE Text Properties").property("ADBE Text Document");
            var value=doc.value;value.fontSize=100;value.fillColor=[1,1,1];value.applyFill=true;value.justification=ParagraphJustification.CENTER_JUSTIFY;doc.setValue(value);
            l.transform.position.setValue([600,300]);l.selected=true;
            p={kind:kinds[i],mode:"in",startAt:"layer",dur:1,delay:0,character:80,travel:24,order:"forward",stagger:.14,feather:1};
            r=JSON.parse(Animix.call("text",JSON.stringify(p)));if(!r.ok)errors.push(kinds[i]+" IN: "+r.msg);
            c.time=3;p.mode="out";r=JSON.parse(Animix.call("text",JSON.stringify(p)));if(!r.ok)errors.push(kinds[i]+" OUT: "+r.msg);
            c.time=0;created.push(c);
        }
    }catch(e){errors.push(e.message);}finally{app.endUndoGroup();}
    if(created.length)created[0].openInViewer();
    alert("Creadas "+created.length+" composiciones de revisión. Reproduce IN al inicio y OUT desde 3 s.\n"+(errors.length?errors.join("\n"):"Sin errores de aplicación. Falta revisar visualmente el resultado."));
})();
