// QA sandbox mock for Dynamic Grid v2.7: run `node qa/engine_dynamic_grid_270_mock.js`
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
class Prop {
  constructor(name,parent){this.name=name;this.parentProperty=parent||null;this.children=[];this._value=0;this.keys=[];this.expression='';this.dimensionsSeparated=false;}
  get numProperties(){return this.children.length;}
  get numKeys(){return this.keys.length;}
  get value(){return this._value;}
  valueAtTime(){return this._value;}
  get matchName(){return this.name;}
  property(k){if(typeof k==='number')return this.children[k-1]||null;return this.children.find(x=>x.name===k||x.matchName===k)||null;}
  addProperty(k){let v=new Prop(k,this);if(k==='ADBE Vector Group')v.children.push(new Prop('ADBE Vectors Group',v));
    if(k==='ADBE Vector Shape - Rect') ['ADBE Vector Rect Position','ADBE Vector Rect Size','ADBE Vector Rect Roundness'].forEach(x=>v.children.push(new Prop(x,v)));
    if(k==='ADBE Vector Shape - Ellipse') ['ADBE Vector Ellipse Position','ADBE Vector Ellipse Size'].forEach(x=>v.children.push(new Prop(x,v)));
    if(k==='ADBE Vector Graphic - Fill') ['ADBE Vector Fill Color','ADBE Vector Fill Opacity'].forEach(x=>v.children.push(new Prop(x,v)));
    if(k==='ADBE Vector Graphic - Stroke') ['ADBE Vector Stroke Color','ADBE Vector Stroke Width'].forEach(x=>v.children.push(new Prop(x,v)));
    if(k==='ADBE Mask Atom')v.children.push(new Prop('ADBE Mask Shape',v));
    if(k==='ADBE Ramp')for(let i=1;i<=4;i++)v.children.push(new Prop('Ramp'+i,v));
    this.children.push(v);return v;
  }
  remove(){if(this.parentProperty){this.parentProperty.children=this.parentProperty.children.filter(x=>x!==this);}}
  setValue(v){this._value=v;}
  setValueAtTime(t,v){let found=this.keys.find(k=>Math.abs(k.t-t)<1e-6);if(found)found.v=v;else this.keys.push({t,v});this.keys.sort((a,b)=>a.t-b.t);this._value=v;}
  setValueAtKey(k,v){this.keys[k-1].v=v;}
  keyTime(k){return this.keys[k-1].t;}
  keyValue(k){return this.keys[k-1].v;}
  removeKey(k){this.keys.splice(k-1,1);}
  setInterpolationTypeAtKey(){}
}
class Layer {
  constructor(c,type){this.c=c;this.type=type;this.name='Layer';this.comment='';this.threeDLayer=false;this.parent=null;
    this.root=new Prop('ADBE Root Vectors Group');this.effects=new Prop('ADBE Effect Parade');this.masks=new Prop('ADBE Mask Parade');
    this.position=new Prop('ADBE Position');this.opacity=new Prop('ADBE Opacity');this.scale=new Prop('ADBE Scale');this.anchor=new Prop('ADBE Anchor Point');
    this.transform={position:this.position,opacity:this.opacity,scale:this.scale,anchorPoint:this.anchor};this.label=0;this.width=1920;this.height=1080;
  }
  property(k){if(k==='ADBE Root Vectors Group')return this.root;if(k==='ADBE Effect Parade')return this.effects;
    if(k==='ADBE Mask Parade')return this.masks;if(k==='ADBE Transform Group')return {property:(p)=>p==='ADBE Position'?this.position:p==='ADBE Scale'?this.scale:null};return null;}
  remove(){this.c._layers=this.c._layers.filter(x=>x!==this);}
  moveToBeginning(){this.remove();this.c._layers.unshift(this);}
  moveToEnd(){this.remove();this.c._layers.push(this);}
  duplicate(){let l=new Layer(this.c,this.type);l.name=this.name;this.c._layers.unshift(l);return l;}
}
class CompItem {
  constructor(){this.width=1920;this.height=1080;this.duration=30;this.time=1;this.frameDuration=1/30;this.pixelAspect=1;this._layers=[];}
  get numLayers(){return this._layers.length;}
  get selectedLayers(){return this._layers.filter(x=>x.selected);}
  layer(k){return typeof k==='number'?this._layers[k-1]||null:this._layers.find(x=>x.name===k)||null;}
  get layers(){const c=this;return {addShape(){let l=new Layer(c,'shape');c._layers.unshift(l);return l;},
    addSolid(){let l=new Layer(c,'solid');c._layers.unshift(l);return l;},
    add(src){let l=new Layer(c,'footage');c._layers.unshift(l);return l;}};}
}
const comp=new CompItem(),sandbox={JSON,Math,Error,Array,CompItem,app:{project:{activeItem:comp},beginUndoGroup(){},endUndoGroup(){}},
  File:{openDialog:()=>null},ImportOptions:function(){},ImportAsType:{FOOTAGE:'FOOTAGE'},KeyframeInterpolationType:{LINEAR:'LINEAR'},isFinite};
vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../jsx/host.jsx'),'utf8'),sandbox,{filename:'host.jsx'});
function run(name,args){const r=JSON.parse(sandbox.Animix.call(name,JSON.stringify(args||{})));if(!r.ok)throw new Error(name+': '+r.msg);return r;}
function fails(name,args,part){const r=JSON.parse(sandbox.Animix.call(name,JSON.stringify(args||{})));assert.strictEqual(r.ok,false,name+' should fail');assert(r.msg.includes(part),r.msg);}
const grid={cols:3,rows:2,layout:{x:[0,.25,.65,1],y:[0,.42,1]},draw:'both',markers:true,gap:8,
  radius:12,lineWidth:2,cellOpacity:24,rim:1,cellColor:'#8975ee',lineColor:'#ffffff',markerColor:'#ffffff'};
run('dgCreate',grid);
const gl=comp.layer('Yaguanimix Dynamic Grid');assert(gl);
assert.strictEqual(run('dgStatus',{}).data.cols,3);assert.strictEqual(gl.root.numProperties,6+2+1+2);
const pathCell=gl.root.property('DG Cell 0 0').property('ADBE Vectors Group').property('DG Rect');
assert(pathCell.property('ADBE Vector Rect Size').value[0]>450);
run('dgStyle',Object.assign({},grid,{gap:12,cellOpacity:70,cellColor:'#ff9900',rim:4}));
assert.strictEqual(pathCell.property('ADBE Vector Rect Size').value[0],468);
const style=JSON.parse(gl.comment.split('YAGUANIMIX_DGRID_V1:')[1]);assert.strictEqual(style.gap,12);
run('dgAnimate',Object.assign({},grid,{motion:'Accordion',custom:false,move:.6,hold:.1,stagger:.02,easing:'Smooth',order:'row',loop:false}));
assert(pathCell.property('ADBE Vector Rect Position').numKeys>=24);
const prevKeys=pathCell.property('ADBE Vector Rect Position').numKeys;
run('dgAnimate',Object.assign({},grid,{motion:'Wave',custom:false,extend:true,move:.5,hold:0,stagger:0,easing:'Easy Ease',order:'column',loop:false}));
assert(pathCell.property('ADBE Vector Rect Position').numKeys>prevKeys);
run('dgClearAnimation');assert.strictEqual(pathCell.property('ADBE Vector Rect Position').numKeys,0);
run('dgSetLayout',Object.assign({},grid,{layout:{x:[0,.2,.6,1],y:[0,.4,1]}}));
assert.strictEqual(pathCell.property('ADBE Vector Rect Position').value[0],192);
assert.strictEqual(run('dgStatus',{}).data.layout.x[1],.2);
const textLayer=comp.layers.addShape();textLayer.name='Demo UI';textLayer.selected=true;
run('dgAttach',{targets:['c:0:0','c:0:1'],mode:'area',align:'center',clip:true});
assert(textLayer.position.expression.includes('YAGUANIMIX_DGRID_ATTACH'));
assert.strictEqual(textLayer.masks.numProperties,1);
run('dgAttach',{targets:['v:1'],mode:'area',align:'center',fit:'cover',clip:false});
assert(!textLayer.position.expression.includes('NaN'), 'vertical line expression must not refer to NaN');
assert(textLayer.scale.expression.includes('YAGUANIMIX_DGRID_FIT'));
run('dgAttach',{targets:['h:1'],mode:'area',align:'center',fit:'contain',clip:false});
assert(!textLayer.position.expression.includes('NaN'));
run('dgAttach',{targets:['d:1:1'],mode:'area',align:'center',fit:'none',clip:false});
assert(!textLayer.position.expression.includes('NaN'));
assert.strictEqual(textLayer.scale.expression, '');
fails('dgRemove',{},'ancladas');
run('dgDetach');assert.strictEqual(textLayer.position.expression,'');assert.strictEqual(textLayer.masks.numProperties,0);
run('dgBackdrop',{mode:'gradient',color1:'#111111',color2:'#dddddd',direction:'horizontal',opacity:65});
assert(comp.layer('Yaguanimix Dynamic Backdrop'));
run('dgBackdropRemove');assert(!comp.layer('Yaguanimix Dynamic Backdrop'));
run('dgRemove');assert(!comp.layer('Yaguanimix Dynamic Grid'));
console.log('OK: create, status, layout update, styles, animations, extend, clear, cells/lines/dots, attach+fit/clip, detach, backdrop, remove');
