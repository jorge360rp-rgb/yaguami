# Fix 2.7.6: acceder a .parent sin parent

Generadores Pin, Follow y Scale ahora comprueban hasParent. Nuevo comando dgRepairAttach repara expresiones preexistentes. Pruebas: node qa/engine_attach_276_mock.js; node qa/engine_grid_regressions_275_mock.js. No probado en AE real.
