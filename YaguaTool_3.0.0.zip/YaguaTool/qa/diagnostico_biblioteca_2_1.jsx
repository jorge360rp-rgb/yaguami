/* Yaguanimix v2.1 — Diagnóstico no destructivo para After Effects 2024/2025.
   Se ejecuta desde Archivo > Scripts > Ejecutar archivo de script.
   NO importa nada, no altera el proyecto ni sus composiciones. */
(function () {
    var names=["Text Animation 24.x.aep","Text Animation.aep","Dynamic Text Animation.aep"];
    var ids=["text24","text","dynamic"];
    var root=new File($.fileName).parent.parent;
    var lines=["YAGUANIMIX 2.1 — BIBLIOTECA AEP", "Fecha: "+new Date(), "AE: "+app.version, "Ruta extensión: "+root.fsName,""];
    for(var i=0;i<names.length;i++){
        var f=new File(root.fsName+"/library/"+names[i]);
        lines.push("ARCHIVO " + names[i]);
        lines.push("  Existe: " + (f.exists?"Sí":"NO"));
        if(f.exists){
            lines.push("  Bytes: " + f.length);
            var ok=false,header="";
            try{
                f.encoding="BINARY"; f.open("r");header=f.read(4);f.close();ok=(header==="RIFX");
            }catch(e){lines.push("  No se pudo leer cabecera: "+String(e));}
            lines.push("  Cabecera RIFX: " + (ok?"Sí":"NO"));
            try{
                var imp=new ImportOptions(f);
                lines.push("  Admite importación como proyecto: " + (imp.canImportAs(ImportAsType.PROJECT)?"Sí":"No detectada"));
            }catch(e2){lines.push("  Estado ImportOptions: " + String(e2));}
        }
        var n=0,tag="YAGUANO_LIBRARY_21:"+ids[i]+":";
        for(var j=1;j<=app.project.numItems;j++){
            var it=app.project.item(j);
            if(it instanceof CompItem && String(it.comment||"").indexOf(tag)===0)n++;
        }
        lines.push("  Composiciones de pack registradas en este proyecto: " + n);
        lines.push("");
    }
    lines.push("Este diagnóstico no reproduce animaciones ni demuestra compatibilidad visual.");
    var dest=new File(Folder.desktop.fsName+"/Yaguanimix_Biblioteca_2.1_QA.txt");
    try{
        dest.encoding="UTF-8";
        if(dest.open("w")){dest.write(lines.join("\r\n"));dest.close();alert("Diagnóstico completado. Informe guardado en el Escritorio: " + dest.name);}
        else alert(lines.join("\n"));
    }catch(e3){alert(lines.join("\n"));}
})();
