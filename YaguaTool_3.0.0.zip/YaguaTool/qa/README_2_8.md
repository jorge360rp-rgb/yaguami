# Pruebas 2.8.0

Desde la raíz de la extensión:

```sh
python qa/sync_mask_motion.py --check
node qa/engine_mask_280_mock.js
node qa/engine_in_out_240_mock.js
node qa/engine_260_mock.js
node qa/engine_attach_276_mock.js
node qa/engine_grid_regressions_275_mock.js
```

La prueba `engine_mask_280_mock.js` retiene la matriz de 2.7.7 y añade los nuevos diseños. `engine_text_277_mock.js` redirige a esta matriz para mantener el comando antiguo operativo. Los mocks de propiedades avanzadas incluyen ahora Based On y Smoothness de los selectores por línea.

Prueba de navegador (requiere Node, Playwright y Chromium): servir la extensión con `python -m http.server 8766` y ejecutar `node qa/studio_280_browser.js`. Variables opcionales: YAGUANIMIX_TEST_URL, CHROMIUM_PATH, YAGUANIMIX_CAPTURE_DIR. Las capturas se guardan por defecto en `/tmp/yaguanimix-280`.

Se han comprobado 280, 320, 380, 768 y 1340 px. El test verifica montaje, navegación y ausencia de desbordamiento del contenedor. Las capturas claro, oscuro y acoplado se inspeccionan además visualmente; el test de anchura no equivale a una auditoría de cada componente en todos sus estados.

## Pruebas históricas

Los scripts de versiones anteriores a 2.7.6 se conservan como historial y no constituyen todos ellos criterios actuales. `engine_grid_follow_274_mock.js` y `engine_dynamic_grid_273_mock.js` fallan también en 2.7.7: esperan identificadores de expresiones que el motor de Attach ya cambió. No se presentan como regresiones nuevas ni como pruebas superadas. `engine_250_mock.js` y `panel_smoke_test.js` tienen asimismo expectativas obsoletas documentadas en la revisión 2.7.7.

## Prueba nativa pendiente

En un proyecto de prueba, ejecutar `qa/diagnostico_2_8.jsx` desde Archivo > Secuencias de comandos > Ejecutar archivo. Crea seis composiciones con IN y OUT, sin guardar ni sobrescribir un proyecto. El script usa la copia de host.jsx de esta carpeta.

Revisar: silueta y desplazamiento; salida por líneas; Split Slide y sus franjas; orden normal/inverso/centro/alterno; intensidad/desplazamiento/cadencia cero; conservación de una fase al sustituir la otra; máscaras y keyframes previos; render PNG en Windows/macOS con permisos activados/desactivados. Probar las tres apariencias del panel y navegación por teclado dentro de CEP.

No se ha ejecutado esta prueba nativa en el entorno de desarrollo.
