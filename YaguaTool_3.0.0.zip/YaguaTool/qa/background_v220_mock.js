// Yaguanimix 2.2: pruebas simuladas de construcción, edición y color por pixel.
// No reemplaza un render real en AE 2024/2025.
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
let count=0,failRamp=false;
class Property{
 constructor(name,parent){this.name=name;this.matchName=name;this.parent=parent;this.items=[];this.value=null;this.expression='';this.keys=[]}
 get numKeys(){return this.keys.length}
 get numProperties(){return this.items.length}
 property(x){return typeof x==='number'?this.items[x-1]||null:this.items.find(y=>y.name===x ||y.matchName===x)||null}
 addProperty(match){
  if(failRamp&&match==='ADBE Ramp')throw Error('Error simulado Gradient Ramp');
  let p=new Property(match,this);this.items.push(p);
  const n=match==='ADBE Ramp'?7:match==='ADBE Color Control'||match==='ADBE Slider Control'?1:0;
  for(let i=0;i<n;i++)p.items.push(new Property(match+'_'+(i+1),p));
  return p;
 }
 setValue(v){this.value=v}
 setValueAtTime(t,v){this.keys.push([t,v]);this.value=v}
 remove(){if(this.parent)this.parent.items=this.parent.items.filter(x=>x!==this)}
}
class Layer{
 constructor(c,name,color){this.c=c;this.name=name;this.color=color;this.id=++count;this.inPoint=0;this.outPoint=c.duration;this.comment='';this.enabled=true;this.blendingMode='NORMAL';this.transform={opacity:new Property('opacity',null)};this.transform.opacity.value=100;
  this.effects=new Property('ADBE Effect Parade',null);this.source={width:c.width,height:c.height};this.selected=false;}
 property(name){return name==='ADBE Effect Parade'?this.effects:null}
 moveToEnd(){this.c.arr=this.c.arr.filter(x=>x!==this);this.c.arr.push(this)}
 remove(){this.c.arr=this.c.arr.filter(x=>x!==this)}
}
class CompItem{
 constructor(w=1080,h=1920){this.width=w;this.height=h;this.pixelAspect=1;this.duration=11;this.time=0;this.arr=[];
  this.layers={
   addSolid:(rgb,name,w,h)=>{assert.equal(w,this.width);assert.equal(h,this.height);let l=new Layer(this,name,rgb);this.arr.unshift(l);return l;},
   addNull:()=>{let l=new Layer(this,'Null',null);this.arr.unshift(l);return l;}
  };
 }
 get numLayers(){return this.arr.length}
 layer(x){return typeof x==='number'?this.arr[x-1]:this.arr.find(l=>l.name===x)}
 get selectedLayers(){return this.arr.filter(l=>l.selected)}
}
const current=new CompItem();const textLayer=new Layer(current,'User TEXT',null);current.arr.push(textLayer);textLayer.selected=true;
const sandbox={app:{project:{activeItem:current},beginUndoGroup(){},endUndoGroup(){}},
 CompItem,TextLayer:Layer,ShapeLayer:Layer,BlendingMode:{MULTIPLY:'MULTIPLY',SCREEN:'SCREEN',NORMAL:'NORMAL'},
 JSON,Math,Error,isNaN,Number,String,parseInt,Date};
vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../jsx/host.jsx'),'utf8'),sandbox);
const call=(n,o)=>JSON.parse(sandbox.Animix.call(n,JSON.stringify(o)));
const originalCount=current.numLayers;
const bg=()=>current.arr.filter(l=>l.name.startsWith('Animix BG - '));
const ctrl=()=>bg().find(l=>l.name.startsWith('Animix BG - CONTROLES'));
const colnames=['Yaguano BG Principal','Yaguano BG Secundario','Yaguano BG Acento'];
const evalExpr=(p,t)=>{
 if(!p.expression)return p.value;
 const context={Math,time:t,thisComp:{layer:(name)=>{
  const l=current.layer(name);if(!l)throw Error('no control layer '+name);
  return {effect:(fxName)=>{const f=l.effects.property(fxName);if(!f)throw Error('no control '+fxName);return (num)=>f.property(num).value;}};
 }}};
 return vm.runInNewContext(p.expression,context);
};
function sample(x,y,t){
 // Read the actual Ramp expressions, not the intended palette configuration.
 let layers=bg().slice().reverse(),v=[0,0,0];
 for(const l of layers){
  if(l.name.includes('Base 2.2')){v=l.color.slice();continue}
  if(!l.name.includes('Luz'))continue;
  const f=l.effects.property(1),start=evalExpr(f.property(1),t),end=evalExpr(f.property(3),t),rgb=evalExpr(f.property(2),t);
  const rr=Math.hypot(end[0]-start[0],end[1]-start[1]);
  const k=Math.min(1,Math.hypot(x-start[0],y-start[1])/rr);
  const neutral=evalExpr(f.property(4),t);const glow=rgb.map((n,i)=>n*(1-k)+neutral[i]*k);
  const a=evalExpr(l.transform.opacity,t)/100;
  v=v.map((ch,i)=>{const blend=l.blendingMode==='MULTIPLY'?ch*glow[i]:1-(1-ch)*(1-glow[i]);return (1-a)*ch+a*blend;});
 }
 return v;
}
function dist(a,b){return Math.sqrt(a.reduce((s,v,i)=>s+(v-b[i])**2,0))}
function format(a){return a.map(x=>x.toFixed(3)).join(',')}
const opts={style:'minimal',color1:'#00ff00',color2:'#ff0000',accent:'#0000ff',intensity:85,speed:1.2};
for(const style of ['minimal','gradient','aurora','dark']){
 const r=call('background',{...opts,style});assert(r.ok,style+': '+r.msg);
 assert.equal(bg().length,5,'base + 3 lights + null');
 assert.equal(current.numLayers,originalCount+5,'no stacking');
 assert.equal(current.layer(1),textLayer,'background must stay BELOW user text');
 assert(bg().every(l=>l.source.width===current.width && l.source.height===current.height));
 assert(ctrl(),'controller missing');
 const lights=bg().filter(l=>l.name.includes('Luz')).reverse();
 assert.equal(lights.length,3);
 for(const [i,l] of lights.entries()){
  const f=l.effects.property(1);assert.equal(f.matchName,'ADBE Ramp');assert.equal(f.property(5).value,2);
  for(const j of [1,3,2]){
   assert(f.property(j).expression.includes('YAGUANO_BG_220'));
   assert.doesNotThrow(()=>evalExpr(f.property(j),1),'expression must evaluate');
  }
  assert.equal(l.blendingMode,style==='minimal'?'MULTIPLY':'SCREEN');
  assert.equal(f.property(2).expression.includes(colnames[i]),true);
  assert.deepEqual(f.property(4).value.slice(0,3),style==='minimal'?[1,1,1]:[0,0,0]);
 }
 const s1=sample(current.width*.22,current.height*.3,0);
 const s2=sample(current.width*.80,current.height*.75,0);
 assert(dist(s1,s2)>.015,style+': background appears flat '+format(s1)+' '+format(s2));
 const before=[sample(current.width*.25,current.height*.33,2.1),sample(current.width*.8,current.height*.75,2.1)];
 const n=bg().map(l=>l.id).sort();
 const changed=call('backgroundUpdate',{...opts,style,color1:'#ff00ff',color2:'#00ffff',accent:'#ffff00',intensity:95,speed:1.5});
 assert(changed.ok,changed.msg);assert(changed.data.updated);
 assert.deepEqual(bg().map(l=>l.id).sort(),n,'editing colors must NOT rebuild');
 for(let k=0;k<3;k++)assert.deepEqual(ctrl().effects.property(colnames[k]).property(1).value.slice(0,3),[[1,0,1],[0,1,1],[1,1,0]][k]);
 const after=[sample(current.width*.25,current.height*.33,2.1),sample(current.width*.8,current.height*.75,2.1)];
 assert(before.some((p,j)=>dist(p,after[j])>.05),style+': new UI colors invisible');
 const moved=sample(current.width*.25,current.height*.33,5.8);
 assert(dist(after[0],moved)>.0005,style+': no movement over time');
 console.log(style, '✓ three editable colors, visible palette, move, full-frame',format(before[0]),'=>',format(after[0]));
}
// Applying again must keep only 5 BG layers while preserving content.
let keep=bg().map(l=>l.id);
assert(call('background',{...opts,style:'gradient'}).ok);
assert(bg().every(l=>!keep.includes(l.id))&&bg().length===5);
// A failure should keep all existing layers and NOT leave partially created lights.
keep=bg().map(l=>l.id).sort();failRamp=true;
let failed=call('background',{...opts,style:'minimal'});
assert(!failed.ok,'we simulated a native effect failure');
assert.deepEqual(bg().map(l=>l.id).sort(),keep,'restore old background after failure');
failRamp=false;
let deleted=call('background',{remove:true});assert(deleted.ok,deleted.msg);
assert.equal(current.numLayers,originalCount,'cleanup must not touch user layers');
assert.equal(call('backgroundUpdate',opts).data.updated,false);
// Legacy background auto migration.
let legacy=current.layers.addSolid([1,1,1],'Animix BG - Pearl Bloom',1080,1920);
assert(call('backgroundUpdate',opts).ok);assert.equal(bg().length,5);assert(!bg().includes(legacy));
console.log('PASS: 4 styles, all 3 colours live, separate old layers, rollback, clean removal, legacy migration.');
