## Actualización 2.7.3

Pruebas nuevas: `node qa/panel_grid_273_mock.js` y `node qa/engine_dynamic_grid_273_mock.js`. Las pruebas antiguas 2.7.0/2.7.1 son históricas y no reflejan la arquitectura actual de divisores ni el modo de máscara fija.

# QA — Yaguanimix 2.7 Dynamic Grid

## Pruebas fuera de After Effects

- `node qa/panel_grid_271_mock.js`: carga y navegación del panel, Grid Pro, selección por arrastre, presets y controles de ajuste.
- `node qa/engine_dynamic_grid_270_mock.js`: creación de shapes, geometría, estilos, animación, extensión de keyframes, limpieza, anclaje + máscara, desvinculación, gradiente y borrado.
- `node qa/engine_260_mock.js`: barridos de color, blur, zoom y herramientas previas; sin regresión en las pruebas de motor correspondientes.
- Interfaz comprobada con Chromium/Playwright: diez secciones, cuatro pestañas Grid/Animate/Backdrop/Attach, seis layouts y once presets de movimiento. Sin excepciones de JS durante navegación de prueba.

Estas pruebas usan mocks de la API de AE: no prueban el motor de render, ni el evaluador real de expresiones ni el resultado visual.

## Prueba real en After Effects 2024 / 2025

1. Abre AE y crea/guarda un proyecto de prueba.
2. Ejecuta **Archivo → Scripts → Ejecutar archivo de script**, elige `qa/diagnostico_dynamic_grid_2_7.jsx`.
3. Se crea la comp `YAGUANIMIX_DG_DIAGNOSTICO_2_7` con grid, texto, animación y fondo. Se guarda un informe en el Escritorio.
4. Inspecciona el visor, reproduce el grid, ajusta un divisor y comprueba que la capa de texto sigue el movimiento.
5. Prueba manualmente las 32 curvas, la máscara en clips e imágenes, la importación de vídeo y los parentados/3D: los mocks no validan estos casos.

**Limitaciones:** el recorte solo funciona con capas 2D y destinos de celdas; se rechazan capas con expresiones preexistentes de Posición y Separate Dimensions para no sobrescribir trabajos. Al cambiar filas/columnas con capas adjuntas, primero desvincúlalas. No se ha certificado esta versión en AE real.

## Correcciones 2.7.1 verificadas por tests (no equivalen a render real)

- Marcadores construidos sin utilizar referencias AE invalidadas al añadir propiedades indexadas.
- Las líneas verticales usan su índice real en expresiones (`v:1`, no `NaN`).
- Nuevo comando `dgSetLayout`: geometría actualizada sin destruir keyframes. `dgStatus`: lee el grid de la composición.
- Anclaje `cover`/`contain` por escala, 2D; remueve el ajuste en `detach`, preservando su aspecto al cabezal.
- Celdas y líneas seleccionables con arrastre aunque cambie el modo de dibujo.
- Regresión: otros mocks independientes de 2.6 funcionan; dos tests heredados de 2.6 ya fallaban sin modificaciones por un cambio en navegación y un conteo de animadores.

**Aviso:** si ya tienes grids creados con 2.7, guarda una copia del proyecto antes de actualizar. Las expresiones de 2.7 siguen operativas si la capa se conserva con su nombre. El modo Cover/Contain en capas parentadas con escalas no uniformes o 3D tiene restricciones; comprueba el resultado en el visor real.
