/* Yaguanimix 2.7.1 diagnostic: run via Archivo > Scripts > Ejecutar archivo de script.
   Creates an independent test composition; never modifies the active composition. */
(function(){
    var report=[], compTest=null, file=null;
    function record(s){report.push(s);}
    function go(n,args){var r=JSON.parse(Animix.call(n,JSON.stringify(args||{})));record(n+": "+(r.ok?"OK - ":"ERROR - ")+r.msg);if(!r.ok)throw new Error(r.msg);return r;}
    try{
        var dir=File($.fileName).parent.parent;
        $.evalFile(new File(dir.fsName+"/jsx/host.jsx"));
        app.beginUndoGroup("Yaguanimix 2.7.1 Dynamic Grid diagnostic");
        compTest=app.project.items.addComp("YAGUANIMIX_DG_DIAGNOSTICO_2_7",1280,720,1,12,30);
        compTest.openInViewer();
        var cfg={cols:3,rows:3,layout:{x:[0,.25,.60,1],y:[0,.20,.70,1]},draw:"both",markers:true,
          gap:10,radius:14,lineWidth:2,cellOpacity:30,rim:1,cellColor:"#8b7bff",lineColor:"#ffffff",markerColor:"#ffffff"};
        go("dgCreate",cfg);
        var read=go("dgStatus",{});
        if(!read.data||read.data.cols!==3)throw new Error("No se puede recuperar la configuración del grid.");
        var newCfg=JSON.parse(JSON.stringify(cfg));newCfg.layout.x=[0,.27,.62,1];
        go("dgSetLayout",newCfg);
        var gl=compTest.layer("Yaguanimix Dynamic Grid");
        if(!gl)throw new Error("La capa del grid no se ha creado.");
        record("Forma creada: "+gl.property("ADBE Root Vectors Group").numProperties+" grupos");
        var text=compTest.layers.addText("Dynamic Grid · Yaguanimix");text.selected=true;gl.selected=false;
        go("dgAttach",{mode:"area",targets:["v:1"],align:"center",clip:false});
        if(text.transform.position.expression.indexOf("NaN")>=0)throw new Error("Anclaje vertical inválido");
        go("dgAttach",{mode:"area",targets:["c:1:0","c:1:1"],align:"center",fit:"contain",clip:false});
        record("Posición con expresión: "+String(text.transform.position.expression).substr(0,90));
        record("Escala con expresión: "+String(text.transform.scale.expression).substr(0,70));
        try{record("Errores en expresiones: "+(text.transform.position.expressionError||"Ninguno")+" | "+(text.transform.scale.expressionError||"Ninguno"));}catch(ignore){}
        go("dgAnimate",{motion:"Accordion",easing:"Smooth",move:.6,hold:.2,stagger:.01,order:"row",custom:false,loop:false});
        var cell=gl.property("ADBE Root Vectors Group").property("DG Cell 0 0").property("ADBE Vectors Group").property("DG Rect");
        record("Keyframes celda 0,0: "+cell.property("ADBE Vector Rect Position").numKeys);
        go("dgBackdrop",{mode:"gradient",color1:"#151c39",color2:"#5047a1",direction:"diagonal",opacity:100});
        record("Fondo creado: "+String(!!compTest.layer("Yaguanimix Dynamic Backdrop")));
        go("dgDetach");
        record("DIAGNÓSTICO FINALIZADO · prueba la vista previa y comprueba los cambios de layout y las expresiones.");
    }catch(e){record("FALLO: "+String(e));}
    finally{
        try{app.endUndoGroup();}catch(e2){}
        try{
          file=new File(Folder.desktop.fsName+"/Yaguanimix_Dynamic_Grid_2_7_diagnostico.txt");file.encoding="UTF-8";file.open("w");
          file.writeln(report.join("\n"));file.close();alert("Diagnóstico guardado en el Escritorio:\n"+file.fsName);
        }catch(e3){alert(report.join("\n"));}
    }
})();
