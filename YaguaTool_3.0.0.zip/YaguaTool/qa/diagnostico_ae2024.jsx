// Yaguanimix 2.0.0 · Diagnóstico de AE 2024/2025 (ejecutar desde Archivo > Scripts).
// Crea UNA composición nueva de prueba. No modifica capas de proyectos existentes.
(function(){
    var host = new File(File($.fileName).parent.parent.fsName + '/jsx/host.jsx');
    var definitions = new File(File($.fileName).parent.parent.fsName + '/js/data.js');
    if (!host.exists || !definitions.exists){alert('No se encuentran los scripts de Yaguanimix.');return;}
    var results=[],errs=0,ok=0;
    function test(label, fn, opts){
        try{var r=JSON.parse(Animix.call(fn,JSON.stringify(opts||{})));
            if(!r.ok)throw new Error(r.msg);results.push('OK   '+label+' · '+r.msg);ok++;
        }catch(e){results.push('ERROR '+label+' · '+e.toString());errs++;}
    }
    // El panel puede construir un preset y, aun así, AE puede rechazar una
    // expresión hasta evaluarla. Este segundo chequeo lo detecta en el motor real.
    function inspectExpressions(label,layer){
        var found=0,bad=0;
        function visit(p){
            if(!p)return;
            try{
                if(p.propertyType===PropertyType.PROPERTY){
                    if(p.canSetExpression && p.expression && p.expression.length){
                        found++;
                        try{p.valueAtTime(Math.max(0,Math.min(1,layer.outPoint-.01)),false);}catch(renderProblem){}
                        var err='';try{err=p.expressionError||'';}catch(readProblem){}
                        if(err){bad++;errs++;results.push('ERROR expresión '+label+' · '+p.name+' · '+err);}
                    }
                }else{
                    for(var j=1;j<=p.numProperties;j++)visit(p.property(j));
                }
            }catch(unavailable){}
        }
        try{for(var q=1;q<=layer.numProperties;q++)visit(layer.property(q));}
        catch(top) {results.push('AVISO evaluación '+label+' · '+top.toString());}
        if(found)results.push((bad?'REVISAR ':'OK   ')+'Expresiones '+label+' · '+found+' evaluadas, '+bad+' errores');
    }
    app.beginUndoGroup('Yaguanimix · Diagnóstico');
    try {
        $.evalFile(host);$.evalFile(definitions);
        var c=app.project.items.addComp('YAGUANIMIX_QA_2024',1080,1920,1,6,25);
        c.openInViewer();
        var base=c.layers.addText('Motion de prueba\rSegunda línea');
        base.selected=true;
        for(var i=0;i<TEXT_PRESETS.length;i++){
            var p=TEXT_PRESETS[i],layer=c.layers.addText('Línea 1\rLínea 2'),o={kind:p.id,startAt:'layer',ease:55},j;
            try{base.selected=false;}catch(e){}
            for(j=1;j<=c.numLayers;j++)c.layer(j).selected=false;
            layer.selected=true;
            for(j=0;j<p.params.length;j++)o[p.params[j].k]=p.params[j].def;
            // Apple: probar sin el destello opcional; se prueba por separado.
            o.lightAccent=false;
            test('Texto '+p.id,'text',o);
            inspectExpressions('Texto '+p.id,layer);
            layer.selected=false;
        }
        var two=c.layers.addText('Primera línea\rSegunda línea');
        for(var z=1;z<=c.numLayers;z++)c.layer(z).selected=false;
        two.selected=true;
        test('Color Sweep · dos líneas','colorSweep',{colors:['#e7bd9a','#f4a16c','#eb5d6a'],startAt:'layer',mode:'in',dur:.95,band:68,feather:.7,separation:.60,colorPower:48,glow:12,lineMode:'sequential',lineGap:.1,blur:'soft',reveal:'follow'});
        inspectExpressions('Color Sweep (texto)',two);
        test('Color Sweep · quitar','removeSweep',{});
        two.selected=false;
        var modes=['minimal','gradient','aurora','dark'];
        for(var m=0;m<modes.length;m++){
            test('Fondo '+modes[m],'background',{style:modes[m],speed:1,intensity:65,color1:'#1261f4',color2:'#76ddff',accent:'#aa88ff'});
            for(var b=1;b<=c.numLayers;b++)if(c.layer(b).name.indexOf('Animix BG - ')===0)inspectExpressions('Fondo '+modes[m],c.layer(b));
        }
        test('Fondo · quitar','background',{remove:true});
        // Previews realmente procesadas por AE, no por CSS.
        test('Preview real de máscaras','previewText',{kind:'MRU',params:{dur:.85,stagger:.1,feather:2,mode:'in'}});
        test('Preview real de Color Sweep','previewSweep',{colors:['#e7bd9a','#f4a16c','#eb5d6a'],band:68,colorPower:48,glow:12,dur:1,mode:'in',blur:'soft',lineMode:'all'});
        results.unshift('Yaguanimix 2.0.0 / After Effects '+app.version+' / Correctas '+ok+' / Errores '+errs);
        var f=new File(Folder.desktop.fsName+'/Yaguanimix_Diagnostico.txt');
        if(f.open('w')){f.write(results.join('\n'));f.close();}
        alert('Diagnóstico finalizado. Pruebas correctas: '+ok+' · errores: '+errs+'\nInforme: Escritorio/Yaguanimix_Diagnostico.txt');
    }catch(e){alert('No se pudo completar el diagnóstico: '+e.toString());}
    try{app.endUndoGroup();}catch(u){}
})();
