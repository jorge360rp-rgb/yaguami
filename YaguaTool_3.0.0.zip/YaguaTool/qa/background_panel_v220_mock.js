const fs=require('fs'),vm=require('vm'),path=require('path');
const extensionRoot=path.resolve(__dirname,'..');
class E {
 constructor(tag,id){this.tagName=tag;this.id=id||'';this.children=[];this.attrs={};this.handlers={};this.value='';this.scrollTop=0;this.style={setProperty:(...x)=>{},cssText:'',getPropertyValue:(n)=>'#888'};this.className='';this.hidden=false;this.classList={add:()=>{},remove:()=>{},toggle:()=>{}};}
 appendChild(c){if(c==null)throw Error('append null to '+this.tagName);this.children.push(c);return c;}
 setAttribute(k,v){this.attrs[k]=v; if(k==='value')this.value=v;}
 addEventListener(k,cb){(this.handlers[k]=this.handlers[k]||[]).push(cb);}
 getContext(){return new Proxy({},{get:(o,k)=>k==='getImageData'?(()=>({data:new Uint8ClampedArray(100)})):(()=>{}) ,set:()=>true});}
 getBoundingClientRect(){return {width:300,height:200,left:0,top:0};}
 querySelector(selector){const match=(n)=> selector[0]==='.'? String(n.className).split(' ').includes(selector.slice(1)):selector[0]==='['?n.attrs[selector.slice(1,-1)]!==undefined:n.tagName===selector;return deep(this).find(match)||null;}
 querySelectorAll(selector){const match=(n)=> selector[0]==='.'?String(n.className).split(' ').includes(selector.slice(1)):selector[0]==='['?n.attrs[selector.slice(1,-1)]!==undefined:n.tagName===selector;return deep(this).filter(match);}
 set innerHTML(v){this.children=[];this._html=v;}
 get innerHTML(){return this._html||'';}
 set textContent(v){this.children=[];this._txt=v;}
 get textContent(){return this._txt||this.children.map(c=>c.textContent||'').join('');}
 remove(){}
}
function deep(node){let out=[];for(const c of node.children){out.push(c);if(c instanceof E)out.push(...deep(c))};return out;}
const ids={};['page','tabs','viewer','ctx','toast'].forEach(id=>ids[id]=new E('div',id));const doc={body:new E('body'),documentElement:new E('html'),createElement:n=>new E(n),createTextNode:s=>({tagName:'#text',textContent:String(s)}),getElementById:k=>ids[k],querySelectorAll:s=>deep(doc.body).filter(x=>x.tagName===s),addEventListener:()=>{}};
const calls=[]; const w={addEventListener:()=>{},location:{},setTimeout,clearTimeout,__adobe_cep__:{evalScript:(script,callback)=>{calls.push(script); callback(JSON.stringify({ok:true,msg:'Fondos actualizados',data:{updated:true}}));}}};
const store=new Map(); const localStorage={getItem:k=>store.get(k),setItem:(k,v)=>store.set(k,v),removeItem:k=>store.delete(k)};
const sandbox={window:w,document:doc,localStorage,setTimeout,clearTimeout,console,getComputedStyle:()=>({getPropertyValue:()=> '#888'}),Math,Date,JSON,Number,String,Array,parseInt,Promise,alert:()=>{},confirm:()=>true,prompt:()=>'',Image:function(){},FileReader:function(){}};
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(extensionRoot+'/js/data.js','utf8'),sandbox,{filename:'data.js'});
vm.runInContext(fs.readFileSync(extensionRoot+'/js/aep-library.js','utf8'),sandbox,{filename:'aep-library.js'});
vm.runInContext(fs.readFileSync(extensionRoot+'/js/main.js','utf8'),sandbox,{filename:'main.js'});
let tabs=ids.tabs.children; if(tabs.length!==9)throw Error('Expected 9 tabs, got '+tabs.length);
console.log('startup OK; tabs:',tabs.map(t=>t.textContent));
for(let i=0;i<9;i++){
  tabs=ids.tabs.children;const b=tabs[i]; const label=b.textContent;
  const cb=b.handlers.click?.[0]; if(!cb)throw Error('no tab handler');
  cb({});const count=deep(ids.page).length;
  if(count<10) throw Error(label+' incomplete page '+count);
  console.log(label, 'DOM nodes',count);
}
const pick=ids.tabs.children[0];pick.handlers.click[0]({});
const chips=deep(ids.page).filter(x=>x instanceof E&&String(x.className).includes('chip'));
console.log('preset chips',chips.length);
if(chips.length<5)throw Error('no presets');
for (const i of [1,2,3,4,5,6,7,8,9,10]){
 ids.tabs.children[0].handlers.click[0]({});
 const c=deep(ids.page).filter(x=>x instanceof E&&String(x.className).split(' ').includes('chip'));
 if(i<c.length)c[i].handlers.click[0]({});
}
console.log('all smoke tests PASSED');

(async function testNativeBgUi(){
  const bg=ids.tabs.children[3]; bg.handlers.click[0]({});
  const inputs=deep(ids.page).filter(x=>x instanceof E && x.tagName==='input' && x.attrs.type==='color');
  if(inputs.length!==3) throw Error('Expected 3 color controls, got '+inputs.length);
  for(let i=0;i<inputs.length;i++){
    inputs[i].value=['#ff0000','#00ff00','#0000ff'][i];
    for(const fn of (inputs[i].handlers.input||[]))fn({target:inputs[i]});
    for(const fn of (inputs[i].handlers.change||[]))fn({target:inputs[i]});
  }
  await new Promise(r=>setTimeout(r,340));
  if(!calls.some(x=>x.includes('backgroundUpdate')))throw Error('colors did not call AE backgroundUpdate');
  const backgrounds=calls.filter(x=>x.includes('backgroundUpdate'));
  if(!backgrounds.some(x=>x.includes('#ff0000')&&x.includes('#00ff00')&&x.includes('#0000ff')))
    throw Error('AE did not receive all three new colors');
  const buttons=deep(ids.page).filter(x=>x instanceof E&&x.tagName==='button');
  const update=buttons.find(b=>b.textContent==='Actualizar colores en AE');
  const create=buttons.find(b=>b.textContent==='Crear / Reemplazar fondo');
  if(!update||!create) throw Error('missing create / explicit update controls');
  update.handlers.click[0]({}); create.handlers.click[0]({});
  await new Promise(r=>setTimeout(r,30));
  if(!calls.some(x=>x.includes('Animix.call("background"')))throw Error('create BG not wired to host');
  console.log('PASS: panel 3 color pickers => live native update, create + update buttons connected');
})().catch(e=>{console.error(e);process.exitCode=1});
