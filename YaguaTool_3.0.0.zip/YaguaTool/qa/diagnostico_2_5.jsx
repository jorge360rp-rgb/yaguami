/* Yaguanimix 2.5 · diagnostico nativo AE 2024/2025.
   Crea solo una composición nueva de prueba, NO modifica las composiciones existentes. */
(function () {
    var report = [], pass = 0, fail = 0, qa = null;
    function record(label, result) { report.push((result.ok ? "OK: " : "ERROR: ") + label + " — " + result.msg); if (result.ok) pass++; else fail++; }
    function invoke(name, o, label) {
        var r;
        try { r=JSON.parse(Animix.call(name,JSON.stringify(o||{}))); }
        catch(e){r={ok:false,msg:String(e)};}
        record(label||name,r); return r;
    }
    function selectedOnly(l) {
        var i;for(i=1;i<=qa.numLayers;i++)try{qa.layer(i).selected=false;}catch(ignore){}
        l.selected=true;
    }
    try {
        if(!app.project)app.newProject();
        var srcFile=new File(File($.fileName).parent.parent.fsName+"/jsx/host.jsx");
        if(!srcFile.exists)throw new Error("No se encontró jsx/host.jsx. Ejecuta el script dentro de qa/ del paquete descomprimido.");
        $.evalFile(srcFile);
        qa=app.project.items.addComp("YAGUANO QA 2.5 — BORRAR AL TERMINAR",960,540,1,12,30);
        qa.openInViewer();qa.time=0;
        var l=qa.layers.addText("Yaguano\rMotion");l.name="QA — Texto de dos líneas";
        l.outPoint=11;
        var docP=l.property("ADBE Text Properties").property("ADBE Text Document"),d=docP.value;
        d.fontSize=105;d.applyFill=true;d.fillColor=[.92,.91,.94];docP.setValue(d);
        l.transform.position.setValue([170,250]);
        selectedOnly(l);
        var styles=["silk","chrome","prism","scan"],i,r,an,fxp,exprs;
        for(i=0;i<styles.length;i++){
            qa.time=1;
            r=invoke("styleSweep",{style:styles[i],dur:1.2,startAt:"cti",width:20,feather:110,power:68,colors:["#a8f1ec","#c5a5f0","#f3a3b9"],sequential:true,lineGap:.1},"Barrido "+styles[i]);
            if(r.ok){
                an=l.property("ADBE Text Properties").property("ADBE Text Animators");exprs=0;
                for(var j=1;j<=an.numProperties;j++){
                    var a=an.property(j);
                    if(a.name.indexOf("Animix StyleSweep ")===0){
                        exprs++;
                        try{var se=a.property("ADBE Text Selectors").property(1).property("ADBE Text Expressible Amount")||a.property("ADBE Text Selectors").property(1).property(1);
                            if(se.expressionError)report.push("AVISO expresión "+styles[i]+": "+se.expressionError);
                        }catch(error){report.push("AVISO: no se pudo leer selector "+String(error));}
                    }
                }
                if(exprs!==3){fail++;report.push("ERROR: "+styles[i]+" generó "+exprs+" animadores (esperados 3)");}
            }
        }
        invoke("removeStyleSweep",{},"Quitar Studio (conservar texto)");
        qa.time=2;
        invoke("textZoom",{phase:"in",direction:"in",strength:22,dur:.7},"Zoom IN");
        qa.time=6;
        invoke("textZoom",{phase:"out",direction:"out",strength:30,dur:1.0},"Zoom OUT");
        invoke("removeTextZoom",{phase:"in"},"Quitar solo Zoom IN");
        qa.time=4;
        invoke("toolMarker",{tag:"in"},"Marcador IN");
        invoke("toolRename",{prefix:"QA_Text_",first:1},"Renombrar capa");
        invoke("toolTrim",{side:"in"},"Recortar IN a cabezal");
        report.push("La composición 'YAGUANO QA 2.5' permanece disponible para revisar el render, y puedes borrarla manualmente.");
    } catch (e) { fail++; report.push("ERROR CRÍTICO: "+String(e)); }
    var body="YAGUANIMIX 2.5 — DIAGNÓSTICO AE\rFecha: "+(new Date()).toString()+"\rOK: "+pass+"  Errores: "+fail+"\r\r"+report.join("\r");
    try { var file=new File(Folder.desktop.fsName+"/Yaguano_diagnostico_2_5.txt");if(file.open("w")){file.write(body);file.close();alert("Diagnóstico completado: "+pass+" OK / "+fail+" errores.\nInforme en Escritorio.");}else alert(body); }
    catch (x) { alert(body); }
})();
