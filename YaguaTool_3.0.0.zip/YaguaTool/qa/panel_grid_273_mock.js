const fs=require('fs'),vm=require('vm'),path=require('path');
const extensionRoot=path.resolve(__dirname,'..');
class E {
 constructor(tag,id){this.tagName=tag;this.id=id||'';this.children=[];this.attrs={};this.handlers={};this.value='';this.scrollTop=0;this.style={setProperty:(...x)=>{},cssText:'',getPropertyValue:(n)=>'#888'};this.className='';this.hidden=false;this.classList={add:()=>{},remove:()=>{},toggle:()=>{}};}
 appendChild(c){if(c==null)throw Error('append null to '+this.tagName);this.children.push(c);return c;}
 setAttribute(k,v){this.attrs[k]=v; if(k==='value')this.value=v;}
 getAttribute(k){return this.attrs[k];}
 addEventListener(k,cb){(this.handlers[k]=this.handlers[k]||[]).push(cb);}
 getContext(){return new Proxy({},{get:(o,k)=>k==='getImageData'?(()=>({data:new Uint8ClampedArray(100)})):(()=>{}) ,set:()=>true});}
 getBoundingClientRect(){return {width:300,height:200,left:0,top:0};}
 querySelector(selector){const match=(n)=> selector[0]==='.'? String(n.className).split(' ').includes(selector.slice(1)):selector[0]==='['?n.attrs[selector.slice(1,-1)]!==undefined:n.tagName===selector;return deep(this).find(match)||null;}
 querySelectorAll(selector){const match=(n)=> selector[0]==='.'?String(n.className).split(' ').includes(selector.slice(1)):selector[0]==='['?n.attrs[selector.slice(1,-1)]!==undefined:n.tagName===selector;return deep(this).filter(match);}
 set innerHTML(v){this.children=[];this._html=v;}
 get innerHTML(){return this._html||'';}
 set textContent(v){this.children=[];this._txt=v;}
 get textContent(){return this._txt||this.children.map(c=>c.textContent||'').join('');}
 remove(){}
}
function deep(node){let out=[];for(const c of node.children){out.push(c);if(c instanceof E)out.push(...deep(c))};return out;}
const docHandlers={};
const ids={};['page','tabs','viewer','ctx','toast','nav-shade'].forEach(id=>ids[id]=new E('div',id));const doc={body:new E('body'),documentElement:new E('html'),createElement:n=>new E(n),createElementNS:(ns,n)=>new E(n),createTextNode:s=>({tagName:'#text',textContent:String(s)}),getElementById:k=>ids[k],querySelectorAll:s=>deep(doc.body).filter(x=>x.tagName===s),addEventListener:(name,cb)=>{(docHandlers[name]=docHandlers[name]||[]).push(cb);}};
const w={addEventListener:()=>{},location:{},setTimeout,clearTimeout};
const store=new Map(); const localStorage={getItem:k=>store.get(k),setItem:(k,v)=>store.set(k,v),removeItem:k=>store.delete(k)};
const sandbox={window:w,document:doc,localStorage,setTimeout,clearTimeout,console,getComputedStyle:()=>({getPropertyValue:()=> '#888'}),Math,Date,JSON,Number,String,Array,parseInt,Promise,alert:()=>{},confirm:()=>true,prompt:()=>'',Image:function(){},FileReader:function(){}};
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(extensionRoot+'/js/data.js','utf8'),sandbox,{filename:'data.js'});
vm.runInContext(fs.readFileSync(extensionRoot+'/js/aep-library.js','utf8'),sandbox,{filename:'aep-library.js'});
vm.runInContext(fs.readFileSync(extensionRoot+'/js/dynamic-grid.js','utf8'),sandbox,{filename:'dynamic-grid.js'});
vm.runInContext(fs.readFileSync(extensionRoot+'/js/main.js','utf8'),sandbox,{filename:'main.js'});

// Mock de interfaz para Grid Pro 2.7.1 (sin render real de After Effects).
let tabs=ids.tabs.children;
const grid=tabs.find(x=>x.attrs.title==='Grid Pro');
if(!grid)throw Error('Grid Pro missing in sidebar');
grid.handlers.click[0]({});
function byClass(n){return deep(ids.page).filter(x=>x instanceof E&&String(x.className).split(' ').includes(n));}
if(byClass('dg-tabbar').length!==1)throw Error('Missing grid tabs');
if(byClass('dg-preset-list').length!==1)throw Error('Missing presets');
if(byClass('dg-preset-list')[0].children.length!==6)throw Error('Expected six layouts');
const gridButtons=deep(ids.page).filter(x=>x.tagName==='button');
for(const title of ['Aplicar disposición','Leer grid de AE','Crear / reconstruir grid']){
 if(!gridButtons.find(x=>x.textContent===title))throw Error('Missing '+title);
}
const tabsBar=byClass('dg-tabbar')[0];
for(const name of ['Animate','Backdrop','Attach']){
 const b=tabsBar.children.find(x=>x.textContent===name);
 if(!b)throw Error(name+' tab missing');
 b.handlers.click[0]({});
 if(byClass('dg-preview-wrap').length!==1)throw Error('Missing preview in '+name);
 if(name==='Animate'&&byClass('dg-motion-list')[0].children.length!==11)throw Error('Motion count mismatch');
 if(name==='Attach'){
   const sels=deep(ids.page).filter(x=>x.tagName==='select');
   if(!sels.some(x=>x.children.some(o=>o.attrs.value==='reveal')))throw Error('Missing reveal mode');
 }
}
// Attach 2.7.3: a single click must replace the previous cell and never expand by accident.
function cells(){return deep(ids.page).filter(x=>x.tagName==='rect'&&x.attrs['data-dg-cell']!==undefined);}
function cell(id){const found=cells().find(x=>x.attrs['data-dg-cell']===id);if(!found)throw Error('Missing cell '+id);return found;}
function md(id){cell(id).handlers.mousedown[0]({preventDefault:()=>{},stopPropagation:()=>{},button:0});}
function move(x,y){(docHandlers.mousemove||[]).forEach(fn=>fn({clientX:x,clientY:y}));}
function up(){(docHandlers.mouseup||[]).forEach(fn=>fn({}));}
function selected(){return byClass('dg-picks-list')[0].textContent;}
function gesture(value){
 const sels=deep(ids.page).filter(x=>x.tagName==='select');
 const control=sels.find(x=>x.children.some(o=>o.attrs.value==='single'));
 if(!control)throw Error('Gesture chooser missing');
 control.handlers.change[0]({target:{value}});
}
function assertOnly(id){const picks=selected().split(' · ').filter(x=>x.startsWith('c:'));if(picks.length!==1||picks[0]!==id)throw Error('Expected only '+id+', got '+selected());}
if(!deep(ids.page).some(x=>x.tagName==='button'&&x.textContent==='Crear máscara de revelado'))throw Error('Missing reveal mask action');
md('c:1:1');up();assertOnly('c:1:1');
md('c:2:2');move(5,5);up();assertOnly('c:2:2');
md('c:2:2');up();assertOnly('c:2:2');
const center=cell('c:2:2');if(center.attrs['fill']!=='#8b7bff')throw Error('Selected cell not visibly highlighted');
gesture('multi');md('c:0:0');up();md('c:2:2');up();
if(selected().split(' · ').filter(x=>x.startsWith('c:')).length!==2)throw Error('Multi-click should select two independent cells: '+selected());
gesture('block');md('c:0:0');move(160,90);up();
if(selected().split(' · ').filter(x=>x.startsWith('c:')).length!==9)throw Error('Drag 3x3 expected, got '+selected());
gesture('single');md('c:3:3');move(160,90);up();assertOnly('c:3:3');
console.log('PASS: single-cell stable click; no accidental hover/drag; multi click; block drag; reveal mask action');
