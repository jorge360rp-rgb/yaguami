# Pruebas Yaguanimix 2.6

Las pruebas automatizadas de interfaz y motor se hicieron fuera de After Effects. `engine_260_mock.js` verifica el reemplazo entre Color Sweep y Sweep Studio, el control de blur y las operaciones de zoom y timeline. `engine_in_out_240_mock.js`, `background_v220_mock.js` y `library_ae_mock.js` comprueban regresiones de las funciones anteriores.

Para comprobar el funcionamiento **real** en After Effects 2024/2025: abre la aplicación y ejecuta `qa/diagnostico_2_6.jsx` desde Archivo → Scripts → Ejecutar archivo de script. La prueba crea una composición aislada nueva con texto de dos líneas, aplica los cinco barridos y examina selectores y controles. Guarda `Yaguano_diagnostico_2_6.txt` en el Escritorio. Es necesario inspeccionar visualmente las animaciones en el visor: estas pruebas no garantizan la apariencia final ni reemplazan un render.

La prueba de interfaz cubrió 9 secciones, barra lateral (contraída y expandida), acordeones y cinco presets de barrido en anchuras de 260, 300, 340, 480, 680 y 900 px sin desbordamientos horizontales.
