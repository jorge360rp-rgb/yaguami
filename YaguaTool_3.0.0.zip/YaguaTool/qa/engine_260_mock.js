// Yaguanimix 2.0 simulated AE engine: masks + ink sweep + full-frame gradient backgrounds.
// This is NOT a substitute for rendering in After Effects.
const vm=require('vm'),fs=require('fs'),assert=require('assert'),path=require('path');
let nextId=1, sceneComps=[];
class Shape{constructor(){this.vertices=[];this.inTangents=[];this.outTangents=[];this.closed=false}}
class Prop{
  constructor(name){this.name=name;this.children=[];this.value=0;this.keys=[];this.expression='';this.expressionEnabled=false;this.parentProperty=null;this.isSpatial=false;this.propertyValueType=0;this.maskMode=0}
  get numProperties(){return this.children.length}get numKeys(){return this.keys.length}
  property(n){return typeof n==='number'?this.children[n-1]||null:this.children.find(x=>x.name===n)||null}
  addProperty(name){let x=new Prop(name);x.parentProperty=this;
    if(name==='ADBE Text Animator'){x.addProperty('ADBE Text Animator Properties');let s=x.addProperty('ADBE Text Selectors');let r=s.addProperty('ADBE Text Selector');r.addProperty('ADBE Text Range Advanced');r.addProperty('ADBE Text Percent Start');r.addProperty('ADBE Text Percent End');r.addProperty('ADBE Text Percent Offset')}
    else if(name==='ADBE Text Expressible Selector')x.addProperty('ADBE Text Expressible Amount');
    else if(name==='ADBE Slider Control'||name==='ADBE Color Control')x.addProperty('value');
    else if(name==='ADBE 4ColorGradient')for(let i=1;i<=8;i++)x.addProperty('effect-'+i);
    else if(name==='ADBE Ramp')for(let i=1;i<=7;i++)x.addProperty('ramp-'+i);
    else if(name==='ADBE Vector Group')x.addProperty('ADBE Vectors Group');
    else if(name==='ADBE Vector Shape - Ellipse')x.addProperty('ADBE Vector Ellipse Size');
    else if(name==='ADBE Vector Shape - Rect')x.addProperty('ADBE Vector Rect Size');
    else if(name==='ADBE Vector Graphic - Fill')x.addProperty('ADBE Vector Fill Color');
    else if(name==='ADBE Gaussian Blur 2'){x.addProperty('amount');x.addProperty('unused');x.addProperty('repeat edge pixels')}
    else if(name==='ADBE Fill')x.addProperty('ADBE Fill-0002');
    else if(name==='ADBE Glo2')for(let i=1;i<=5;i++)x.addProperty('ADBE Glo2-'+String(i).padStart(4,'0'));
    else if(name==='ADBE Mask Atom'){x.addProperty('ADBE Mask Shape');x.addProperty('ADBE Mask Feather')}
    this.children.push(x);return x;
  }
  setValue(v){this.value=v} setValueAtTime(t,v){this.keys.push([t,v]);this.value=v}
  valueAtTime(){return this.value}keyTime(i){return this.keys[i-1][0]} keyValue(i){return this.keys[i-1][1]} removeKey(i){this.keys.splice(i-1,1)} keyInInterpolationType(){return 1} keyOutInterpolationType(){return 1} keyInTemporalEase(){return [{}]} keyOutTemporalEase(){return [{}]}
  moveTo(index){if(!this.parentProperty)return;const ar=this.parentProperty.children;const old=ar.indexOf(this);if(old<0)return;ar.splice(old,1);ar.splice(Math.max(0,Math.min(ar.length,index-1)),0,this)}
  remove(){if(this.parentProperty)this.parentProperty.children=this.parentProperty.children.filter(x=>x!==this)}
  setInterpolationTypeAtKey(){}setTemporalEaseAtKey(){}
}
class Layer{
  constructor(name,comp){this.id=nextId++;this.name=name;this.comp=comp;this.inPoint=0;this.outPoint=comp.duration;this.label=1;this.selected=false;this.audioEnabled=false;this.properties={};this.source=null;this.transform={};
    for(const name of ['position','scale','rotation','opacity','anchorPoint'])this.transform[name]=new Prop(name);
    this.transform.opacity.value=100;this.transform.position.value=[200,200];this.transform.scale.value=[100,100];
    this.properties['ADBE Effect Parade']=new Prop('ADBE Effect Parade');
    this.properties['ADBE Root Vectors Group']=new Prop('ADBE Root Vectors Group');
    this.properties['ADBE Mask Parade']=new Prop('ADBE Mask Parade');
    let tp=this.properties['ADBE Text Properties']=new Prop('ADBE Text Properties');tp.addProperty('ADBE Text Animators');let td=tp.addProperty('ADBE Text Document');td.value={text:'Creative\rMotion',fontSize:82};
  }
  property(n){return this.properties[n]||null}
  duplicate(){let d=new this.constructor('Duplicated',this.comp);d.inPoint=this.inPoint;d.outPoint=this.outPoint;
    d.transform.opacity.value=this.transform.opacity.value;d.transform.opacity.expression=this.transform.opacity.expression;
    d.property('ADBE Text Properties').property('ADBE Text Document').value={...this.property('ADBE Text Properties').property('ADBE Text Document').value};
    d.property('ADBE Text Properties').property('ADBE Text Document').expression=this.property('ADBE Text Properties').property('ADBE Text Document').expression;
    this.comp.arr.unshift(d);return d}
  sourceRectAtTime(){return {left:-150,top:-90,width:360,height:160}}
  moveBefore(other){this.comp.arr=this.comp.arr.filter(x=>x!==this);this.comp.arr.splice(this.comp.arr.indexOf(other),0,this)}
  moveToEnd(){this.comp.arr=this.comp.arr.filter(x=>x!==this);this.comp.arr.push(this)}
  remove(){this.comp.arr=this.comp.arr.filter(x=>x!==this)}
}
class TextLayer extends Layer{}
class ShapeLayer extends Layer{}
class CompItem{
  constructor(w=1080,h=1920,d=10,fps=30){this.width=w;this.height=h;this.duration=d;this.frameRate=fps;this.frameDuration=1/fps;this.pixelAspect=1;this.time=0;this.arr=[];this.usedIn=[];
    this.layers={
      addNull:()=>{let l=new Layer('Null',this);this.arr.unshift(l);return l},
      addShape:()=>{let l=new ShapeLayer('Shape',this);this.arr.unshift(l);return l},
      addSolid:(c,nm)=>{let l=new ShapeLayer(nm,this);this.arr.unshift(l);return l},
      add:(source)=>{let l=new Layer(source.name,this);l.source=source;this.arr.unshift(l);return l},
      addText:(txt)=>{let l=new TextLayer('Text',this);l.property('ADBE Text Properties').property('ADBE Text Document').value.text=txt;this.arr.unshift(l);return l}
    }
  }
  get numLayers(){return this.arr.length}layer(i){return this.arr[i-1]}
  get selectedLayers(){return this.arr.filter(x=>x.selected)}
  openInViewer(){current=this}
  remove(){sceneComps=sceneComps.filter(x=>x!==this)}
}
let current=new CompItem();let orig=new TextLayer('Original',current);orig.selected=true;current.arr.push(orig);
orig.property('ADBE Text Properties').property('ADBE Text Document').expression='"keep expression"';
orig.transform.opacity.expression='value*0.5';orig.transform.opacity.expressionEnabled=true;
const sandbox={app:{project:{get activeItem(){return current},items:{addComp:(nm,w,h,pa,d,fps)=>{let c=new CompItem(w,h,d,fps);c.name=nm;sceneComps.push(c);return c}}},beginUndoGroup(){},endUndoGroup(){}},
 CompItem,TextLayer,ShapeLayer,Shape,MaskMode:{ADD:1,INTERSECT:2},BlendingMode:{NORMAL:1,SCREEN:2,MULTIPLY:3},KeyframeEase:class{},KeyframeInterpolationType:{BEZIER:1},PropertyValueType:{TwoD:2,ThreeD:3},ParagraphJustification:{CENTER_JUSTIFY:1},JSON,Math};
vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../jsx/host.jsx'),'utf8'),sandbox);
const call=(name,o)=>JSON.parse(sandbox.Animix.call(name,JSON.stringify(o)));

const base={mode:'in',dur:.8,delay:0,startAt:'layer',basedOn:'chars',dir:'up',dist:32,blur:5,scale:92,rot:0,bounce:23,bounces:2,overlap:70,fade:true};
function reset(){current=new CompItem();orig=new TextLayer('Original',current);orig.selected=true;current.arr.push(orig);orig.property('ADBE Text Properties').property('ADBE Text Document').value.text='Hello\rWorld';}
function animatorNames(){return orig.property('ADBE Text Properties').property('ADBE Text Animators').children.map(x=>x.name);}
function maskNames(){return orig.property('ADBE Mask Parade').children.map(x=>x.name);}

reset();current.time=1;
for (const style of ['silk','chrome','prism','scan']){
  let r=call('styleSweep',{style, colors:['#ff0000','#00ff00','#0000ff'],dur:1.1,width:18,feather:75,power:70,startAt:'cti',sequential:true});
  assert(r.ok,style+':'+r.msg);
  let anims=orig.property('ADBE Text Properties').property('ADBE Text Animators').children.filter(a=>a.name.startsWith('Animix StyleSweep'));
  assert.equal(anims.length,4,style+' anims count');
  for (let a of anims){
    let expr=a.property('ADBE Text Selectors').property(1).property(1).expression;
    console.log(style,'expression',expr.slice(0,95).replace(/\n/g,'\\n'));
    new Function('time','textIndex','textTotal','effect',expr);
  }
}
assert(call('removeStyleSweep',{}).ok);
assert.equal(orig.property('ADBE Text Properties').property('ADBE Text Animators').numProperties,0);
console.log('style sweep create replace remove PASS');
// v2.6: los cinco estilos comparten blur y cada aplicación reemplaza a la anterior.
reset();current.time=1;
let classic=call('colorSweep',{colors:['#e7bd9a','#f4a16c','#eb5d6a'],blurAmount:7.5,glow:0,dur:1,band:68,feather:.7,colorPower:48});
assert(classic.ok,classic.msg);
assert(animatorNames().some(n=>n==='Animix Sweep Moving Blur'));
assert.equal(orig.property('ADBE Effect Parade').property('Yaguano Sweep Blur').property(1).value,7.5);
let glowBlur=orig.property('ADBE Text Properties').property('ADBE Text Animators').children.find(x=>x.name==='Animix Sweep Moving Blur');
assert(glowBlur.property('ADBE Text Animator Properties').property('ADBE Text Blur').expression.includes('Yaguano Sweep Blur'));
let sr=call('styleSweep',{style:'prism',blurAmount:11,colors:['#ee0011','#10ffff','#1166ee'],dur:.8,startAt:'cti'});
assert(sr.ok,sr.msg);
assert(animatorNames().every(n=>n.indexOf('Animix Sweep ')==-1),'old sweep removed');
assert.equal(orig.property('ADBE Effect Parade').property('Yaguano FX Blur').property(1).value,11);
assert(animatorNames().includes('Animix StyleSweep Motion Blur'));
let back=call('colorSweep',{colors:['#e7bd9a','#f4a16c','#eb5d6a'],blurAmount:2,glow:0,dur:.7,band:55,colorPower:45});
assert(back.ok,back.msg);
assert(animatorNames().every(n=>n.indexOf('Animix StyleSweep ')==-1),'studio removed by classic');
assert(call('removeAnySweep',{}).ok);
assert(!animatorNames().some(n=>n.indexOf('Sweep')>=0),'unified removal');
console.log('sweep unified classic/studio/blur 0-20px PASS');
reset();current.time=1;
for(const phase of ['in','out']){
  let r=call('textZoom',{direction:phase,phase,strength:25,dur:1});assert(r.ok,r.msg);
}
assert.equal(orig.property('ADBE Text Properties').property('ADBE Text Animators').numProperties,2);
assert(call('textZoom',{direction:'out',phase:'out',strength:40,dur:.5}).ok);
assert.equal(orig.property('ADBE Text Properties').property('ADBE Text Animators').numProperties,2);
assert(call('removeTextZoom',{phase:'in'}).ok);
assert.equal(orig.property('ADBE Text Properties').property('ADBE Text Animators').numProperties,1);
console.log('zoom independent phases PASS');

// Timeline tools: marker/trim/rename and stagger on a two-layer selection.
reset();current.time=3;orig.inPoint=0;orig.outPoint=6;
let next=new TextLayer('Second',current);next.selected=true;next.inPoint=0;next.outPoint=6;current.arr.push(next);
assert(call('toolRename',{prefix:'Scene_',first:7}).ok);
assert.equal(orig.name,'Scene_7');assert.equal(next.name,'Scene_8');
assert(call('toolTrim',{side:'in'}).ok);
assert.equal(orig.inPoint,3);assert.equal(next.inPoint,3);
assert(!call('toolTrim',{side:'in'}).ok,'no zero duration trim');
assert(call('toolStagger',{frames:5,origin:'first'}).ok);
Prop.prototype.nearestKeyIndex=function(){return 1;};
orig.properties['ADBE Marker']=new Prop('ADBE Marker');next.properties['ADBE Marker']=new Prop('ADBE Marker');
sandbox.MarkerValue=class{constructor(v){this.comment=v;}};
assert(call('toolMarker',{tag:'in'}).ok);
assert.equal(orig.property('ADBE Marker').numKeys,1);
assert(call('toolMarker',{tag:'in'}).ok);
assert.equal(orig.property('ADBE Marker').numKeys,1,'marker not overwritten');
console.log('timeline batch tools PASS');
