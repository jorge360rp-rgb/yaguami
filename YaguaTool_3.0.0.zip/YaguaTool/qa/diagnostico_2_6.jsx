/* Yaguanimix 2.6 — diagnostico de barridos nativos + blur en AE 2024/2025.
   Crea una composicion de prueba nueva; NO modifica las composiciones originales.
   Ejecucion: Archivo > Scripts > Ejecutar archivo de script. */
(function(){
    var notes=[],ok=0,bad=0,qa=null;
    function rec(name,pass,msg){notes.push((pass?"OK ":"ERROR ")+name+": "+msg);if(pass)ok++;else bad++;}
    function call(name,o){
        var r;
        try{r=JSON.parse(Animix.call(name,JSON.stringify(o||{})));}
        catch(e){r={ok:false,msg:String(e)};}
        rec(name,r.ok,r.msg||"Sin mensaje");return r;
    }
    function names(l){
        var a=l.property("ADBE Text Properties").property("ADBE Text Animators"),out=[],i;
        for(i=1;i<=a.numProperties;i++)out.push(a.property(i).name);
        return out;
    }
    function countPrefix(l,prefix){var a=names(l),n=0,i;for(i=0;i<a.length;i++)if(a[i].indexOf(prefix)===0)n++;return n;}
    function checkExpressions(l){
        var a=l.property("ADBE Text Properties").property("ADBE Text Animators"),j,sel,prop,bp,i;
        for(i=1;i<=a.numProperties;i++){
            if(a.property(i).name.indexOf("Sweep")<0)continue;
            try{
                sel=a.property(i).property("ADBE Text Selectors");
                bp=sel.property(1);
                prop=bp.property("ADBE Text Expressible Amount")||bp.property(1);
                if(prop&&prop.expressionError)rec("Expresión "+a.property(i).name,false,prop.expressionError);
            }catch(e){rec("Lectura de selector "+a.property(i).name,false,String(e));}
            try{
                prop=a.property(i).property("ADBE Text Animator Properties").property("ADBE Text Blur");
                if(prop&&prop.expressionError)rec("Expresión de blur",false,prop.expressionError);
            }catch(blurError){}
        }
    }
    try{
        if(!app.project)app.newProject();
        var host=new File(File($.fileName).parent.parent.fsName+"/jsx/host.jsx");
        if(!host.exists)throw new Error("No se encontró el motor de extensión: jsx/host.jsx.");
        $.evalFile(host);
        qa=app.project.items.addComp("YAGUANO QA 2.6 — BORRAR AL TERMINAR",960,540,1,12,30);
        qa.openInViewer();qa.time=.5;
        var t=qa.layers.addText("Yaguano\rMotion");t.name="Yaguano · Prueba de blur";t.outPoint=11;
        t.transform.position.setValue([150,270]);
        var docProp=t.property("ADBE Text Properties").property("ADBE Text Document"),doc=docProp.value;
        doc.fontSize=112;doc.fillColor=[.82,.82,.85];doc.applyFill=true;docProp.setValue(doc);
        t.selected=true;
        var styles=["silk","chrome","prism","scan"],i,r;
        for(i=0;i<styles.length;i++){
            qa.time=1;
            r=call("styleSweep",{style:styles[i],dur:.9,delay:0,startAt:"cti",blurAmount:6.5,power:70,
                width:22,feather:95,sequential:true,lineGap:.12});
            if(r.ok){
                rec("Studio "+styles[i]+" crea 3 colores + blur",countPrefix(t,"Animix StyleSweep ")===4,"Animadores: "+countPrefix(t,"Animix StyleSweep "));
                checkExpressions(t);
                try{rec("Studio control Blur",Math.abs(t.property("ADBE Effect Parade").property("Yaguano FX Blur").property(1).value-6.5)<.001,"6.5 px");}
                catch(er){rec("Studio control Blur",false,String(er));}
            }
        }
        qa.time=1;
        r=call("colorSweep",{colors:["#e7bd9a","#f4a16c","#eb5d6a"],dur:1,delay:0,glow:0,band:70,
          feather:.7,colorPower:48,startAt:"cti",blurAmount:3.5,lineMode:"sequential",lineGap:.12,mode:"in",reveal:"follow"});
        if(r.ok){
            rec("Clásico crea 3 colores + blur",countPrefix(t,"Animix Sweep ")===4,"Animadores: "+countPrefix(t,"Animix Sweep "));
            rec("Clásico reemplaza Studio",countPrefix(t,"Animix StyleSweep ")===0,"Studio sin duplicados");
            checkExpressions(t);
            try{rec("Clásico control Blur",Math.abs(t.property("ADBE Effect Parade").property("Yaguano Sweep Blur").property(1).value-3.5)<.001,"3.5 px");}
            catch(er){rec("Clásico control Blur",false,String(er));}
        }
        call("removeAnySweep",{});
        rec("Quitar barrido",countPrefix(t,"Animix Sweep ")+countPrefix(t,"Animix StyleSweep ")===0,"Sin animadores de barrido");
        notes.push("Comp de prueba: 'YAGUANO QA 2.6', borra manualmente cuando termines.");
    }catch(e){bad++;notes.push("ERROR CRÍTICO: "+String(e));}
    var output="YAGUANIMIX 2.6 — DIAGNÓSTICO AFTER EFFECTS\rOK: "+ok+" / ERRORES: "+bad+"\r\r"+notes.join("\r");
    try{var f=new File(Folder.desktop.fsName+"/Yaguano_diagnostico_2_6.txt");
        if(f.open("w")){f.write(output);f.close();alert("Yaguanimix 2.6: "+ok+" OK / "+bad+" errores. Informe en Escritorio.");}
        else alert(output);
    }catch(writeErr){alert(output);}
})();
