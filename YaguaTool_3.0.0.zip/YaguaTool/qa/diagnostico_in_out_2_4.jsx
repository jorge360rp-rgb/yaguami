/*
 * Yaguanimix 2.4 — comprobación nativa de IN / OUT (After Effects 24/25).
 * Crea una composición de PRUEBA. No modifica ninguna composición existente.
 * Archivo > Scripts > Ejecutar archivo de script y seleccionar este .jsx.
 */
(function(){
    var lines=[], prior=null, compQa=null;
    function log(s){ lines.push(s); }
    function callAnim(kind,mode,t,opts){
        compQa.time=t;
        var args={kind:kind,mode:mode,startAt:mode==='out'?'cti':'layer',dur:.75,
                  basedOn:'words',dir:'up',dist:35,blur:5,scale:96,rot:0,
                  bounce:25,bounces:2,overlap:70,fade:true,delay:0};
        var k;for(k in opts)if(opts.hasOwnProperty(k))args[k]=opts[k];
        var answer=JSON.parse(Animix.call('text',JSON.stringify(args)));
        if(!answer.ok)throw new Error(kind+' '+mode+': '+answer.msg);
        log('OK: '+kind+' '+mode+' @ '+t+'s');
    }
    app.beginUndoGroup('Yaguanimix QA IN OUT');
    try{
        var host=new File(File($.fileName).parent.parent.fsName+'/jsx/host.jsx');
        if(!host.exists)throw new Error('Falta host.jsx; ejecuta desde la carpeta qa del paquete.');
        $.evalFile(host);
        if(!app.project)app.newProject();
        prior=app.project.activeItem;
        compQa=app.project.items.addComp('Yaguanimix 2.4 QA - IN OUT',1080,640,1,5,30);
        var txt=compQa.layers.addText('YAGUANO\rMOTION');
        txt.name='QA: Smart Reveal IN + Smart Bounce OUT';
        var doc=txt.property('ADBE Text Properties').property('ADBE Text Document');
        var value=doc.value;value.fontSize=96;value.applyFill=true;value.fillColor=[1,1,1];doc.setValue(value);
        txt.transform.position.setValue([540,320]);
        compQa.openInViewer();txt.selected=true;
        callAnim('SR','in',0);
        callAnim('SB','out',2.8);
        var a=txt.property('ADBE Text Properties').property('ADBE Text Animators');
        var seenIn=false,seenOut=false,i;
        for(i=1;i<=a.numProperties;i++){
            if(a.property(i).name==='Animix SR In')seenIn=true;
            if(a.property(i).name==='Animix SB Out')seenOut=true;
        }
        if(!seenIn||!seenOut)throw new Error('No aparecen ambas fases independientes en el texto.');
        log('OK: Smart Reveal IN permanece al aplicar Smart Bounce OUT.');
        // No elimina la composición: deja la prueba visible para reproducirla.
        compQa.time=0;
    }catch(e){log('ERROR: '+String(e));}
    try{app.endUndoGroup();}catch(ignore){}
    var output=new File(Folder.desktop.fsName+'/Yaguanimix_2_4_IN_OUT_QA.txt');
    try{output.encoding='UTF-8';output.open('w');output.write(lines.join('\n'));output.close();}catch(ignore2){}
    alert('Diagnóstico Yaguanimix 2.4\n\n'+lines.join('\n')+'\n\nInforme en el escritorio.');
})();
