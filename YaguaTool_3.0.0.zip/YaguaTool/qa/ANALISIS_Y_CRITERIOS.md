# Integración de animaciones originales: criterios técnicos de Yaguanimix 2.1

## Inspección de archivos aportados

Los tres proyectos son archivos After Effects binarios con cabecera RIFX (no `.ffx`). Se recorrieron sus estructuras de proyecto y se identificaron por nombre **51 composiciones principales**:

| Archivo fuente | Composiciones seleccionadas | Técnicas identificadas en nombres/expresiones |
| --- | ---: | --- |
| Text Animation 24.x.aep | 21 | Highlight Reveal izq./dcha., Drift In/Out, slide de frases, typewriter, transiciones palabra→palabra y palabra→frase. Controladores `Highlight Word Color`, `General Text Color`, `Position`, `Scale`. |
| Text Animation.aep | 10 | `Text Animation (Main) 01` a `10`, títulos con capas de texto, controladores de color (`Text Color 01/02/03`), algunos con cámaras/controles de puntos. |
| Dynamic Text Animation.aep | 20 | `Title 01` a `Title 20`; `Controller`, interruptores de Noise y Glow, colores de texto y fondos sólidos/degradados. Algunas expresiones apuntan a otros títulos con `comp("Title 06")`. |

Estos hallazgos están sustentados en nombres y expresiones extraídos de los archivos; **no se han reproducido los renders**. No se presume que todos utilicen únicamente efectos nativos: los proyectos originales podrían tener dependencias no incluidas.

## Por qué no se convirtieron a `.ffx`

Un `.aep` puede incluir capas, precomposiciones, cámaras, fuentes, controladores, efectos y expresiones. Un preset `.ffx` no reproduce necesariamente esa composición ni sus dependencias. Para conservar más fidelidad, la v2.1 ofrece importación **bajo demanda** (un proyecto por pack) y duplicación profunda de la composición elegida al aplicarla.

## Estrategia de no destrucción

- **Originales:** al importar, se etiquetan las composiciones del proyecto con un comentario `YAGUANO_LIBRARY_21:`. No se modifican sus animaciones.
- **Instancias:** al aplicar, se duplican la composición y todas sus precomps insertadas, con memoización por ID; se reutilizan los sólidos y los medios externos sin duplicarlos.
- **Referencias cruzadas:** también se detectan expresiones del tipo `comp("Nombre")`, se duplican las composiciones referenciadas que pertenecen al mismo pack y se reescriben dichas referencias en las copias. Expresiones dinámicas basadas en nombres construidos por concatenación o `eval` no se pueden descubrir estáticamente.
- **Deshacer:** toda llamada `Animix.call` se ejecuta dentro de `app.beginUndoGroup` y `app.endUndoGroup`.
- **Sin plugins de terceros añadidos:** la extensión solo utiliza la API de AE. Los **AEP aportados** pueden contener efectos o dependencias que After Effects exija instalar o reemplazar.

## Presets nativos añadidos a Texto

1. **Drift In · Fast:** entrada lateral breve y frenada controlada. Preset de texto basado en Range Selector con suavizado y controles de duración, desplazamiento, blur y unidad.
2. **Drift Out · Cinematic:** salida lateral lenta y difusa. Duración mayor y curva de desaceleración/aceleración diferente de la entrada.
3. **Highlight Lift:** ascenso tipográfico por palabras con tracking y un acento de color móvil mediante otro animador de texto nativo (con color ajustable desde Efectos). El color base del texto y sus animadores previos no se sustituyen.

Las recreaciones nativas no pretenden ser idénticas a los `.aep`; son técnicas reutilizables aplicables a texto existente.

## Qué falta validar dentro de After Effects

- Importación real de los tres `.aep` en AE2024 y AE2025, incluyendo sus posibles avisos de fuentes/medios/plugins.
- Render visual del original frente a la instancia duplicada, incluida la sincronización de expresiones de referencia cruzada.
- Escala y duración de los títulos en composiciones de otros formatos (vertical/cuadrado/horizontal). Una precomp de 1920×1080 insertada en un proyecto vertical conservará su tamaño propio; ajustar su encuadre es responsabilidad del editor.
- Funcionamiento y resultado visual de los tres nuevos presets nativos en una comp real.

Para inspección inicial sin modificar proyectos, ejecutar `qa/diagnostico_biblioteca_2_1.jsx` en AE.
