/* Run against the served extension; Playwright and Chromium required. */
const {chromium}=require('playwright'),assert=require('assert'),fs=require('fs'),path=require('path');
(async()=>{
const base=process.env.YAGUANIMIX_TEST_URL||'http://127.0.0.1:8766',out=process.env.YAGUANIMIX_CAPTURE_DIR||'/tmp/yaguanimix-280';fs.mkdirSync(out,{recursive:true});
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
const page=await browser.newPage({viewport:{width:1340,height:1000}}),errors=[],external=[];
page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(!r.url().startsWith(base)&&!r.url().startsWith('data:'))external.push(r.url())});
await page.goto(base);await page.waitForTimeout(450);assert.equal(await page.locator('.chip').count(),32);
async function choose(id){await page.locator('.preset-family').evaluateAll(es=>es.forEach(e=>e.open=true));await page.locator('.chip').filter({has:page.locator('b',{hasText:new RegExp('^'+id+'$')})}).click();}
const maskIds=['MRU','MRD','MRL','MRR','MSC','MDI'];
for(const id of maskIds){
 await choose(id);assert.equal(await page.locator('.mask-live-svg').count(),1,id);
 for(const phase of ['IN · Entrada','OUT · Salida']){
  await page.getByText(phase,{exact:true}).click();
  const scrub=page.getByLabel('Posición de la preview');
  await scrub.evaluate(e=>{e.value='0';e.dispatchEvent(new Event('input',{bubbles:true}));});const start=await page.locator('mask path').first().getAttribute('d');
  await scrub.evaluate(e=>{e.value='350';e.dispatchEvent(new Event('input',{bubbles:true}));});const mid=await page.locator('mask path').first().getAttribute('d');
  await scrub.evaluate(e=>{e.value='1000';e.dispatchEvent(new Event('input',{bubbles:true}));});const end=await page.locator('mask path').first().getAttribute('d');
  assert.notEqual(start,mid,id+' start/mid');assert.notEqual(mid,end,id+' mid/end');
  assert.equal(await page.locator('mask path').count(),id==='MRR'?6:2);
 }
 await page.getByText('IN · Entrada',{exact:true}).click();
 const order=page.getByLabel('Orden de líneas',{exact:true});for(const value of ['reverse','center','alternate','forward'])await order.selectOption(value);
}
const allIds=await page.locator('.chip b').allTextContents();
for(const id of allIds){await choose(id);assert.equal(await page.locator('.text-preview-stage').count(),1,id);}
await choose('MRU');
const search=page.getByLabel('Buscar presets');await search.fill('iris');assert.equal(await page.locator('.chip:not([hidden])').count(),1);await search.fill('zz-no-such-preset');assert(await page.locator('.search-empty').isVisible());await search.fill('');assert.equal(await page.locator('.chip:not([hidden])').count(),32);
// All sections in all themes and widths must mount without horizontal overflow.
const labels=['Texto','Biblioteca','Movimiento','Fondos','Curvas','Herramientas','Guardado','Retícula','Grid Pro','Ajustes'];
for(const width of [280,320,380,768,1340]){
 await page.setViewportSize({width,height:1000});
 for(const label of labels){await page.locator('#tabs').getByRole('button',{name:label,exact:true}).click();await page.waitForTimeout(30);assert.equal(await page.locator('.section-lead h1').count(),1,label);assert(await page.locator('.section-body').evaluate(e=>e.childElementCount>0),label);assert(await page.locator('#page').evaluate(e=>e.scrollWidth<=e.clientWidth+1),label+' overflow '+width);}
}
await page.setViewportSize({width:1340,height:1000});await page.locator('#tabs').getByRole('button',{name:'Texto',exact:true}).click();
await page.getByRole('button',{name:'Activar tema oscuro',exact:true}).click();assert.equal(await page.locator('html').getAttribute('data-theme'),'dark');
await page.reload();assert.equal(await page.locator('html').getAttribute('data-theme'),'dark');
await page.waitForTimeout(450);await page.screenshot({path:path.join(out,'Studio_2.8.0_Oscuro.png')});
await page.getByRole('button',{name:'Activar tema claro',exact:true}).click();
await page.getByRole('button',{name:'Expandir menú lateral'}).click();await page.waitForTimeout(450);
await page.screenshot({path:path.join(out,'Studio_2.8.0_Claro.png')});
assert(await page.locator('.nav-selection').evaluate(e=>getComputedStyle(e).transitionDuration!=='0s'));
await page.locator('#tabs').getByRole('button',{name:'Fondos',exact:true}).focus();await page.keyboard.press('Enter');assert.equal(await page.locator('#page').getAttribute('data-section'),'backgrounds');assert(await page.locator('#tabs .nav-item.on').evaluate(e=>e===document.activeElement));
await page.locator('#tabs').getByRole('button',{name:'Texto',exact:true}).click();await choose('MDI');
const scrub=page.getByLabel('Posición de la preview');await scrub.evaluate(e=>{e.value='250';e.dispatchEvent(new Event('input',{bubbles:true}));});
await page.setViewportSize({width:380,height:920});await page.waitForTimeout(100);
assert(await page.locator('.text-preview-stage').evaluate(e=>{const a=e.getBoundingClientRect(),b=e.parentNode.getBoundingClientRect();return a.right<=b.right+1}));
await page.screenshot({path:path.join(out,'Studio_2.8.0_Acoplado.png')});
// Reduced motion: paused previews, no shell transition, still manually playable.
const reduced=await browser.newPage({viewport:{width:380,height:920},reducedMotion:'reduce'});reduced.on('pageerror',e=>errors.push(e.message));await reduced.goto(base);await reduced.waitForTimeout(150);assert.equal(await reduced.locator('html').getAttribute('data-motion'),'reduced');assert.equal(await reduced.locator('.preview-pause').textContent(),'Continuar');
const before=await reduced.locator('mask path').first().getAttribute('d');await reduced.waitForTimeout(150);assert.equal(await reduced.locator('mask path').first().getAttribute('d'),before);await reduced.getByRole('button',{name:'↻ Reproducir',exact:true}).first().click();await reduced.waitForTimeout(80);assert.notEqual(await reduced.locator('mask path').first().getAttribute('d'),before);
// Native frame path via a stub: loading, decode and stale-frame discard.
const native=await browser.newPage({viewport:{width:380,height:920}});await native.addInitScript(({base})=>{window.__adobe_cep__={evalScript:(script,cb)=>cb(JSON.stringify({ok:true,msg:'stub',data:{frames:[base+'/assets/yaguanimix-icon.png',base+'/assets/yaguanimix-icon.png'],duration:1,fps:2}}))};},{base});await native.goto(base);await native.getByRole('button',{name:'Renderizar preview real en el panel',exact:true}).click();await native.waitForFunction(()=>!document.querySelector('.text-preview-render').hidden);assert(await native.locator('.text-preview-render').isVisible());await native.getByRole('spinbutton',{name:'Intensidad de forma',exact:true}).fill('42');await native.getByRole('spinbutton',{name:'Intensidad de forma',exact:true}).dispatchEvent('change');assert(await native.locator('.text-preview-render').isHidden());
assert.deepEqual(errors,[]);assert.deepEqual(external,[]);console.log('PASS: six masks IN/OUT with scrubbing, ordering, search, 10 sections × 5 widths, light/dark persistence, keyboard focus, reduced motion, native frames, no external assets');
await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
