// Simulación aislada de la API ExtendScript de importación/duplicación de .aep.
// No verifica la representación gráfica ni reemplaza After Effects.
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const root = path.resolve(__dirname,'..');
let id = 1, calls = 0, curr;
const PropertyType={PROPERTY:1, GROUP:2};
class Property {
  constructor(str){this.propertyType=1;this.canSetExpression=true;this.expressionEnabled=true;this.expression=str;this.numProperties=0;}
}
class Group {
  constructor(children){this.propertyType=2;this.children=children;this.numProperties=children.length;}
  property(i){return this.children[i-1];}
}
class Layer {
  constructor(comp, source, expr=''){
    this.comp=comp;this.source=source;this.startTime=0;this.inPoint=0;this.outPoint=comp.duration;
    this.props=expr ? [new Group([new Property(expr)])] : [];
    this.numProperties=this.props.length;
  }
  property(i){return this.props[i-1];}
  replaceSource(comp,fixExpressions){this.source=comp;}
  duplicate(newcomp){return new Layer(newcomp,this.source,this.props.length?this.props[0].children[0].expression:'');}
}
class CompItem {
  constructor(name){this.name=name;this.id=id++;this.comment='';this.duration=5;this.frameRate=30;this.time=0;this.arr=[];this.parentFolder=null;}
  get numLayers(){return this.arr.length;}
  layer(i){return this.arr[i-1];}
  get layers(){return {add:(source)=>{const l=new Layer(this,source);this.arr.unshift(l);return l;}};}
  duplicate(){let d=new CompItem(this.name);d.arr=this.arr.map(l=>l.duplicate(d));items.push(d);return d;}
  openInViewer(){curr=this;}
}
class FolderItem {constructor(name){this.name=name;this.id=id++;}}
class File {constructor(filename){this.fsName=filename;this.name=path.basename(filename);this.exists=fs.existsSync(filename);}}
class ImportOptions{constructor(file){this.file=file;this.importAs=0;} canImportAs(t){return true;}}
const ImportAsType={PROJECT:4};
let items=[];const dest=new CompItem('Comp destino');items.push(dest);curr=dest;
function importFile(io){
  calls++;
  const name=io.file.name;
  if(name==='Text Animation 24.x.aep') {
    let nested=new CompItem('Subcomp de prueba');
    let main=new CompItem('1. Highlight Reveal - Left');
    let global=new CompItem('Global Colors');
    main.arr.push(new Layer(main,nested,'comp("Subcomp de prueba").layer("Text")'));
    main.arr.push(new Layer(main,null,'comp("Global Colors").layer("Controls")'));
    items.push(main,nested,global);
  } else if(name==='Text Animation.aep') {
    items.push(new CompItem('Text Animation (Main) 01'));
  } else if(name==='Dynamic Text Animation.aep') {
    items.push(new CompItem('Title 01'));
  }
}
const project={
  get numItems(){return items.length;},
  item:(i)=>items[i-1],
  get activeItem(){return curr;},
  importFile,
  items:{addFolder:(name)=>{let f=new FolderItem(name);items.push(f);return f;}}
};
const sb={app:{project,beginUndoGroup(){},endUndoGroup(){}},
  CompItem,FolderItem,File,ImportOptions,ImportAsType,PropertyType,
  JSON,Math,Error,Number,String};
vm.runInNewContext(fs.readFileSync(path.join(root,'jsx/host.jsx'),'utf8'),sb);
const invoke=(name,o)=>JSON.parse(sb.Animix.call(name,JSON.stringify(o)));
const folder=root,base={root:folder,pack:'text24',name:'1. Highlight Reveal - Left'};
let response=invoke('aepLibraryStatus',base);assert(response.ok,response.msg);assert(!response.data.loaded);
response=invoke('aepLibraryApply',{...base,open:false});assert(response.ok,response.msg);
assert.equal(response.data.count,3);assert.equal(response.data.destination,'Comp destino');assert.equal(calls,1);
let instance=dest.arr[0].source; assert(instance instanceof CompItem);assert(instance.comment.startsWith('YAGUANO_INSTANCE_21:'));
const sub=instance.layer(1).source;assert(sub!==items.find(it=>it.name==='Subcomp de prueba'));
const ex=instance.layer(1).property(1).property(1).expression;
assert(ex.indexOf('comp("'+sub.name+'")')>=0,'Cross-comp expression must point at cloned nested source: '+ex);
let originalGlobal=items.find(it=>it.name==='Global Colors');
let copyGlobal=items.find(it=>it.comment==='YAGUANO_INSTANCE_21:'+originalGlobal.id);
assert(copyGlobal && copyGlobal!==originalGlobal,'Global comp() dependency must be cloned');
assert(instance.layer(2).property(1).property(1).expression.indexOf('comp("'+copyGlobal.name+'")')>=0);
response=invoke('aepLibraryApply',{...base,open:false});assert(response.ok,response.msg);assert.equal(calls,1,'Import should be deduplicated');
const second=dest.arr[0].source;assert(second!==instance,'Instances must be independent');assert(second.layer(1).source!==sub,'Nested comps must be independent');
response=invoke('aepLibraryOpen',base);assert(response.ok,response.msg);
response=invoke('aepLibraryApply',base);assert(!response.ok,'Applying inside original comp must fail');
curr=dest;
response=invoke('aepLibraryImport',{...base,pack:'text',name:'Text Animation (Main) 01'});assert(response.ok,response.msg);assert.equal(calls,2);
response=invoke('aepLibraryApply',{...base,pack:'dynamic',name:'Title 01'});assert(response.ok,response.msg);assert.equal(calls,3);
response=invoke('aepLibraryList',{...base,pack:'dynamic'});assert(response.ok&&response.data[0].name==='Title 01');
console.log('PASS: AEP library paths, import on demand, idempotency, isolated deep copies, expression relinking, destination protection, three packs.');
console.log('REAL AFTER EFFECTS RENDER/IMPORT STILL REQUIRED for verification.');
