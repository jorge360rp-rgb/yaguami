const {chromium}=require('playwright'),assert=require('assert');
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:420,height:900}}),errors=[];
 page.on('pageerror',e=>errors.push(e.message));await page.goto((process.env.YAGUANIMIX_TEST_URL||'http://127.0.0.1:8765'));
 const ids=await page.locator('.chip b').allTextContents();assert.equal(ids.length,32);
 async function choose(id){await page.locator('.preset-family').evaluateAll(es=>es.forEach(e=>e.open=true));await page.locator('.chip').filter({has:page.locator('b',{hasText:new RegExp('^'+id+'$')})}).click();}
 for(const id of ids){
  await choose(id);
  assert.equal(await page.locator('.text-preview-stage').count(),1,id);
  await page.getByText('OUT · Salida',{exact:true}).click();
  await page.locator('.preview-card').filter({has:page.locator('.text-preview-stage')}).getByRole('button',{name:'↻ Reproducir',exact:true}).click();
  if(!/^(N|TM|TW|MR[UDLR]|MSC|MDI)$/.test(id)){
   const opacity=await page.locator('.text-preview-unit').first().evaluate(e=>getComputedStyle(e).opacity);assert(Number(opacity)>.5,id+' OUT starts invisible');
  }
  await page.getByText('IN · Entrada',{exact:true}).click();
 }
 await choose('SR');
 const select=page.locator('.text-unit-card select');
 for(const [unit,count] of [['words',5],['lines',2],['chars',31],['nospace',28]]){
  await select.selectOption(unit);
  const result=await page.locator('.text-preview-unit').count();
  // Spaces are rendered but excluded from timing for nospace.
  assert.equal(result,unit==='nospace'?31:count,unit);
 }
 await page.getByRole('button',{name:'Renderizar preview real en el panel',exact:true}).click();
 assert((await page.locator('.preview-card:has(.text-preview-stage)>small').textContent()).includes('After Effects'));
 await choose('N');
 await page.waitForTimeout(300);const n1=await page.locator('.text-preview-unit').textContent();await page.waitForTimeout(300);const n2=await page.locator('.text-preview-unit').textContent();assert.notEqual(n1,n2,'number must animate');
 await choose('TW');assert.equal(await page.getByText('Ambos',{exact:true}).count(),0);
 await choose('YHERO');await page.waitForTimeout(850);await page.screenshot({path:'/tmp/yaguanimix-text-277.png',fullPage:true});
 assert.deepEqual(errors,[]);console.log('32 presets x IN/OUT, unit switching, animated numbers, demo fallback and narrow panel: PASS');
 // Exercise the real-frame UI using a CEP transport stub, including invalidation.
 const real=await browser.newPage({viewport:{width:420,height:900}});
 await real.addInitScript(()=>{
  const png='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jM1sAAAAASUVORK5CYII=';
  window.__adobe_cep__={evalScript:(script,cb)=>cb(JSON.stringify(script.includes('previewText')?{ok:true,msg:'test frames',data:{frames:[png,png],fps:2,duration:1}}:{ok:true,msg:'stub',data:null}))};
 });
 await real.goto((process.env.YAGUANIMIX_TEST_URL||'http://127.0.0.1:8765'));
 // Data URLs cannot carry the cache query; test file serving via http image URI instead.
 await real.evaluate(()=>{window.__adobe_cep__.evalScript=(script,cb)=>cb(JSON.stringify({ok:true,msg:'test frames',data:{frames:['http://127.0.0.1:8765/assets/yaguanimix-icon.png','http://127.0.0.1:8765/assets/yaguanimix-icon.png'],fps:2,duration:1}}));});
 await real.getByRole('button',{name:'Renderizar preview real en el panel',exact:true}).click();
 await real.waitForFunction(()=>document.querySelector('.preview-card:has(.text-preview-stage)>small').textContent.includes('Render real de AE'));
 assert(await real.locator('.text-preview-render').isVisible());
 await real.locator('input[type=number]').first().fill('42');await real.locator('input[type=number]').first().dispatchEvent('change');
 assert(await real.locator('.text-preview-render').isHidden());
 console.log('CEP frame load/playback and stale-frame invalidation: PASS');
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
