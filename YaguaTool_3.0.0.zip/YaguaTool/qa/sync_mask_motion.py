"""Generate or check the ES3 shared geometry embedded in ExtendScript."""
from pathlib import Path
import sys
root=Path(__file__).resolve().parent.parent
shared=(root/'js/mask-motion.js').read_text()
host=root/'jsx/host.jsx'
start='// BEGIN SHARED MASK MOTION 280\n'
end='// END SHARED MASK MOTION 280\n'
s=host.read_text()
block=start+shared+end
if start in s:
    old=s[s.index(start):s.index(end)+len(end)]
    if '--check' in sys.argv:
        assert old==block, 'Shared geometry is out of sync'
    else:
        s=s.replace(old,block)
elif '--check' in sys.argv:
    raise AssertionError('Missing shared geometry')
else:
    s=block+s
if '--check' not in sys.argv:host.write_text(s)
print('Shared browser/AE geometry: identical')
