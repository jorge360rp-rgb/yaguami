# QA v2.4

Pruebas vigentes:
- `engine_in_out_240_mock.js`: simulación de las 32 animaciones y combinación IN/OUT.
- `panel_smoke_test.js`: inicialización de nueve secciones.
- `background_panel_v220_mock.js`, `background_v220_mock.js`: controles y generación simulada de fondos.
- `library_ae_mock.js`: librería de tres packs.
- `diagnostico_in_out_2_4.jsx`: prueba con el motor real desde After Effects.

Las pruebas Node no renderizan y no pueden confirmar un resultado visual real en AE.
