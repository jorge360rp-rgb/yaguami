// Yaguanimix 2.7.4 - follow-mode / attached-image regression test.
// Mock harness copied from the 2.7.3 engine runner. This does NOT replace a live AE test.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
class Prop {
 constructor(name,parent){this.name=name;this.parentProperty=parent||null;this.children=[];this._value=0;this.keys=[];this.expression='';this.dimensionsSeparated=false;}
 get numProperties(){return this.children.length;}
 get numKeys(){return this.keys.length;}
 get value(){return this._value;}
 valueAtTime(){return this._value;}
 get matchName(){return this.name;}
 property(k){if(typeof k==='number')return this.children[k-1]||null;return this.children.find(x=>x.name===k||x.matchName===k)||null;}
 addProperty(k){let v=new Prop(k,this);if(k==='ADBE Vector Group')v.children.push(new Prop('ADBE Vectors Group',v));
  if(k==='ADBE Vector Shape - Rect') ['ADBE Vector Rect Position','ADBE Vector Rect Size','ADBE Vector Rect Roundness'].forEach(x=>v.children.push(new Prop(x,v)));
  if(k==='ADBE Vector Shape - Ellipse') ['ADBE Vector Ellipse Position','ADBE Vector Ellipse Size'].forEach(x=>v.children.push(new Prop(x,v)));
  if(k==='ADBE Vector Graphic - Fill') ['ADBE Vector Fill Color','ADBE Vector Fill Opacity'].forEach(x=>v.children.push(new Prop(x,v)));
  if(k==='ADBE Vector Graphic - Stroke') ['ADBE Vector Stroke Color','ADBE Vector Stroke Width'].forEach(x=>v.children.push(new Prop(x,v)));
  if(k==='ADBE Mask Atom')v.children.push(new Prop('ADBE Mask Shape',v));
  if(k==='ADBE Slider Control')v.children.push(new Prop('ADBE Slider Control-0001',v));
  this.children.push(v);return v;
 }
 remove(){if(this.parentProperty){this.parentProperty.children=this.parentProperty.children.filter(x=>x!==this);}}
 setValue(v){this._value=v;}
 setValueAtTime(t,v){let found=this.keys.find(k=>Math.abs(k.t-t)<1e-6);if(found)found.v=v;else this.keys.push({t,v});this.keys.sort((a,b)=>a.t-b.t);this._value=v;}
 setValueAtKey(k,v){this.keys[k-1].v=v;}
 keyTime(k){return this.keys[k-1].t;}
 keyValue(k){return this.keys[k-1].v;}
 removeKey(k){this.keys.splice(k-1,1);}
 setInterpolationTypeAtKey(){}
}
class Layer {
 constructor(c,type){this.c=c;this.type=type;this.name='Layer';this.comment='';this.threeDLayer=false;this.parent=null;
  this.root=new Prop('ADBE Root Vectors Group');this.effects=new Prop('ADBE Effect Parade');this.masks=new Prop('ADBE Mask Parade');
  this.position=new Prop('ADBE Position');this.opacity=new Prop('ADBE Opacity');this.scale=new Prop('ADBE Scale');this.anchor=new Prop('ADBE Anchor Point');
  this.transform={position:this.position,opacity:this.opacity,scale:this.scale,anchorPoint:this.anchor};this.label=0;this.width=1920;this.height=1080;
 }
 property(k){if(k==='ADBE Root Vectors Group')return this.root;if(k==='ADBE Effect Parade')return this.effects;
  if(k==='ADBE Mask Parade')return this.masks;if(k==='ADBE Transform Group')return {property:(p)=>p==='ADBE Position'?this.position:p==='ADBE Scale'?this.scale:null};return null;}
 remove(){this.c._layers=this.c._layers.filter(x=>x!==this);}
 moveToBeginning(){this.remove();this.c._layers.unshift(this);}
 moveToEnd(){this.remove();this.c._layers.push(this);}
 duplicate(){let l=new Layer(this.c,this.type);l.name=this.name;this.c._layers.unshift(l);return l;}
}
class CompItem {
 constructor(){this.width=1920;this.height=1080;this.duration=30;this.time=1;this.frameDuration=1/30;this.pixelAspect=1;this._layers=[];}
 get numLayers(){return this._layers.length;}
 get selectedLayers(){return this._layers.filter(x=>x.selected);}
 layer(k){return typeof k==='number'?this._layers[k-1]||null:this._layers.find(x=>x.name===k)||null;}
 get layers(){const c=this;return {addShape(){let l=new Layer(c,'shape');c._layers.unshift(l);return l;},
  addSolid(){let l=new Layer(c,'solid');c._layers.unshift(l);return l;},
  add(src){let l=new Layer(c,'footage');c._layers.unshift(l);return l;}};}
}
const comp=new CompItem(),sandbox={JSON,Math,Error,Array,CompItem,app:{project:{activeItem:comp},beginUndoGroup(){},endUndoGroup(){}},
 File:{openDialog:()=>null},ImportOptions:function(){},ImportAsType:{FOOTAGE:'FOOTAGE'},KeyframeInterpolationType:{LINEAR:'LINEAR'},isFinite};
vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../jsx/host.jsx'),'utf8'),sandbox,{filename:'host.jsx'});
function run(name,args){const r=JSON.parse(sandbox.Animix.call(name,JSON.stringify(args||{})));if(!r.ok)throw new Error(name+': '+r.msg);return r;}
function fail(name,args,part){const r=JSON.parse(sandbox.Animix.call(name,JSON.stringify(args||{})));assert.strictEqual(r.ok,false);assert(r.msg.includes(part),r.msg);}
const cfg={cols:3,rows:3,layout:{x:[0,.2,.55,1],y:[0,.25,.55,1]},draw:'both',markers:true,gap:8,
 radius:10,lineWidth:2,cellOpacity:0,rim:1,cellColor:'#8975ee',lineColor:'#ffffff',markerColor:'#ffffff'};
run('dgCreate',cfg);
const photo=comp.layers.addShape();photo.name='Imagen';photo.selected=true;photo.position.setValue([700,420]);photo.scale.setValue([112,112]);
// Start from an existing fixed reveal (the user's 2.7.3 workflow).
run('dgAttach',{targets:['c:1:1'],mode:'area',reveal:true,clip:true});
assert.strictEqual(photo.position.expression,'');
// Apply follow on the same layer, without rebuilding grid or repositioning footage.
run('dgAttach',{targets:['c:1:1'],mode:'area',follow:true,reveal:false,clip:true});
assert(photo.position.expression.includes('FOLLOW_CELL_274'));
assert.strictEqual(photo.masks.numProperties,1);
assert.strictEqual(photo.scale.expression,'');
assert.deepStrictEqual(photo.position.value,[700,420]);
assert.deepStrictEqual(photo.scale.value,[112,112]);
const posExpr=photo.position.expression;
const maskExpr=photo.masks.property(1).property('ADBE Mask Shape').expression;
assert(maskExpr.includes('DG Cell 1 1'));
// Evaluate the actual AE position expression in a JS stub at two times.
// The cell grows/moves, while the original image does NOT change its scale.
function cellAt(t){return t<=1 ? {p:[850,450],s:[460,250]} : {p:[1000,510],s:[580,300]};}
function exprProp(type,time){const prop=Object.assign([],cellAt(time)[type]);prop.valueAtTime=(t)=>cellAt(t)[type];return prop;}
function evaluatePosition(t,parent){
 const rect={position:exprProp('p',t),size:exprProp('s',t)};
 const grid={content(name){assert(name==='DG Cell 1 1');return {content(n){assert(n==='DG Rect');return rect;}}}};
 const context={Math,Number,value:[700,420],time:t,thisComp:{layer(name){assert(name==='Yaguanimix Dynamic Grid');return grid;}},thisLayer:{parent:parent||null}};
 return vm.runInNewContext(posExpr,context);
}
assert.deepStrictEqual(Array.from(evaluatePosition(1)),[700,420],'attach frame should not jump');
assert.deepStrictEqual(Array.from(evaluatePosition(2)),[850,480],'image must move +150,+60 with the cell');
const parent={fromComp:p=>[p[0]/2,p[1]/2]};
assert.deepStrictEqual(Array.from(evaluatePosition(2,parent)),[775,450],'parented image should move in parent space');
// Separate pin mode should no longer use array division (which used to produce NaN).
run('dgDetach');
run('dgAttach',{targets:['c:1:1'],mode:'area',align:'center',fit:'none',clip:true});
const pin=photo.position.expression;
assert(pin.includes('var sc=[thisLayer.scale[0]/100,thisLayer.scale[1]/100]'), 'scale has to be divided componentwise');
const rectPin={position:exprProp('p',2),size:exprProp('s',2)};
const out=vm.runInNewContext(pin,{
 Math,time:2,value:[700,420],thisComp:{layer:()=>({content:()=>({content:()=>rectPin})})},thisLayer:{parent:null,sourceRectAtTime:()=>({left:0,top:0,width:1920,height:1080}),scale:[112,112],rotation:0},
 anchorPoint:[960,540],degreesToRadians:x=>x*Math.PI/180
});
assert(Array.from(out).every(Number.isFinite),'Pin expression must evaluate finite coordinates');
// A registered Backdrop should also be convertible to a follow layer.
run('dgDetach');photo.selected=false;
const b=comp.layers.addSolid([1,0,0],'Yaguanimix Dynamic Backdrop',1920,1080,1,30);b.name='Yaguanimix Dynamic Backdrop';b.selected=true;b.position.setValue([900,500]);b.scale.setValue([100,100]);
run('dgAttach',{targets:['c:1:1'],mode:'area',follow:true});
assert(b.name==='Yaguanimix Image (follow grid)');
assert(b.position.expression.includes('FOLLOW_CELL_274'));
console.log('PASS 2.7.4: fixed reveal -> follow; stable attachment frame; image moves with cell; parent transform; pin correction; Backdrop conversion');
