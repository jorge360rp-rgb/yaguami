# QA de Yaguanimix 2.5

- `engine_in_out_240_mock.js`: regresión de los 32 presets y de IN / OUT.
- `engine_250_mock.js`: cuatro estilos de barrido, re-aplicación y zoom IN / OUT (simulación).
- `panel_smoke_test.js`: arranque de las nueve secciones (DOM simulado).
- `diagnostico_2_5.jsx`: ejecutar manualmente en After Effects 2024 / 2025. Crea una composición de prueba separada y genera un informe en el Escritorio.

Ninguno de los tests JavaScript o de navegador verifica píxeles. Los renders, efectos nativos y sus variaciones dependen de una ejecución real de After Effects. Se recomienda probar sobre una copia de proyecto antes de utilizar estas funciones en producción.
