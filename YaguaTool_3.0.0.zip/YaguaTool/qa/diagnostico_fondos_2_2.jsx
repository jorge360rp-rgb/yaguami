// Yaguanimix 2.2 — Diagnóstico real de fondos para AE 2024 / AE 2025.
// Crea UNA composición de pruebas y verifica los cuatro estilos nativos.
// Ejecutar: Archivo > Scripts > Ejecutar archivo de script.
(function () {
    var root = File($.fileName).parent.parent;
    var host = new File(root.fsName + "/jsx/host.jsx");
    if (!host.exists) { alert("No encuentro jsx/host.jsx junto al instalador."); return; }
    var lines=[],passes=0,errors=0,comp=null;
    function record(ok,label,message) {
        lines.push((ok?"OK  ":"ERROR ")+label+(message?" - "+message:""));
        if(ok)passes++;else errors++;
    }
    function invoke(name,obj) {
        var response=JSON.parse(Animix.call(name,JSON.stringify(obj||{})));
        if(!response.ok)throw new Error(response.msg);
        return response;
    }
    function ctrlLayer(c) {
        for(var i=1;i<=c.numLayers;i++){
            var l=c.layer(i);
            if(l.name.indexOf("Animix BG - CONTROLES 2.2")===0)return l;
        }
        return null;
    }
    function controls(c) {
        var l=ctrlLayer(c);
        if(!l)throw new Error("No se creó la capa de controles.");
        var fs=l.property("ADBE Effect Parade");
        return {l:l,a:fs.property("Yaguano BG Principal").property(1),
            b:fs.property("Yaguano BG Secundario").property(1),
            d:fs.property("Yaguano BG Acento").property(1)};
    }
    function exprErrors(layer) {
        var mistakes=[];
        function visit(p) {
            if(!p)return;
            try {
                if(p.propertyType===PropertyType.PROPERTY){
                    if(p.canSetExpression && p.expression && p.expression.length){
                        try{p.valueAtTime(.55,false);}catch(renderErr){}
                        var e="";
                        try{e=p.expressionError||"";}catch(noErr){}
                        if(e)mistakes.push(p.name+" : "+e);
                    }
                } else for(var z=1;z<=p.numProperties;z++)visit(p.property(z));
            }catch(unavailable){}
        }
        for(var j=1;j<=layer.numProperties;j++)visit(layer.property(j));
        return mistakes;
    }
    function testStyle(s) {
        var mode=s[0],c=comp;
        try {
            invoke("background",{style:mode,color1:"#ff4500",color2:"#00ff81",accent:"#164bff",intensity:95,speed:1.2});
            var layers=[],i;
            for(i=1;i<=c.numLayers;i++)if(c.layer(i).name.indexOf("Animix BG - ")===0)layers.push(c.layer(i));
            if(layers.length!==5)throw new Error("Capas previstas 5, encontradas "+layers.length);
            var ctrl=controls(c),before=ctrl.a.value.slice(),beforeCount=c.numLayers;
            invoke("backgroundUpdate",{style:mode,color1:"#00ff00",color2:"#ff0000",accent:"#ff00ff",intensity:85,speed:1.7});
            if(c.numLayers!==beforeCount)throw new Error("Actualizar colores creó nuevas capas");
            if(ctrl.a.value[0]>.02||ctrl.a.value[1]<.95)throw new Error("Color principal no ha cambiado");
            if(ctrl.b.value[0]<.95||ctrl.b.value[1]>.02)throw new Error("Color secundario no ha cambiado");
            if(ctrl.d.value[0]<.95||ctrl.d.value[2]<.95)throw new Error("Acento no ha cambiado");
            var problems=[];
            for(i=0;i<layers.length;i++) {
                var l=layers[i];
                if(l.name.indexOf("Luz ")>=0){
                    var ramp=l.property("ADBE Effect Parade").property(1);
                    if(!ramp||ramp.matchName!=="ADBE Ramp")problems.push(l.name+" no tiene Ramp");
                    else if(ramp.property(5).value!==2)problems.push(l.name+" no es radial");
                }
                var es=exprErrors(l);
                for(var j=0;j<es.length;j++)problems.push(es[j]);
            }
            if(problems.length)throw new Error(problems.join(" | "));
            record(true,mode,"3 colores y expresiones verificados en AE");
        }catch(e) { record(false,mode,String(e)); }
    }
    app.beginUndoGroup("Yaguanimix — Test real de fondos 2.2");
    try {
        $.evalFile(host);
        comp=app.project.items.addComp("YAGUANO_QA_FONDOS_2_2",1080,1920,1,8,30);
        comp.openInViewer();
        var cases=[["gradient"],["aurora"],["dark"],["minimal"]];
        for(var k=0;k<cases.length;k++)testStyle(cases[k]);
        lines.unshift("Yaguanimix 2.2 / AE "+app.version+" / Correctas "+passes+" / Errores "+errors);
        lines.push("La composición de prueba queda abierta con Pearl Bloom para comprobar la imagen y el movimiento.");
        var report=new File(Folder.desktop.fsName+"/Yaguanimix_Diagnostico_Fondos_2_2.txt");
        if(report.open("w")){report.encoding="UTF-8";report.write(lines.join("\n"));report.close();}
        alert("Diagnóstico de fondos: "+passes+" correctas, "+errors+" errores.\nInforme en Escritorio.\n\nComprueba el aspecto visual en la composición de prueba.");
    }catch(e){alert("Error en diagnóstico: "+String(e));}
    try{app.endUndoGroup();}catch(end){}
})();
