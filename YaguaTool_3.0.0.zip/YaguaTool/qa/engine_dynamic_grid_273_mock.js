// QA sandbox mock for Dynamic Grid v2.7: run `node qa/engine_dynamic_grid_270_mock.js`
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
class Prop {
  constructor(name,parent){this.name=name;this.parentProperty=parent||null;this.children=[];this._value=0;this.keys=[];this.expression='';this.dimensionsSeparated=false;}
  get numProperties(){return this.children.length;}
  get numKeys(){return this.keys.length;}
  get value(){return this._value;}
  valueAtTime(){return this._value;}
  get matchName(){return this.name;}
  property(k){if(typeof k==='number')return this.children[k-1]||null;return this.children.find(x=>x.name===k||x.matchName===k)||null;}
  addProperty(k){let v=new Prop(k,this);if(k==='ADBE Vector Group')v.children.push(new Prop('ADBE Vectors Group',v));
    if(k==='ADBE Vector Shape - Rect') ['ADBE Vector Rect Position','ADBE Vector Rect Size','ADBE Vector Rect Roundness'].forEach(x=>v.children.push(new Prop(x,v)));
    if(k==='ADBE Vector Shape - Ellipse') ['ADBE Vector Ellipse Position','ADBE Vector Ellipse Size'].forEach(x=>v.children.push(new Prop(x,v)));
    if(k==='ADBE Vector Graphic - Fill') ['ADBE Vector Fill Color','ADBE Vector Fill Opacity'].forEach(x=>v.children.push(new Prop(x,v)));
    if(k==='ADBE Vector Graphic - Stroke') ['ADBE Vector Stroke Color','ADBE Vector Stroke Width'].forEach(x=>v.children.push(new Prop(x,v)));
    if(k==='ADBE Mask Atom')v.children.push(new Prop('ADBE Mask Shape',v));
    if(k==='ADBE Slider Control')v.children.push(new Prop('ADBE Slider Control-0001',v));
    if(k==='ADBE Ramp')for(let i=1;i<=4;i++)v.children.push(new Prop('Ramp'+i,v));
    this.children.push(v);return v;
  }
  remove(){if(this.parentProperty){this.parentProperty.children=this.parentProperty.children.filter(x=>x!==this);}}
  setValue(v){this._value=v;}
  setValueAtTime(t,v){let found=this.keys.find(k=>Math.abs(k.t-t)<1e-6);if(found)found.v=v;else this.keys.push({t,v});this.keys.sort((a,b)=>a.t-b.t);this._value=v;}
  setValueAtKey(k,v){this.keys[k-1].v=v;}
  keyTime(k){return this.keys[k-1].t;}
  keyValue(k){return this.keys[k-1].v;}
  removeKey(k){this.keys.splice(k-1,1);}
  setInterpolationTypeAtKey(){}
}
class Layer {
  constructor(c,type){this.c=c;this.type=type;this.name='Layer';this.comment='';this.threeDLayer=false;this.parent=null;
    this.root=new Prop('ADBE Root Vectors Group');this.effects=new Prop('ADBE Effect Parade');this.masks=new Prop('ADBE Mask Parade');
    this.position=new Prop('ADBE Position');this.opacity=new Prop('ADBE Opacity');this.scale=new Prop('ADBE Scale');this.anchor=new Prop('ADBE Anchor Point');
    this.transform={position:this.position,opacity:this.opacity,scale:this.scale,anchorPoint:this.anchor};this.label=0;this.width=1920;this.height=1080;
  }
  property(k){if(k==='ADBE Root Vectors Group')return this.root;if(k==='ADBE Effect Parade')return this.effects;
    if(k==='ADBE Mask Parade')return this.masks;if(k==='ADBE Transform Group')return {property:(p)=>p==='ADBE Position'?this.position:p==='ADBE Scale'?this.scale:null};return null;}
  remove(){this.c._layers=this.c._layers.filter(x=>x!==this);}
  moveToBeginning(){this.remove();this.c._layers.unshift(this);}
  moveToEnd(){this.remove();this.c._layers.push(this);}
  duplicate(){let l=new Layer(this.c,this.type);l.name=this.name;this.c._layers.unshift(l);return l;}
}
class CompItem {
  constructor(){this.width=1920;this.height=1080;this.duration=30;this.time=1;this.frameDuration=1/30;this.pixelAspect=1;this._layers=[];}
  get numLayers(){return this._layers.length;}
  get selectedLayers(){return this._layers.filter(x=>x.selected);}
  layer(k){return typeof k==='number'?this._layers[k-1]||null:this._layers.find(x=>x.name===k)||null;}
  get layers(){const c=this;return {addShape(){let l=new Layer(c,'shape');c._layers.unshift(l);return l;},
    addSolid(){let l=new Layer(c,'solid');c._layers.unshift(l);return l;},
    add(src){let l=new Layer(c,'footage');c._layers.unshift(l);return l;}};}
}
const comp=new CompItem(),sandbox={JSON,Math,Error,Array,CompItem,app:{project:{activeItem:comp},beginUndoGroup(){},endUndoGroup(){}},
  File:{openDialog:()=>null},ImportOptions:function(){},ImportAsType:{FOOTAGE:'FOOTAGE'},KeyframeInterpolationType:{LINEAR:'LINEAR'},isFinite};
vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../jsx/host.jsx'),'utf8'),sandbox,{filename:'host.jsx'});
function run(name,args){const r=JSON.parse(sandbox.Animix.call(name,JSON.stringify(args||{})));if(!r.ok)throw new Error(name+': '+r.msg);return r;}
function fails(name,args,part){const r=JSON.parse(sandbox.Animix.call(name,JSON.stringify(args||{})));assert.strictEqual(r.ok,false,name+' should fail');assert(r.msg.includes(part),r.msg);}
const grid={cols:3,rows:3,layout:{x:[0,.25,.65,1],y:[0,.3,.72,1]},draw:'both',markers:true,gap:8,
  radius:12,lineWidth:2,cellOpacity:0,rim:1,cellColor:'#8975ee',lineColor:'#ffffff',markerColor:'#ffffff'};
run('dgCreate',grid);
const gl=comp.layer('Yaguanimix Dynamic Grid');assert(gl);
const prop=(n)=>gl.effects.property(n).property(1);
assert.strictEqual(prop('DG X 0').value,0);
assert.strictEqual(prop('DG X 1').value,.25);
assert.strictEqual(prop('DG Y 2').value,.72);
assert.strictEqual(prop('DG Gap').value,8);
const rect=gl.root.property('DG Cell 1 1').property('ADBE Vectors Group').property('DG Rect');
assert(rect.property('ADBE Vector Rect Size').expression.includes('DG X 2'));
assert(rect.property('ADBE Vector Rect Position').expression.includes('DG Y 1'));
const vline=gl.root.property('DG Vertical 1').property('ADBE Vectors Group').property('DG Rect');
assert(!vline.property('ADBE Vector Rect Position').expression.includes('[var'));
run('dgStyle',Object.assign({},grid,{gap:12,cellOpacity:70,cellColor:'#ff9900',rim:4}));
assert.strictEqual(prop('DG Gap').value,12);
run('dgAnimate',Object.assign({},grid,{motion:'Accordion',custom:false,move:.6,hold:.1,stagger:.02,easing:'Smooth',order:'row',loop:false}));
assert(prop('DG X 1').numKeys>=24,'Expected divider keyframes');
assert.strictEqual(rect.property('ADBE Vector Rect Position').numKeys,0,'Cell geometry must remain driven by rig');
const nkeys=prop('DG X 1').numKeys;
run('dgAnimate',Object.assign({},grid,{motion:'Wave',custom:false,extend:true,move:.5,hold:0,stagger:0,easing:'Easy Ease',order:'column',loop:false}));
assert(prop('DG X 1').numKeys>nkeys,'Extending should preserve earlier divider keyframes');
run('dgClearAnimation');assert.strictEqual(prop('DG X 1').numKeys,0);
run('dgSetLayout',Object.assign({},grid,{layout:{x:[0,.2,.6,1],y:[0,.4,.8,1]}}));
assert.strictEqual(prop('DG X 1').value,.2);
assert.strictEqual(run('dgStatus',{}).data.layout.x[1],.2);
// Reveal should only create / update a tracked mask, not alter footage transform.
const photo=comp.layers.addShape();photo.name='Foto de fondo';photo.selected=true;
photo.position.setValue([960,540]);photo.scale.setValue([112,112]);
run('dgAttach',{targets:['c:1:1'],mode:'area',clip:true,reveal:true,fit:'cover'});
assert.strictEqual(photo.position.expression,'');
assert.strictEqual(photo.scale.expression,'');
assert.deepStrictEqual(photo.position.value,[960,540]);
assert.deepStrictEqual(photo.scale.value,[112,112]);
assert.strictEqual(photo.masks.numProperties,1);
assert(photo.masks.property(1).property('ADBE Mask Shape').expression.includes('DG Cell 1 1'));
run('dgAttach',{targets:['c:1:1'],mode:'area',clip:true,reveal:true});
assert.strictEqual(photo.masks.numProperties,1,'Mask update should replace existing mask, not duplicate it');
run('dgDetach');assert.strictEqual(photo.masks.numProperties,0);
run('dgAttach',{targets:['c:1:1'],mode:'area',align:'center',clip:true,reveal:false,fit:'cover'});
assert(photo.position.expression.includes('YAGUANIMIX_DGRID_ATTACH'));
assert(photo.scale.expression.includes('YAGUANIMIX_DGRID_FIT'));
fails('dgAttach',{targets:['c:1:1'],mode:'area',clip:true,reveal:true},'Desvincular');
run('dgDetach');assert.strictEqual(photo.position.expression,'');
assert.strictEqual(photo.masks.numProperties,0);
run('dgRemove');assert(!comp.layer('Yaguanimix Dynamic Grid'));
console.log('PASS: divider rig, geometry expressions, styles, animation, extend, mask reveal preserves footage transform, detach');
