// Yaguanimix 2.7.5 - diagnóstico no destructivo de la comp activa y sus capas seleccionadas
(function () {
  var lines=[],c=app.project.activeItem,i,l,p,fx,masks,j,m,mp,t,t1,v,w,log;
  function add(s){lines.push(s);}
  function getErr(prop){try{return prop.expressionError||"";}catch(e){return String(e);}}
  function getV(prop,t){try{var z=prop.valueAtTime(t,false);return z instanceof Array?"["+z.join(", ")+"]":String(z);}catch(e){return "ERROR "+e;}}
  try {
    if(!(c instanceof CompItem))throw Error("Activa una composición antes de ejecutar el diagnóstico.");
    t=c.time;t1=Math.min(c.duration-.001,t+Math.max(.5,c.frameDuration*10));
    add("Yaguanimix 2.7.5 - Diagnóstico Attach");add("Comp: "+c.name+" | t="+t+" | t2="+t1);
    for(i=1;i<=c.numLayers;i++){
      l=c.layer(i);if(l.name==="Yaguanimix Dynamic Grid"){
        add("Grid: "+l.name+", efectos: "+l.property("ADBE Effect Parade").numProperties);
        fx=l.property("ADBE Effect Parade");
        add("  DG X 0: "+(fx.property("DG X 0")?getV(fx.property("DG X 0").property(1),t):"NO EXISTE"));
        add("  DG X 1: "+(fx.property("DG X 1")?getV(fx.property("DG X 1").property(1),t):"NO EXISTE"));
        add("  DG Y 1: "+(fx.property("DG Y 1")?getV(fx.property("DG Y 1").property(1),t):"NO EXISTE"));
      }
    }
    if(!c.selectedLayers.length)add("No has seleccionado imágenes en la línea de tiempo de After Effects.");
    for(i=0;i<c.selectedLayers.length;i++){
      l=c.selectedLayers[i];add("Capa: "+l.name+" | 3D: "+l.threeDLayer);
      p=l.property("ADBE Transform Group").property("ADBE Position");
      add("  Posición: "+getV(p,t)+" -> "+getV(p,t1));
      add("  Expresión: "+(p.expression?String(p.expression).substr(0,90).replace(/\n/g," "):"ninguna"));
      if(getErr(p))add("  ERROR EXPRESIÓN POSICIÓN: "+getErr(p));
      masks=l.property("ADBE Mask Parade");if(!masks||!masks.numProperties)add("  Sin máscaras");
      else for(j=1;j<=masks.numProperties;j++){
        m=masks.property(j);if(m.name.indexOf("YAG Dynamic Grid Clip")<0)continue;
        mp=m.property("ADBE Mask Shape");add("  Máscara: "+m.name+", enabled="+m.enabled);
        add("  Máscara evaluable: "+(getV(mp,t).indexOf("ERROR")<0));
        if(getErr(mp))add("  ERROR EXPRESIÓN MÁSCARA: "+getErr(mp));
      }
    }
  }catch(err){add("ERROR: "+err);}
  try{
    log=new File(Folder.desktop.fsName+"/Yaguanimix_Attach_Diagnostico_275.txt");
    log.encoding="UTF-8";log.open("w");log.write(lines.join("\r\n"));log.close();
    alert("Diagnóstico guardado en el Escritorio: "+log.name+"\n\n"+lines.join("\n").substr(0,1400));
  }catch(e2){alert(lines.join("\n")+"\n\nError al guardar: "+e2);}
})();
