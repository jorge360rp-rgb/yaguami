#!/bin/bash
# Instalador Yaguanimix 2.8.0 para AE 2024/2025 (CEP, usuario actual).
set -euo pipefail
SOURCE="$(cd "$(dirname "$0")" && pwd)"
EXTDIR="$HOME/Library/Application Support/Adobe/CEP/extensions"
DEST="$EXTDIR/Yaguanimix"
STAGE="$EXTDIR/Yaguanimix.__instalando__"
BACKUP="$EXTDIR/Yaguanimix.__respaldo__"
printf '\nYAGUANIMIX 2.8.0 - macOS / After Effects 2024-2025\n'
printf 'Cierra After Effects antes de instalar. No se necesita sudo.\n\n'
if [[ ! -f "$SOURCE/CSXS/manifest.xml" || ! -f "$SOURCE/js/main.js" ]]; then
  printf 'ERROR: descomprime el ZIP y ejecuta desde la carpeta Yaguanimix.\n' >&2
  exit 1
fi
mkdir -p "$EXTDIR"
if [[ -e "$STAGE" ]]; then rm -rf "$STAGE"; fi
# La copia se hace primero en staging, sin tocar la version en uso.
ditto "$SOURCE" "$STAGE"
if [[ ! -f "$STAGE/CSXS/manifest.xml" || ! -f "$STAGE/css/style.css" ]]; then
  printf 'ERROR: copia incompleta; se conserva la version anterior.\n' >&2
  rm -rf "$STAGE"
  exit 1
fi
if [[ -e "$BACKUP" ]]; then rm -rf "$BACKUP"; fi
if [[ -e "$DEST" ]]; then mv "$DEST" "$BACKUP"; fi
if ! mv "$STAGE" "$DEST"; then
  printf 'ERROR: no se pudo activar la nueva version; recuperando la anterior.\n' >&2
  if [[ -d "$BACKUP" ]]; then mv "$BACKUP" "$DEST"; fi
  exit 1
fi
# Permite paneles CEP sin firma. Se describe como revertirlo en la guia.
for v in 11 12 13; do
  if ! defaults write "com.adobe.CSXS.$v" PlayerDebugMode 1; then
    printf 'AVISO: no se pudo configurar CSXS.%s.\n' "$v" >&2
  fi
done
if [[ -e "$BACKUP" ]]; then rm -rf "$BACKUP"; fi
printf '\nINSTALACION COMPLETADA: %s\n' "$DEST"
printf 'Reinicia After Effects > Ventana > Extensiones (heredadas) > Yaguanimix\n'
printf 'Si no aparece, abre GUIA_INSTALACION.md.\n'
