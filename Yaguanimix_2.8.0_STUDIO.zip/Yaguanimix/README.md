# Yaguanimix Studio 2.8.0

Instala el paquete completo y reinicia After Effects. Interfaz renovada, seis revelados creativos en TEXT, previews con pausa y recorrido manual, y modos de apariencia y movimiento.

- [Novedades, uso y límites de 2.8.0](NOVEDADES_2.8.0.md)
- [Investigación de diseño y motion](INVESTIGACION_MOTION_2.8.0.md)
- [Pruebas y diagnóstico nativo](qa/README_2_8.md)
- [Instalación general](GUIA_INSTALACION.md)

La validación visual dentro de After Effects está pendiente; se incluyen las pruebas automatizadas y el script de diagnóstico.

---

## Documentación de base e historial

### Corrección 2.7.6 — Acceso a Parent de expresiones

La versión 2.7.5 podía fallar al centrar, seguir una celda y usar Cubrir/Contener sobre una capa que no tuviera *Parent*. Todas esas expresiones ahora comprueban `thisLayer.hasParent` antes de acceder a `.parent` (según la referencia oficial de After Effects). **Attach → Reparar vínculo antiguo** reescribe estas expresiones en imágenes ya vinculadas, sin eliminar máscaras ni modificar el grid. Si la máscara no llegó a crearse por el fallo, después de reparar vuelve a ejecutar la acción deseada de Attach sobre la celda.

No se ha validado esta actualización dentro de After Effects real; solo con pruebas de simulación. Guarda una copia del proyecto antes de probarla.

# Yaguanimix 2.7.6 — Corrección de Attach y centrado

**Cambio técnico:** los módulos de máscara y posición utilizan directamente los controles nativos `DG X n / DG Y n` del grid, en lugar de consultar rectángulos intermedios. La máscara y la capa comparten así la misma referencia geométrica.

- **Revelar fondo (imagen fija):** mueve únicamente la máscara.
- **Mover imagen con la celda:** guarda la posición de referencia en el instante de aplicación y añade el desplazamiento del centro de la celda, sin cambiar la escala.
- **Centrar imagen en la celda:** coloca el centro visual de la imagen en el centro de la celda, compensando ancla, escala, rotación y jerarquía padre 2D. Puede añadir ajuste uniforme Cubrir/Contener y máscara.
- **Comprobar vínculo en AE:** botón nuevo en Attach. Selecciona la imagen en AE y pulsa el botón para ver errores de expresión y una comparación de posición entre fotogramas.
- **Máscara segura:** antes de eliminar una máscara existente, valida una máscara temporal nueva.

**Para probar:** abre una composición de copia, selecciona la imagen en la línea de tiempo, entra en `Grid Pro > Attach`, selecciona una celda y elige `Mover imagen con la celda (sin reescalar)` o `Centrar imagen en la celda`. La primera opción conserva el encuadre original; la segunda cambia la posición para alinearla con la celda.

**Importante:** si el centro de la celda permanece fijo mientras solo crece su tamaño (por ejemplo un preset simétrico sobre la celda central), la imagen no se desplazará en el modo Mover; eso es geométricamente correcto. Para comprobar el vínculo, anima una celda que se traslade lateralmente o modifica sus divisores de manera asimétrica.

**Limitación:** la versión cuenta con pruebas automatizadas del código y simulaciones de expresiones, pero no se ha renderizado ni validado dentro de After Effects real. Para informes utiliza `qa/diagnostico_attach_2_7_5.jsx` desde Archivo > Scripts > Ejecutar archivo, o el botón `Comprobar vínculo en AE`. Se recomiendan copias de seguridad del proyecto.

---

# Yaguanimix 2.7.6 — Dynamic Grid Pro

**Corrección:** posición de las imágenes ancladas: corregida una operación de escala que podía invalidar la expresión y dejar la imagen inmóvil.

**Nuevo modo «Revelar y seguir celda (sin reescalar)»:** selecciona la imagen en After Effects, elige la celda y pulsa «Revelar y mover imagen». Crea una máscara ligada al grid y desplaza la propia capa exactamente según el movimiento del centro de la celda, conservando el encuadre y escala que tenga la imagen al aplicar el vínculo. No requiere reconstruir el grid, solo usar Attach de nuevo.

**Prueba:** crea grid 3×3, una imagen sobre un sólido negro; Grid Pro → Attach → Acción «Revelar y seguir celda», Celdas, Una sola celda, selecciona centro y pulsa «Revelar y mover imagen». Ve a Animate, pulsa un preset y comprueba que ambos se desplazan juntos. Para imágenes ya fijadas mediante «Revelar fondo», basta seleccionar la misma capa y aplicar el nuevo modo.

**Si la imagen se había centrado mediante el modo Anclar:** conviene pulsar «Desvincular / quitar máscara» primero para consolidar su posición.

**Limitación:** las animaciones aún necesitan verificación dentro de After Effects real. Prueba sobre un proyecto duplicado antes de producir.

---

# Yaguanimix 2.7.3 — Dynamic Grid Pro

**Correcciones 2.7.3 (Attach):** selección estable con tres gestos independientes: «Una sola celda» sustituye inmediatamente cualquier selección previa y nunca añade celdas al mover el ratón; «Varias con clics» permite añadir/quitar celdas mediante clic; «Bloque arrastrando» crea un rectángulo de celdas solo cuando se solicita expresamente. Los hit areas de líneas y marcadores no interceptan clics de celdas. El resaltado ya no reconstruye todo el SVG bajo el cursor.

**Nuevo «Revelar fondo (imagen fija)»:** selecciona una imagen/vídeo de la composición, marca una celda y pulsa «Crear máscara de revelado». Se crea solo una máscara de recorte vinculada al grid; no se reubica ni reescala la capa. «Anclar capa a celdas» sigue disponible como opción diferente. Corregida también la expresión de posición de líneas verticales.

**Prueba rápida:** crea un grid 3×3 con opacidad de celda 0, coloca un sólido negro bajo tu imagen, selecciona la imagen en la línea de tiempo, entra en Attach → Revelar fondo → Celdas → Una sola celda, pulsa el centro y «Crear máscara de revelado». Luego anima el grid.

Actualización basada en la versión 2.6, sin eliminar sus barridos, presets, biblioteca de 51 composiciones, interfaz Manrope ni barra lateral permanente.

**Nuevo Grid Pro:** seis layouts (Classic 5×5, Columns, Rows, Bento, Dense 8×8 y Mirror cols); dibujo de divisores arrastrándolos en el preview, simetría y estilos; 11 presets de animación con 32 curvas, stagger, orden, loop y layouts propios con Move/Hold; fondos sólidos/gradiente/imagen-vídeo/capa; anclaje de capas 2D/3D con expresiones a celdas, líneas e intersecciones, con máscaras recortadas limitadas a 2D.

**Uso inicial:** abre una composición en After Effects, entra en **Grid Pro → Grid**, ajusta un preset y pulsa **Crear / reconstruir grid**. Para modificar divisores en un grid existente, arrastra las líneas de la vista previa y pulsa **Aplicar disposición**. **Aplicar estilo** actualiza colores, separación y bordes conservando keyframes; **Leer grid de AE** trae la configuración del grid de la composición activa. En **Attach** usa «Cubrir celda», «Contener» o «Solo anclar»; para cubrir una celda con vídeo o imagen selecciona «Cubrir celda» y activa el recorte.

**Correcciones 2.7.2:** la animación del grid ya no mueve las celdas de forma independiente. Ahora la geometría se gobierna desde divisores X/Y internos, de modo que rectángulos, líneas e intersecciones permanecen siempre sincronizados durante la animación y sirven mejor como ventanas de recorte para vídeo o imagen. Se mantienen además las correcciones 2.7.1 de marcadores, anclajes verticales, lectura del grid desde AE, selección por arrastre y reconstrucción segura.

**Validación:** se ha revisado la lógica de animación para que las celdas dependan de los divisores y no de keyframes independientes por celda. La versión 2.7.3 supera tests de interfaz y de un motor simulado (selección simple, múltiple, arrastre, máscaras que respetan transformaciones y divisores); sigue sin certificarse dentro de After Effects real, así que conviene probarla primero con una comp de ensayo. Consulta `qa/README_2_7.md` y ejecuta `qa/diagnostico_dynamic_grid_2_7.jsx` antes de usarla en producción.

---

# Yaguanimix 2.6 — Sweep Studio, Zoom y Motion Tools

Extensión CEP para After Effects 2024/2025, con interfaz Manrope sobre el diseño proporcionado por el usuario.

## Novedades 2.6

**Barra lateral persistente:** nueve iconos siempre visibles a la izquierda; pulsa el icono de menú para desplegar nombres de pestañas. Se contrae sin perder la página actual; también puedes cerrarla con Escape.

**Text → Barridos de color:** cinco acabados bajo un solo selector: Color Sweep Glow, Iridescent Silk, Chrome Glint, Prism Split y Signal Scan. El nuevo control **Blur del barrido** (0–20 px) añade desenfoque nativo de texto localizado en el brillo en movimiento. Al aplicar otro barrido de Yaguanimix, reemplaza el anterior; las animaciones IN/OUT se mantienen. El control de blur sigue editable desde Efectos.

**Presets de texto en acordeones:** las familias 01–04 se despliegan o contraen sin mezclar botones o títulos. La sección del preset activo se abre por defecto y las preferencias se conservan.

## Novedades 2.5 (conservadas)

**Sweep Studio** (Text, después del Color Sweep original):
- **Iridescent Silk:** bandas perla/lavanda/rosa con transiciones amplias.
- **Chrome Glint:** reflejo estrecho tipo acabado metálico.
- **Prism Split:** triple separación cromática.
- **Signal Scan:** lectura digital escalonada, de estética CRT.

Cada barrido se aplica a la capa de texto original con tres animadores de relleno nativos y selectores de expresión. Se puede editar **Width, Feather, Intensity y Tone 1–3** desde Efectos. No elimina Color Sweep 2.0 ni animaciones IN/OUT. Una nueva aplicación de Studio reemplaza únicamente el Studio anterior de la capa. El botón **Preview real en AE** crea una composición de prueba independiente.

**Zoom tipográfico opcional:** en Text, activa el bloque de zoom, elige Zoom In/Zoom Out y fase IN/OUT. Sitúa el cabezal en el inicio del intervalo; los parámetros Duración y Desfase determinan el final. El efecto usa un animador de escala **por carácter** y no altera Transform Scale ni los keyframes del texto; las fases del zoom son independientes de los presets IN/OUT. Cambia la intensidad y la curva arrastrando los keyframes de Progress desde Efectos.

**Tools → Timeline:** escalonar capas en fotogramas, alinear inicios, recortar IN/OUT hasta el cabezal, añadir marcadores IN/OUT, suavizar los keyframes seleccionados con influencia ajustable y renombrar capas en lote. Se conserva el resto de Tools (Anchor Point, Split Text, Align, etc.).

## Flujo rápido

1. Selecciona una capa de texto y crea **Smart Reveal IN**.
2. Sitúa el cabezal donde empieza el zoom. Activa **Zoom tipográfico**, elige Entrada y pulsa **Aplicar zoom**.
3. Selecciona **Sweep Studio → Iridescent Silk**, ajusta la paleta y pulsa **Aplicar** (o primero **Preview real en AE**).
4. Mueve el cabezal a la salida, crea **Smart Bounce OUT**, y aplica otro **Zoom OUT · Salida** si quieres.
5. Desde **Tools** escalona otros títulos o suaviza sus keyframes.

## Instaladores

- **Windows:** `install_windows.bat`
- **macOS:** `install_mac.command` (iniciar con `bash` si está bloqueada la ejecución).

Descomprime todo el ZIP y cierra After Effects antes de actualizar. Los scripts trabajan en el directorio CEP del usuario y hacen copia temporal de la versión previa. Lee `GUIA_INSTALACION.md`.

## Alcance de validación

El arranque del panel, las nueve secciones, las solicitudes del nuevo panel, los 32 presets anteriores, los cuatro nuevos barridos y las fases de zoom se han probado en simulaciones y navegadores locales. **No se ha ejecutado un render real dentro de After Effects 2024/2025**, por lo que esta actualización es candidata a validación, no una certificación visual de compatibilidad. Ejecuta `qa/diagnostico_2_5.jsx` en After Effects para verificar los efectos nativos y las expresiones.
